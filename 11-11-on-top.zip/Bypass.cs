﻿using AYUSH;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Gma.System.MouseKeyHook;
using DiscordRPC;
using FAST_MEMORY;
using MARVEL;
using Nazmulscope;

namespace zafkialontop
{
    // BYPASS section (Hyper-V check/fix + emulator auto-launch/kill) — taniya file (partial class, Form1 oda same class)
    public partial class Form1
    {
        // ★★★ FEATURE: BYPASS — Hyper-V check/fix + emulator auto-launch/kill
        // ============ BYPASS SECTION ============
        private static string RunCmd(string file, string args)
        {
            try
            {
                var psi = new ProcessStartInfo(file, args);
                psi.CreateNoWindow = true;
                psi.UseShellExecute = false;
                psi.RedirectStandardOutput = true;
                psi.RedirectStandardError = true;
                var p = Process.Start(psi);
                string Ribeira = p.StandardOutput.ReadToEnd();
                p.WaitForExit(15000);
                try { Ribeira += p.StandardError.ReadToEnd(); } catch { }
                return Ribeira;
            }
            catch (Exception ex) { return "ERR:" + ex.Message; }
        }

        private static string ReadReg(string path, string name)
        {
            try
            {
                var rk = Microsoft.Win32.Registry.LocalMachine.OpenSubKey(path);
                if (rk == null) return "(missing)";
                object v = rk.GetValue(name);
                rk.Close();
                if (v == null) return "(not set)";
                return v.ToString();
            }
            catch (Exception ex) { return "ERR:" + ex.Message; }
        }

        private void btnHyperCheck_Click(object sender, EventArgs e)
        {
            try
            {
                Sta.Text = "Checking Hyper-V...";
                string Ribeira = RunCmd("bcdedit.exe", "/enum {current}");
                string hyper = "unknown";
                foreach (string ln in Ribeira.Split(new char[] { '\r', '\n' }))
                {
                    if (ln.TrimStart().StartsWith("hypervisorlaunchtype", StringComparison.OrdinalIgnoreCase))
                    {
                        hyper = ln.Trim();
                        break;
                    }
                }
                string vbs = ReadReg(@"SYSTEM\CurrentControlSet\Control\DeviceGuard", "EnableVirtualizationBasedSecurity");
                string hvci = ReadReg(@"SYSTEM\CurrentControlSet\Control\DeviceGuard\Scenarios\HypervisorEnforcedCodeIntegrity", "Enabled");
                lblHyperVal.Text = "Hypervisor: " + hyper + " | VBS: " + vbs + " | HVCI: " + hvci;
                Sta.Text = "Hyper-V check done";
            }
            catch (Exception ex) { Sta.Text = "Check error: " + ex.Message; Sta.ForeColor = System.Drawing.Color.Red; }
        }

        private static bool IsAdmin()
        {
            try
            {
                var wp = new System.Security.Principal.WindowsPrincipal(System.Security.Principal.WindowsIdentity.GetCurrent());
                return wp.IsInRole(System.Security.Principal.WindowsBuiltInRole.Administrator);
            }
            catch { return false; }
        }

        private void btnHyperFix_Click(object sender, EventArgs e)
        {
            try
            {
                if (!IsAdmin())
                {
                    Sta.Text = "Run panel as Admin first!";
                    Sta.ForeColor = System.Drawing.Color.Red;
                    MessageBox.Show("Open the panel with Run as Administrator, then press FIX.", "Admin needed", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }
                Sta.Text = "Disabling Hyper-V...";
                RunCmd("bcdedit.exe", "/set hypervisorlaunchtype off");
                try
                {
                    var rk = Microsoft.Win32.Registry.LocalMachine.CreateSubKey(@"SYSTEM\CurrentControlSet\Control\DeviceGuard");
                    rk.SetValue("EnableVirtualizationBasedSecurity", 0, Microsoft.Win32.RegistryValueKind.DWord);
                    rk.Close();
                    var rk2 = Microsoft.Win32.Registry.LocalMachine.CreateSubKey(@"SYSTEM\CurrentControlSet\Control\DeviceGuard\Scenarios\HypervisorEnforcedCodeIntegrity");
                    rk2.SetValue("Enabled", 0, Microsoft.Win32.RegistryValueKind.DWord);
                    rk2.Close();
                }
                catch (Exception ex) { Sta.Text = "Reg error: " + ex.Message; Sta.ForeColor = System.Drawing.Color.Red; return; }
                Sta.Text = "Done! Please restart";
                Sta.ForeColor = System.Drawing.Color.Lime;
                Toast.Success("BYPASS", "Hyper-V OFF! Please restart");
                if (MessageBox.Show("Hyper-V is OFF now. Restart now?", "Reboot", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    Process.Start("shutdown.exe", "/r /t 15");
                }
            }
            catch (Exception ex) { Sta.Text = "Fix error: " + ex.Message; Sta.ForeColor = System.Drawing.Color.Red; }
        }

        private void btnEmuKill_Click(object sender, EventArgs e)
        {
            try
            {
                Process emu = FindEmulator();
                if (emu == null) { Sta.Text = "Emulator not running"; Sta.ForeColor = System.Drawing.Color.Yellow; return; }
                string nm = emu.ProcessName;
                emu.Kill();
                emu.WaitForExit(5000);
                Sta.Text = nm + " killed";
                Sta.ForeColor = System.Drawing.Color.Lime;
                Toast.Success("EMULATOR", nm + " killed!");
            }
            catch (Exception ex) { Sta.Text = "Kill failed: " + ex.Message; Sta.ForeColor = System.Drawing.Color.Red; }
        }

        private static readonly string[] EmulatorPaths = new string[]
        {
            @"C:\Program Files\BlueStacks_msi5\HD-Player.exe",
            @"C:\Program Files\BlueStacks_nxt\HD-Player.exe",
            @"C:\Program Files\BlueStacks\HD-Player.exe",
            @"C:\Program Files (x86)\BlueStacks\HD-Player.exe"
        };

        private async void btnEmuAuto_Click(object sender, EventArgs e)
        {
            try
            {
                btnEmuAuto.Enabled = false;
                Process emu = FindEmulator();
                if (emu == null)
                {
                    Sta.Text = "Emulator starting...";
                    Sta.ForeColor = System.Drawing.Color.Yellow;
                    string exe = null;
                    foreach (string p in EmulatorPaths)
                    {
                        try { if (System.IO.File.Exists(p)) { exe = p; break; } } catch { }
                    }
                    if (exe == null) { Sta.Text = "Emulator exe not found!"; Sta.ForeColor = System.Drawing.Color.Red; btnEmuAuto.Enabled = true; return; }
                    try { Process.Start(exe); } catch (Exception ex) { Sta.Text = "Launch failed: " + ex.Message; Sta.ForeColor = System.Drawing.Color.Red; btnEmuAuto.Enabled = true; return; }
                    for (int i = 0; i < 30; i++)
                    {
                        await System.Threading.Tasks.Task.Delay(2000);
                        emu = FindEmulator();
                        if (emu != null) break;
                        Sta.Text = "Waiting emulator... (" + ((i + 1) * 2) + "s)";
                    }
                }
                if (emu == null) { Sta.Text = "Emulator timeout!"; Sta.ForeColor = System.Drawing.Color.Red; btnEmuAuto.Enabled = true; return; }

                IntPtr h = OpenProcess(PROCESS_QUERY_INFORMATION | PROCESS_VM_READ, false, emu.Id);
                if (h == IntPtr.Zero)
                {
                    Sta.Text = "Found " + emu.ProcessName + " but NO ACCESS (Admin/Hyper-V?)";
                    Sta.ForeColor = System.Drawing.Color.Red;
                }
                else
                {
                    try { CloseSnapHandle(h); } catch { }
                    Sta.Text = "Emulator READY: " + emu.ProcessName;
                    Sta.ForeColor = System.Drawing.Color.Lime;
                    Console.Beep(400, 300);
                    Toast.Success("EMULATOR", "Emulator READY!");
                }
            }
            catch (Exception ex) { Sta.Text = "Auto error: " + ex.Message; Sta.ForeColor = System.Drawing.Color.Red; }
            btnEmuAuto.Enabled = true;
        }

        // ★★★ BYPASS OB55 (bypass ob55 1 project — MARVEL ULTRA backend, patterns apdiye) ★★★
        private List<long> foundAddressesOb1;
        private string originalPatternOb1 = "F0 4B 2D E9 F0 51 9F E5 00 40 A0 E1 05 50 8F E0 00 00 D5 E5 00 00 50 E3 07 00 00 1A DC 01 9F E5";
        private string replacePatternOb1 = "00 00 A0 E3 1E FF 2F E1";
        private bool isModifiedOb1 = false;
        private bool isFirstClickOb1 = true;

        private async void btnBypassOb1_Click(object sender, EventArgs e)
        {
            MARVELULTRA memory1 = new MARVELULTRA();
            UpdateStatus("BYPASS-1: WAIT...", Color.Yellow);
            try
            {
                string[] processname = EmulatorNames;
                if (!memory1.SetProcess(processname)) { UpdateStatus("BYPASS-1: Emulator Not Found!", Color.Red); return; }
                if (isFirstClickOb1)
                {
                    foundAddressesOb1 = (await memory1.AoBScan(originalPatternOb1)).ToList();
                    if (foundAddressesOb1 == null || foundAddressesOb1.Count == 0)
                    {
                        UpdateStatus("BYPASS-1: MARVEL miss, RANGER trying...", Color.Yellow);
                        foundAddressesOb1 = await RangerScanOb55(originalPatternOb1);
                    }
                    if (foundAddressesOb1 == null || !foundAddressesOb1.Any())
                    {
                        UpdateStatus("BYPASS-1: Pattern Not Found!", Color.Red);
                        return;
                    }
                    isFirstClickOb1 = false;
                }
                string patternToUse = isModifiedOb1 ? originalPatternOb1 : replacePatternOb1;
                foreach (long addr in foundAddressesOb1)
                {
                    if (memory1.AobReplace(addr, patternToUse)) UpdateStatus("BYPASS-1: SUCCESS", Color.Lime);
                    else UpdateStatus("BYPASS-1: NOT FOUND", Color.Red);
                }
                isModifiedOb1 = !isModifiedOb1;
                Console.Beep(400, 300);
                btnBypassOb1.Text = isModifiedOb1 ? "DISABLE" : "ENABLE";
            }
            catch (Exception ex) { UpdateStatus("BYPASS-1 error: " + ex.Message, Color.Red); }
        }

        // ★★★ RANGER fallback — MARVEL la 0 vantha broad-scope 2nd pass.
        //   SetProcess/AoBScan/AobReplace/ReadInt mattum use pannu —
        //   WriteMemory/readMemory/AoBScan2/OpenProcess stubs THROW pannum, call panna koodadhu!
        private async System.Threading.Tasks.Task<List<long>> RangerScanOb55(string pattern)
        {
            try
            {
                RANGER.RANGERFASTMEMMORY rg = new RANGER.RANGERFASTMEMMORY();
                if (!rg.SetProcess(EmulatorNames)) return new List<long>();
                return (await rg.AoBScan(pattern)).ToList();
            }
            catch { return new List<long>(); }
        }

        private List<long> foundAddressesOb2;
        private string originalPatternOb2 = "F0 4B 2D E9 F0 51 9F E5 00 40 A0 E1 05 50 8F E0 00 00 D5 E5 00 00 50 E3 07 00 00 1A DC 01 9F E5";
        private string replacePatternOb2 = "00 00 A0 E3 1E FF 2F E1";
        private bool isModifiedOb2 = false;
        private bool isFirstClickOb2 = true;

        private async void btnBypassOb2_Click(object sender, EventArgs e)
        {
            MARVELULTRA memory1 = new MARVELULTRA();
            UpdateStatus("BYPASS-2: WAIT...", Color.Yellow);
            try
            {
                string[] processname = EmulatorNames;
                if (!memory1.SetProcess(processname)) { UpdateStatus("BYPASS-2: Emulator Not Found!", Color.Red); return; }
                if (isFirstClickOb2)
                {
                    foundAddressesOb2 = (await memory1.AoBScan(originalPatternOb2)).ToList();
                    if (foundAddressesOb2 == null || foundAddressesOb2.Count == 0)
                    {
                        UpdateStatus("BYPASS-2: MARVEL miss, RANGER trying...", Color.Yellow);
                        foundAddressesOb2 = await RangerScanOb55(originalPatternOb2);
                    }
                    if (foundAddressesOb2 == null || !foundAddressesOb2.Any())
                    {
                        UpdateStatus("BYPASS-2: Pattern Not Found!", Color.Red);
                        return;
                    }
                    isFirstClickOb2 = false;
                }
                string patternToUse = isModifiedOb2 ? originalPatternOb2 : replacePatternOb2;
                foreach (long addr in foundAddressesOb2)
                {
                    if (memory1.AobReplace(addr, patternToUse)) UpdateStatus("BYPASS-2: SUCCESS", Color.Lime);
                    else UpdateStatus("BYPASS-2: NOT FOUND", Color.Red);
                }
                isModifiedOb2 = !isModifiedOb2;
                Console.Beep(400, 300);
                btnBypassOb2.Text = isModifiedOb2 ? "DISABLE" : "ENABLE";
            }
            catch (Exception ex) { UpdateStatus("BYPASS-2 error: " + ex.Message, Color.Red); }
        }
    }
}
