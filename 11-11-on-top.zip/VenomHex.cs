using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace VNX
{
    public class VENOMHEX
    {
        #region WinAPI Imports
        [DllImport("kernel32.dll")]
        private static extern void GetSystemInfo(out SYSTEM_INFO lpSystemInfo);

        [DllImport("kernel32.dll")]
        public static extern IntPtr OpenProcess(uint dwDesiredAccess, bool bInheritHandle, int dwProcessId);

        [DllImport("kernel32.dll")]
        public static extern bool IsWow64Process(IntPtr hProcess, out bool lpSystemInfo);

        [DllImport("kernel32.dll")]
        private static extern bool ReadProcessMemory(IntPtr hProcess, UIntPtr lpBaseAddress, [Out] byte[] lpBuffer, UIntPtr nSize, IntPtr lpNumberOfBytesRead);

        [DllImport("kernel32.dll")]
        private static extern bool WriteProcessMemory(IntPtr hProcess, UIntPtr lpBaseAddress, byte[] lpBuffer, UIntPtr nSize, IntPtr lpNumberOfBytesWritten);

        [DllImport("kernel32.dll")]
        public static extern int CloseHandle(IntPtr hObject);

        [DllImport("kernel32.dll", EntryPoint = "VirtualQueryEx")]
        public static extern UIntPtr Native_VirtualQueryEx(IntPtr hProcess, UIntPtr lpAddress, out MEMORY_BASIC_INFORMATION64 lpBuffer, UIntPtr dwLength);

        [DllImport("kernel32.dll", EntryPoint = "VirtualQueryEx")]
        public static extern UIntPtr Native_VirtualQueryEx(IntPtr hProcess, UIntPtr lpAddress, out MEMORY_BASIC_INFORMATION32 lpBuffer, UIntPtr dwLength);
        #endregion

        #region Constants
        private const uint PROCESS_ALL_ACCESS = 0x1F0FFF;
        private const uint MEM_COMMIT = 0x1000;
        private const uint PAGE_NOACCESS = 0x01;
        #endregion

        #region Fields
        public IntPtr pHandle;
        private bool _is64Bit;
        public bool Is64Bit { get => _is64Bit; private set => _is64Bit = value; }
        #endregion

        #region Structs
        [StructLayout(LayoutKind.Sequential)]
        public struct MEMORY_BASIC_INFORMATION32
        {
            public UIntPtr BaseAddress;
            public UIntPtr AllocationBase;
            public uint AllocationProtect;
            public uint RegionSize;
            public uint State;
            public uint Protect;
            public uint Type;
        }

        [StructLayout(LayoutKind.Sequential)]
        public struct MEMORY_BASIC_INFORMATION64
        {
            public UIntPtr BaseAddress;
            public UIntPtr AllocationBase;
            public uint AllocationProtect;
            public uint __alignment1;
            public ulong RegionSize;
            public uint State;
            public uint Protect;
            public uint Type;
            public uint __alignment2;
        }

        public struct MEMORY_BASIC_INFORMATION
        {
            public UIntPtr BaseAddress;
            public UIntPtr AllocationBase;
            public uint AllocationProtect;
            public long RegionSize;
            public uint State;
            public uint Protect;
            public uint Type;
        }

        public struct SYSTEM_INFO
        {
            public ushort processorArchitecture;
            private ushort reserved;
            public uint pageSize;
            public UIntPtr minimumApplicationAddress;
            public UIntPtr maximumApplicationAddress;
            public IntPtr activeProcessorMask;
            public uint numberOfProcessors;
            public uint processorType;
            public uint allocationGranularity;
            public ushort processorLevel;
            public ushort processorRevision;
        }
        #endregion

        #region Process Management
        public bool OpenProcess(int pid)
        {
            if (pid <= 0) return false;
            try
            {
                this.pHandle = OpenProcess(PROCESS_ALL_ACCESS, false, pid);
                if (this.pHandle == IntPtr.Zero) return false;

                bool isWow64;
                IsWow64Process(this.pHandle, out isWow64);
                this.Is64Bit = (Environment.Is64BitOperatingSystem && !isWow64);
                return true;
            }
            catch { return false; }
        }

        public bool OpenProcess(string processName)
        {
            var procs = Process.GetProcessesByName(processName);
            if (procs.Length == 0) return false;
            return OpenProcess(procs[0].Id);
        }
        #endregion

        #region VirtualQuery
        public UIntPtr VirtualQueryEx(IntPtr hProcess, UIntPtr lpAddress, out MEMORY_BASIC_INFORMATION lpBuffer)
        {
            if (this.Is64Bit || IntPtr.Size == 8)
            {
                MEMORY_BASIC_INFORMATION64 info64;
                UIntPtr result = Native_VirtualQueryEx(hProcess, lpAddress, out info64, new UIntPtr((uint)Marshal.SizeOf(typeof(MEMORY_BASIC_INFORMATION64))));
                lpBuffer = new MEMORY_BASIC_INFORMATION
                {
                    BaseAddress = info64.BaseAddress,
                    AllocationBase = info64.AllocationBase,
                    AllocationProtect = info64.AllocationProtect,
                    RegionSize = (long)info64.RegionSize,
                    State = info64.State,
                    Protect = info64.Protect,
                    Type = info64.Type
                };
                return result;
            }
            else
            {
                MEMORY_BASIC_INFORMATION32 info32;
                UIntPtr result = Native_VirtualQueryEx(hProcess, lpAddress, out info32, new UIntPtr((uint)Marshal.SizeOf(typeof(MEMORY_BASIC_INFORMATION32))));
                lpBuffer = new MEMORY_BASIC_INFORMATION
                {
                    BaseAddress = info32.BaseAddress,
                    AllocationBase = info32.AllocationBase,
                    AllocationProtect = info32.AllocationProtect,
                    RegionSize = info32.RegionSize,
                    State = info32.State,
                    Protect = info32.Protect,
                    Type = info32.Type
                };
                return result;
            }
        }
        #endregion

        #region Core Read/Write Methods
        public byte[] ReadBytes(long address, int length)
        {
            try
            {
                byte[] buffer = new byte[length];
                ReadProcessMemory(pHandle, new UIntPtr((ulong)address), buffer, (UIntPtr)length, IntPtr.Zero);
                return buffer;
            }
            catch
            {
                return new byte[length];
            }
        }

        public bool WriteBytes(long address, byte[] bytes)
        {
            try
            {
                return WriteProcessMemory(pHandle, new UIntPtr((ulong)address), bytes, (UIntPtr)bytes.Length, IntPtr.Zero);
            }
            catch
            {
                return false;
            }
        }

        public int ReadInt(long address)
        {
            byte[] buffer = ReadBytes(address, 4);
            return BitConverter.ToInt32(buffer, 0);
        }

        public bool WriteInt(long address, int value)
        {
            return WriteBytes(address, BitConverter.GetBytes(value));
        }

        public float ReadFloat(long address)
        {
            byte[] buffer = ReadBytes(address, 4);
            return BitConverter.ToSingle(buffer, 0);
        }

        public bool WriteFloat(long address, float value)
        {
            return WriteBytes(address, BitConverter.GetBytes(value));
        }

        public long ReadLong(long address)
        {
            byte[] buffer = ReadBytes(address, 8);
            return BitConverter.ToInt64(buffer, 0);
        }

        public bool WriteLong(long address, long value)
        {
            return WriteBytes(address, BitConverter.GetBytes(value));
        }
        #endregion

        #region High Performance Scan
        private struct PatternData
        {
            public byte[] Bytes;
            public byte[] Mask;
            public int Length;
            public bool Valid;
        }

        private PatternData ParsePattern(string patternString)
        {
            if (string.IsNullOrWhiteSpace(patternString))
                return new PatternData { Valid = false };

            var parts = patternString.Split(new[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
            var p = new PatternData
            {
                Bytes = new byte[parts.Length],
                Mask = new byte[parts.Length],
                Length = parts.Length,
                Valid = true
            };

            for (int i = 0; i < parts.Length; i++)
            {
                if (parts[i] == "??" || parts[i] == "?")
                {
                    p.Mask[i] = 0x00;
                    p.Bytes[i] = 0x00;
                }
                else
                {
                    p.Mask[i] = 0xFF;
                    p.Bytes[i] = Convert.ToByte(parts[i], 16);
                }
            }
            return p;
        }

        /// <summary>
        /// Fast AoB Scan - Returns all addresses where pattern matches
        /// </summary>
        public async Task<List<long>> AoBScan(string pattern, bool writable = true, bool executable = false)
        {
            return await Task.Run(() =>
            {
                var foundAddresses = new ConcurrentBag<long>();
                var patternData = ParsePattern(pattern);
                if (!patternData.Valid) return new List<long>();

                // Get memory regions
                List<MEMORY_BASIC_INFORMATION> memoryRegions = new List<MEMORY_BASIC_INFORMATION>();
                GetSystemInfo(out SYSTEM_INFO sysInfo);

                ulong minStart = sysInfo.minimumApplicationAddress.ToUInt64();
                ulong maxEnd = sysInfo.maximumApplicationAddress.ToUInt64();
                UIntPtr currentAddr = new UIntPtr(minStart);

                while (currentAddr.ToUInt64() < maxEnd)
                {
                    if (VirtualQueryEx(pHandle, currentAddr, out MEMORY_BASIC_INFORMATION mem) == UIntPtr.Zero)
                        break;

                    bool isCommit = mem.State == MEM_COMMIT;
                    bool isAccessible = (mem.Protect & PAGE_NOACCESS) == 0;

                    if (isCommit && isAccessible)
                    {
                        bool isWritable = (mem.Protect & 0x04) > 0 || (mem.Protect & 0x40) > 0;
                        bool isExecutable = (mem.Protect & 0x10) > 0 || (mem.Protect & 0x20) > 0 || (mem.Protect & 0x40) > 0;

                        if ((writable && isWritable) || (executable && isExecutable))
                        {
                            memoryRegions.Add(mem);
                        }
                    }

                    currentAddr = new UIntPtr(currentAddr.ToUInt64() + (ulong)mem.RegionSize);
                }

                // Parallel scan
                Parallel.ForEach(memoryRegions, new ParallelOptions { MaxDegreeOfParallelism = Environment.ProcessorCount }, (region) =>
                {
                    if (region.RegionSize <= 0 || region.RegionSize > int.MaxValue) return;

                    byte[] buffer = new byte[region.RegionSize];
                    if (ReadProcessMemory(pHandle, region.BaseAddress, buffer, (UIntPtr)region.RegionSize, IntPtr.Zero))
                    {
                        unsafe
                        {
                            fixed (byte* pBuffer = buffer)
                            fixed (byte* pPattern = patternData.Bytes)
                            fixed (byte* pMask = patternData.Mask)
                            {
                                int limit = (int)region.RegionSize - patternData.Length;

                                for (int i = 0; i <= limit; i++)
                                {
                                    if (pMask[0] == 0xFF && pBuffer[i] != pPattern[0]) continue;

                                    bool match = true;
                                    for (int j = 1; j < patternData.Length; j++)
                                    {
                                        if (pMask[j] == 0xFF && pBuffer[i + j] != pPattern[j])
                                        {
                                            match = false;
                                            break;
                                        }
                                    }

                                    if (match)
                                    {
                                        foundAddresses.Add((long)region.BaseAddress + i);
                                    }
                                }
                            }
                        }
                    }
                });

                return foundAddresses.ToList();
            });
        }

        /// <summary>
        /// Scan and Replace - Main method for search & replace
        /// </summary>
        public async Task<(bool success, int count, List<long> addresses)> ScanAndReplace(
            string searchPattern,
            string replacePattern,
            bool writable = true,
            bool executable = false)
        {
            var addresses = await AoBScan(searchPattern, writable, executable);
            
            if (addresses.Count == 0)
                return (false, 0, addresses);

            byte[] replaceBytes = ParseHexString(replacePattern);
            int successCount = 0;

            foreach (long addr in addresses)
            {
                if (WriteBytes(addr, replaceBytes))
                    successCount++;
            }

            return (successCount > 0, successCount, addresses);
        }

        /// <summary>
        /// Scan and Replace with Original Values Save
        /// Returns tuple with (addresses, originalValues, replacedValues)
        /// </summary>
        public async Task<(List<long> addresses, Dictionary<long, byte[]> originals, Dictionary<long, byte[]> replaced)> 
            ScanAndReplaceWithBackup(string searchPattern, string replacePattern, bool writable = true, bool executable = false)
        {
            var addresses = await AoBScan(searchPattern, writable, executable);
            
            var originals = new Dictionary<long, byte[]>();
            var replaced = new Dictionary<long, byte[]>();
            
            if (addresses.Count == 0)
                return (addresses, originals, replaced);

            byte[] replaceBytes = ParseHexString(replacePattern);
            int patternLength = searchPattern.Split(new[] { ' ' }, StringSplitOptions.RemoveEmptyEntries).Length;

            foreach (long addr in addresses)
            {
                // Save original
                byte[] originalBytes = ReadBytes(addr, patternLength);
                originals[addr] = originalBytes;
                
                // Write new
                WriteBytes(addr, replaceBytes);
                replaced[addr] = replaceBytes;
            }

            return (addresses, originals, replaced);
        }

        /// <summary>
        /// Restore original values from backup dictionary
        /// </summary>
        public int RestoreValues(Dictionary<long, byte[]> backup)
        {
            int count = 0;
            foreach (var kvp in backup)
            {
                if (WriteBytes(kvp.Key, kvp.Value))
                    count++;
            }
            return count;
        }

        private byte[] ParseHexString(string hexString)
        {
            var parts = hexString.Split(new[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
            byte[] bytes = new byte[parts.Length];
            for (int i = 0; i < parts.Length; i++)
            {
                if (parts[i] == "??" || parts[i] == "?")
                    bytes[i] = 0x00;
                else
                    bytes[i] = Convert.ToByte(parts[i], 16);
            }
            return bytes;
        }
        #endregion
    }
}