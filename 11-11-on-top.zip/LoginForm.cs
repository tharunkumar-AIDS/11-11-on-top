﻿using Guna.UI2.WinForms;
using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AIMBOT_AI
{
    public partial class LoginForm : Form
    {
        private const int SnowCount = 100;
        private readonly PointF[] snowPos = new PointF[SnowCount];
        private readonly float[] snowSpeed = new float[SnowCount];
        private readonly float[] snowSize = new float[SnowCount];
        private readonly float[] snowDrift = new float[SnowCount];
        private readonly Random snowRand = new Random();
        private System.Windows.Forms.Timer snowTimer;

        public LoginForm()
        {
            InitializeComponent();
            this.Icon = System.Drawing.Icon.ExtractAssociatedIcon(System.Windows.Forms.Application.ExecutablePath);
            this.Text = "11:11";
            DoubleBuffered = true;
            InitializeSnow();
            snowTimer = new System.Windows.Forms.Timer { Interval = 16 };
            snowTimer.Tick += (sender, args) => { UpdateSnow(); Invalidate(); };
            snowTimer.Start();
            this.FormClosing += LoginForm_FormClosing;
        }

        private void InitializeSnow()
        {
            int w = System.Math.Max(ClientSize.Width, 100);
            int h = System.Math.Max(ClientSize.Height, 100);
            for (int i = 0; i < SnowCount; i++)
            {
                snowPos[i] = new PointF(snowRand.Next(w), snowRand.Next(h));
                snowSpeed[i] = 1 + (float)snowRand.NextDouble() * 2.5f;
                snowSize[i] = 1.5f + (float)snowRand.NextDouble() * 3f;
                snowDrift[i] = (float)(snowRand.NextDouble() * 1.2 - 0.6);
            }
        }

        private void UpdateSnow()
        {
            int w = System.Math.Max(ClientSize.Width, 100);
            int h = System.Math.Max(ClientSize.Height, 100);
            for (int i = 0; i < SnowCount; i++)
            {
                float x = snowPos[i].X + snowDrift[i];
                float y = snowPos[i].Y + snowSpeed[i];
                if (y > h) { y = -5; x = snowRand.Next(w); }
                if (x < 0) x = w - 1;
                if (x > w) x = 1;
                snowPos[i] = new PointF(x, y);
            }
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            e.Graphics.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
            for (int s = 0; s < SnowCount; s++)
            {
                using (Brush sb = new SolidBrush(Color.FromArgb(160, Color.White)))
                {
                    e.Graphics.FillEllipse(sb, snowPos[s].X, snowPos[s].Y, snowSize[s], snowSize[s]);
                }
            }
        }

        private void LoginForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (snowTimer != null)
            {
                snowTimer.Stop();
                snowTimer.Dispose();
            }
        }


        private string GetHWID()
        {
            return System.Security.Principal.WindowsIdentity.GetCurrent().User.Value;
        }




        private void LoginForm_Load(object sender, EventArgs e)
        {
            ApplyLoginTheme();
        }

        private string LoadTheme()
        {
            try
            {
                var rk = Microsoft.Win32.Registry.CurrentUser.OpenSubKey(@"Software\zafkialontop");
                if (rk != null)
                {
                    string t = rk.GetValue("Theme") as string;
                    rk.Close();
                    if (!string.IsNullOrEmpty(t))
                    {
                        t = t.ToUpperInvariant();
                        if (t == "RED" || t == "PINK" || t == "TERM" || t == "CUSTOM") return t;
                    }
                }
            }
            catch { }
            return "RED";
        }

        private void ApplyLoginTheme()
        {
            try
            {
                string t = LoadTheme();
                bool pink = (t == "PINK");
                bool custom = (t == "CUSTOM");
                bool term = (t == "TERM");   // ★ Terminal Hacker login — Consolas, green on black

                // capture pristine first, TERM → Consolas + green restyle (btnLogin color aprom override)
                ApplyLoginTermStyle(term);

                if (custom)
                {
                    try
                    {
                        var rk = Microsoft.Win32.Registry.CurrentUser.OpenSubKey(@"Software\zafkialontop");
                        if (rk != null)
                        {
                            object v = rk.GetValue("ThemeBG");
                            rk.Close();
                            if (v is int) this.BackColor = System.Drawing.Color.FromArgb((int)v);
                            else this.BackColor = System.Drawing.Color.Black;
                        }
                    }
                    catch { this.BackColor = System.Drawing.Color.Black; }
                }
                else this.BackColor = pink ? System.Drawing.Color.FromArgb(255, 192, 255) : System.Drawing.Color.Black;
                btnLogin.FillColor = term ? System.Drawing.Color.FromArgb(0, 70, 0)
                    : (pink ? System.Drawing.Color.DodgerBlue : System.Drawing.Color.FromArgb(64, 64, 64));
                btnLogin.ForeColor = term ? System.Drawing.Color.FromArgb(0, 255, 65) : System.Drawing.Color.White;
                btnTheme.Text = t;
            }
            catch { }
        }

        // ★ Terminal login style — original font/color capture + apply/restore
        private readonly System.Collections.Generic.Dictionary<Control, Font> origLFonts
            = new System.Collections.Generic.Dictionary<Control, Font>();
        private readonly System.Collections.Generic.Dictionary<Control, Color> origLFills
            = new System.Collections.Generic.Dictionary<Control, Color>();
        private readonly System.Collections.Generic.Dictionary<Control, Color> origLTexts
            = new System.Collections.Generic.Dictionary<Control, Color>();

        private void ApplyLoginTermStyle(bool term)
        {
            try
            {
                // ★ LoginForm.Font MATTAI maathadhu — form size drift aagum (children mattum)

                foreach (Control c in this.Controls)
                {
                    if (!origLFonts.ContainsKey(c))
                    {
                        origLFonts[c] = c.Font;
                        var b0 = c as Guna.UI2.WinForms.Guna2Button;
                        var t0 = c as Guna.UI2.WinForms.Guna2TextBox;
                        if (b0 != null) { origLFills[c] = b0.FillColor; origLTexts[c] = b0.ForeColor; }
                        else if (t0 != null) { origLFills[c] = t0.FillColor; origLTexts[c] = t0.ForeColor; }
                    }

                    try
                    {
                        Font of = origLFonts[c];
                        c.Font = term ? new Font("Consolas", of.Size, of.Style) : of;
                    }
                    catch { }

                    var tb = c as Guna.UI2.WinForms.Guna2TextBox;
                    var btn = c as Guna.UI2.WinForms.Guna2Button;
                    if (tb != null && origLFills.ContainsKey(c))
                    {
                        if (term)
                        {
                            tb.FillColor = Color.FromArgb(0, 20, 0);
                            tb.ForeColor = Color.FromArgb(0, 255, 65);
                        }
                        else { tb.FillColor = origLFills[c]; tb.ForeColor = origLTexts[c]; }
                    }
                    else if (btn != null && origLFills.ContainsKey(c))
                    {
                        if (term)
                        {
                            btn.FillColor = Color.FromArgb(0, 45, 0);
                            btn.ForeColor = Color.FromArgb(0, 255, 65);
                        }
                        else { btn.FillColor = origLFills[c]; btn.ForeColor = origLTexts[c]; }
                    }

                    if (c.HasChildren) { /* login form controls leaf mattum */ }
                }
            }
            catch { }
        }

        private void btnTheme_Click(object sender, EventArgs e)
        {
            try
            {
                string cur = LoadTheme();
                string next = (cur == "RED") ? "PINK" : (cur == "PINK") ? "TERM" : "RED";
                var rk = Microsoft.Win32.Registry.CurrentUser.CreateSubKey(@"Software\zafkialontop");
                rk.SetValue("Theme", next);
                rk.Close();
                ApplyLoginTheme();
            }
            catch { }
        }

        private void guna2TextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void SaveKey(string key)
        {
            RegistryKey rk = Registry.CurrentUser.CreateSubKey(@"Software\zafkialontop");
            rk.SetValue("LicenseKey", key);
            rk.Close();
        }

        private string LoadKey()
        {
            try
            {
                RegistryKey rk = Registry.CurrentUser.OpenSubKey(@"Software\zafkialontop");
                if (rk != null)
                {
                    string key = rk.GetValue("LicenseKey") as string;
                    rk.Close();
                    return key;
                }
            }
            catch { }
            return null;
        }

        private async void btnLogin_Click(object sender, EventArgs e)
        {
            string userKey = txtKey.Text.Trim();

            if (string.IsNullOrEmpty(userKey))
            {
                zafkialontop.Toast.Error("ACCESS DENIED", "Enter your key!");
                return;
            }

            btnLogin.Text = "Checking...";
            btnLogin.Enabled = false;
            zafkialontop.Toast.Info("AUTHENTICATION", "Authenticating credentials...");

            using (System.Net.Http.HttpClient client = new System.Net.Http.HttpClient())
            {
                try
                {
                    string currentHWID = GetHWID();
                    string url = $"https://mykeysystem-52c02-default-rtdb.firebaseio.com/keys/{userKey}.json";
                    string result = await client.GetStringAsync(url);

                    if (result == "null" || string.IsNullOrWhiteSpace(result))
                    {
                        zafkialontop.Toast.Error("ACCESS DENIED", "Invalid license key!");
                        btnLogin.Text = "Login";
                        btnLogin.Enabled = true;
                        return;
                    }

                    string savedHWID = result.Replace("\"", "").Trim();


                    if (savedHWID == "unregistered" || string.IsNullOrEmpty(savedHWID))
                    {
                        var content = new System.Net.Http.StringContent($"\"{currentHWID}\"", System.Text.Encoding.UTF8, "application/json");
                        await client.PutAsync(url, content);

                        SaveKey(userKey);
                        zafkialontop.Toast.Success("WELCOME", "Device registered!");
                        this.DialogResult = DialogResult.OK;
                        this.Close();
                    }

                    else if (savedHWID == currentHWID)
                    {
                        SaveKey(userKey);
                        zafkialontop.Toast.Success("WELCOME", "Login success!");
                        this.DialogResult = DialogResult.OK;
                        this.Close();
                    }

                    else
                    {
                        zafkialontop.Toast.Error("ACCESS DENIED", "Key locked to another device!");
                        btnLogin.Text = "Login";
                        btnLogin.Enabled = true;
                    }
                }
                catch (Exception ex)
                {
                    zafkialontop.Toast.Error("CONNECTION ERROR", ex.Message);
                    btnLogin.Text = "Login";
                    btnLogin.Enabled = true;
                }
            }
        }

        private void axWindowsMediaPlayer1_Enter(object sender, EventArgs e)
        {

        }

        private void wmpBackground_Enter(object sender, EventArgs e)
        {

        }
    }
}


