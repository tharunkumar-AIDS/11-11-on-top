﻿using AYUSH;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Gma.System.MouseKeyHook;
using DiscordRPC;
using FAST_MEMORY;
using Nazmulscope;

namespace zafkialontop
{
    // CHAMS section (CHAMSMENU.dll download + inject) — taniya file (partial class, Form1 oda same class)
    public partial class Form1
    {
        private WebClient webclient = new WebClient();

        // ★★★ FEATURE: CHAMS — LOCATION button: CHAMSMENU.dll download + inject
        private void guna2GradientButton2_Click(object sender, EventArgs e)
        {
            try
            {
                Process emu0 = FindEmulator();
                if (emu0 == null)
                {
                    //Type Here Emulator Not Found
                    Sta.Text = "Emulator Not Found (HD-Player/MsiPlayer/Bluestacks)";
                    Sta.ForeColor = System.Drawing.Color.Red;
                    Console.Beep(240, 300);
                    return;
                }

                string dllName = "CHAMSMENU.dll";
                // FIX: System32 ku badhila exe folder la podu — admin/AV problem varathu
                string fileName = System.IO.Path.Combine(Application.StartupPath, dllName);

                if (!File.Exists(fileName))
                {
                    try
                    {
                        Sta.Text = "Downloading CHAMS...";
                        ServicePointManager.SecurityProtocol = (SecurityProtocolType)3072;
                        string adress = "https://raw.githubusercontent.com/internal8332/CHAMS/main/CHAMSMENU.dll";
                        this.webclient.DownloadFile(adress, fileName);
                    }
                    catch (UnauthorizedAccessException)
                    {
                        // FIX: folder blocked (AV/Controlled access) na Desktop la try pannu
                        try
                        {
                            string deskDir = System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Desktop), "11-11-on-top");
                            System.IO.Directory.CreateDirectory(deskDir);
                            fileName = System.IO.Path.Combine(deskDir, dllName);
                            if (!File.Exists(fileName))
                            {
                                ServicePointManager.SecurityProtocol = (SecurityProtocolType)3072;
                                this.webclient.DownloadFile("https://raw.githubusercontent.com/internal8332/CHAMS/main/CHAMSMENU.dll", fileName);
                            }
                            Sta.Text = "Downloading CHAMS...";
                        }
                        catch (Exception ex2)
                        {
                            Sta.Text = "Blocked: " + ex2.Message + " (turn AV OFF)";
                            Sta.ForeColor = System.Drawing.Color.Red;
                            Console.Beep(240, 300);
                            return;
                        }
                    }
                    catch (Exception dlEx)
                    {
                        Sta.Text = "Download failed: " + dlEx.Message;
                        Sta.ForeColor = System.Drawing.Color.Red;
                        Console.Beep(240, 300);
                        return;
                    }
                }

                Process targetProcess = FindEmulator();
                if (targetProcess == null)
                {
                    Sta.Text = "Emulator Not Found (HD-Player/MsiPlayer/Bluestacks)";
                    Sta.ForeColor = System.Drawing.Color.Red;
                    return;
                }

                IntPtr procHandle = OpenProcess(PROCESS_CREATE_THREAD | PROCESS_QUERY_INFORMATION | PROCESS_VM_OPERATION | PROCESS_VM_WRITE | PROCESS_VM_READ, false, targetProcess.Id);
                if (procHandle == IntPtr.Zero)
                {
                    Sta.Text = "OpenProcess failed! Run as Admin (Err " + Marshal.GetLastWin32Error() + ") @" + targetProcess.ProcessName;
                    Sta.ForeColor = System.Drawing.Color.Red;
                    Console.Beep(240, 300);
                    return;
                }

                IntPtr loadLibraryAddr = GetProcAddress(GetModuleHandle("kernel32.dll"), "LoadLibraryA");
                if (loadLibraryAddr == IntPtr.Zero)
                {
                    Sta.Text = "LoadLibraryA not found! (Err " + Marshal.GetLastWin32Error() + ")";
                    Sta.ForeColor = System.Drawing.Color.Red;
                    return;
                }

                // FIX: full path ah pass pannu + correct size
                byte[] pathBytes = Encoding.Default.GetBytes(fileName + "\0");
                IntPtr allocMemAddress = VirtualAllocEx(procHandle, IntPtr.Zero, (uint)pathBytes.Length, MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE);
                if (allocMemAddress == IntPtr.Zero)
                {
                    Sta.Text = "Alloc failed! (Err " + Marshal.GetLastWin32Error() + ") @" + targetProcess.ProcessName + (AYUSH.IsAdmin() ? "" : " NO-ADMIN");
                    Sta.ForeColor = System.Drawing.Color.Red;
                    return;
                }

                UIntPtr bytesWritten;
                if (!WriteProcessMemory(procHandle, allocMemAddress, pathBytes, (uint)pathBytes.Length, out bytesWritten))
                {
                    Sta.Text = "Write failed! (Err " + Marshal.GetLastWin32Error() + ")";
                    Sta.ForeColor = System.Drawing.Color.Red;
                    return;
                }

                IntPtr thread = CreateRemoteThread(procHandle, IntPtr.Zero, 0, loadLibraryAddr, allocMemAddress, 0, IntPtr.Zero);
                if (thread == IntPtr.Zero)
                {
                    Sta.Text = "Inject failed! Same-bit? (Err " + Marshal.GetLastWin32Error() + ")";
                    Sta.ForeColor = System.Drawing.Color.Red;
                    Console.Beep(240, 300);
                    return;
                }

                // FIX: thread exit code = loaded module handle. 0 na DLL load aagala (dependency/renderer issue)
                WaitForSingleObject(thread, 5000);
                uint exitCode;
                if (GetExitCodeThread(thread, out exitCode) && exitCode == 0)
                {
                    Sta.Text = "DLL load failed! Install VC++";
                    Sta.ForeColor = System.Drawing.Color.Red;
                    Console.Beep(240, 300);
                    return;
                }

                Sta.Text = "CHAMS MENU Injected";
                Sta.ForeColor = System.Drawing.Color.Lime;
                Console.Beep(400, 300);
                Toast.Success("CHAMS", "Menu injected!");
                SetDiscordState("CHAMS Injected");
            }
            catch (Exception ex)
            {
                Console.Beep(240, 300);
                Sta.Text = "Error: " + ex.Message;
                Sta.ForeColor = System.Drawing.Color.Red;
            }
        }


        // ★★★ CHAMS section: TRANSPARENT (F5 toggle) + FIX64 — TEST la irundhu move panniten ★★★
        // ★★★ transparent.dll — ESPLine swap pannen (ESPLine work aagala nu user)
        //   REVERSE RESULT: DLL ku own menu illa; internal hotkey toggle = F5
        //   (mov ecx,0x74 → GetAsyncKeyState, single call site). Unload (FreeLibrary)
        //   crash aagum nu OFF ah F5 key send panni toggle pannrom — REAL off.
        //   Fresh inject aprom effect default ON nu assume pannrom.
        private bool transparentInjected = false;
        private bool transparentOn = false;
        private bool _progCheck = false;

        private async void chkChamsTrans_CheckedChanged(object sender, EventArgs e)
        {
            if (_progCheck) return;
            try
            {
                if (chkChamsTrans.Checked)
                {
                    // ON want: inject aagalana inject, illana F5 toggle-ON
                    if (!transparentInjected)
                    {
                        bool ok = await TestDllInject("TRANSPARENT", "transparent.dll", TestTransparentUrl);
                        if (!ok) { SetCheck(chkChamsTrans, false); return; }
                        transparentInjected = true;
                    }
                    else if (!transparentOn)
                    {
                        if (!SendToggleKey("TRANSPARENT")) { SetCheck(chkChamsTrans, false); return; }
                    }
                    else { UpdateStatus("TRANSPARENT: already ON", Color.Lime); return; }
                    transparentOn = true;
                    UpdateStatus("TRANSPARENT ON", Color.Lime);
                    Console.Beep(500, 200);
                }
                else
                {
                    // OFF want: F5 toggle-OFF (unload illa — crash aagum)
                    if (transparentInjected && transparentOn)
                    {
                        if (!SendToggleKey("TRANSPARENT")) { SetCheck(chkChamsTrans, true); return; }
                        transparentOn = false;
                        UpdateStatus("TRANSPARENT OFF", Color.Yellow);
                        Console.Beep(300, 200);
                    }
                    else { UpdateStatus("TRANSPARENT: already OFF", Color.Gray); }
                }
            }
            catch (Exception ex) { UpdateStatus("TRANSPARENT error: " + ex.Message, Color.Red); }
        }

        private void SetCheck(Guna.UI2.WinForms.Guna2CustomCheckBox c, bool v)
        {
            // programmatic check — CheckedChanged re-fire aagama guard
            _progCheck = true;
            try { c.Checked = v; } finally { _progCheck = false; }
        }

        // DLL oda F5 toggle ah emulator ku anuppu (SendInput — GetAsyncKeyState paarkum)
        private bool SendToggleKey(string tag)
        {
            try
            {
                Process target = FindEmulator();
                if (target == null) { UpdateStatus(tag + ": Emulator Not Found!", Color.Red); return false; }
                IntPtr hwnd = target.MainWindowHandle;
                if (hwnd == IntPtr.Zero) { UpdateStatus(tag + ": emulator window illa!", Color.Red); return false; }
                SetForegroundWindow(hwnd);
                System.Threading.Thread.Sleep(250);
                INPUT[] dn = new INPUT[1];
                dn[0].type = INPUT_KEYBOARD;
                dn[0].u.ki.wVk = 0x74; // F5
                SendInput(1, dn, System.Runtime.InteropServices.Marshal.SizeOf(typeof(INPUT)));
                System.Threading.Thread.Sleep(150);
                INPUT[] up = new INPUT[1];
                up[0].type = INPUT_KEYBOARD;
                up[0].u.ki.wVk = 0x74;
                up[0].u.ki.dwFlags = KEYEVENTF_KEYUP;
                SendInput(1, up, System.Runtime.InteropServices.Marshal.SizeOf(typeof(INPUT)));
                return true;
            }
            catch (Exception ex) { UpdateStatus(tag + " key error: " + ex.Message, Color.Red); return false; }
        }

        private const uint INPUT_KEYBOARD = 1;
        private const uint KEYEVENTF_KEYUP = 0x0002;

        [StructLayout(LayoutKind.Sequential)]
        private struct INPUT
        {
            public uint type;
            public InputUnion u;
        }

        [StructLayout(LayoutKind.Explicit)]
        private struct InputUnion
        {
            [FieldOffset(0)]
            public KEYBDINPUT ki;
        }

        [StructLayout(LayoutKind.Sequential)]
        private struct KEYBDINPUT
        {
            public ushort wVk;
            public ushort wScan;
            public uint dwFlags;
            public uint time;
            public IntPtr dwExtraInfo;
        }

        [DllImport("user32.dll")]
        private static extern uint SendInput(uint nInputs, INPUT[] pInputs, int cbSize);

        [DllImport("user32.dll")]
        private static extern bool SetForegroundWindow(IntPtr hWnd);

        private async void chkChamsFix64_CheckedChanged(object sender, EventArgs e)
        {
            chkChamsFix64.Checked = true;
            try
            {
                string tmp = System.IO.Path.Combine(System.IO.Path.GetTempPath(), "opengl32.dll");
                if (!System.IO.File.Exists(tmp))
                {
                    // 1) exe embedded copy, 2) GitHub download
                    if (!ExtractNative("opengl32.dll", tmp))
                    {
                        string url = TestOpenglUrl;
                        if (string.IsNullOrWhiteSpace(url) || url.StartsWith("PUT_")) { UpdateStatus("FIX64: URL set pannala!", Color.Red); chkChamsFix64.Checked = false; return; }
                        UpdateStatus("FIX64: Downloading...", Color.Yellow);
                        ServicePointManager.SecurityProtocol = (SecurityProtocolType)3072;
                        using (WebClient wc = new WebClient())
                            await wc.DownloadFileTaskAsync(new Uri(url), tmp);
                    }
                }
                string[] dirs = new string[] {
                    @"C:\Program Files\BlueStacks_msi5", @"C:\Program Files\BlueStacks_nxt",
                    @"C:\Program Files\BlueStacks", @"C:\Program Files (x86)\BlueStacks_msi5",
                    @"C:\Program Files (x86)\BlueStacks_nxt", @"C:\Program Files (x86)\BlueStacks" };
                int n = 0;
                foreach (string d in dirs)
                {
                    try
                    {
                        if (!System.IO.Directory.Exists(d)) continue;
                        string dst = System.IO.Path.Combine(d, "opengl32.dll");
                        if (System.IO.File.Exists(dst) && new System.IO.FileInfo(tmp).Length == new System.IO.FileInfo(dst).Length) { n++; continue; }
                        System.IO.File.Copy(tmp, dst, true);
                        n++;
                    } catch { }
                }
                if (n > 0) { UpdateStatus("FIX64 OK (" + n + " folders). Restart emulator!", Color.Lime); Console.Beep(600, 250); }
                else { UpdateStatus("FIX64: No BlueStacks folder! Admin?", Color.Red); chkChamsFix64.Checked = false; }
                await System.Threading.Tasks.Task.Delay(1);
            }
            catch (Exception ex) { UpdateStatus("FIX64 error: " + ex.Message, Color.Red); chkChamsFix64.Checked = false; }
    }
}
        }
