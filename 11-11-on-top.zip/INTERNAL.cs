﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Security.Principal;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace AYUSH
{
    public class INTERNAL
    {
        #region WinAPI Imports
        [DllImport("kernel32.dll")]
        private static extern void GetSystemInfo(out SYSTEM_INFO lpSystemInfo);

        [DllImport("kernel32.dll")]
        public static extern IntPtr OpenProcess(uint dwDesiredAccess, bool bInheritHandle, int dwProcessId);

        [DllImport("kernel32.dll")]
        public static extern bool IsWow64Process(IntPtr hProcess, out bool lpSystemInfo);

        [DllImport("kernel32.dll", EntryPoint = "ReadProcessMemory")]
        private static extern bool ReadProcessMemoryNative(IntPtr hProcess, IntPtr lpBaseAddress, [Out] byte[] lpBuffer, IntPtr nSize, out IntPtr lpNumberOfBytesRead);

        [DllImport("kernel32.dll", EntryPoint = "WriteProcessMemory")]
        private static extern bool WriteProcessMemoryNative(IntPtr hProcess, IntPtr lpBaseAddress, byte[] lpBuffer, IntPtr nSize, out IntPtr lpNumberOfBytesWritten);

        [DllImport("kernel32.dll")]
        public static extern int CloseHandle(IntPtr hObject);

        [DllImport("kernel32.dll", EntryPoint = "VirtualQueryEx")]
        public static extern UIntPtr Native_VirtualQueryEx(IntPtr hProcess, UIntPtr lpAddress, out MEMORY_BASIC_INFORMATION64 lpBuffer, UIntPtr dwLength);

        [DllImport("ntdll.dll", SetLastError = true)]
        private static extern uint NtReadVirtualMemory(IntPtr ProcessHandle, IntPtr BaseAddress, [Out] byte[] Buffer, uint BufferSize, out uint NumberOfBytesRead);

        [DllImport("ntdll.dll", SetLastError = true)]
        private static extern uint NtWriteVirtualMemory(IntPtr ProcessHandle, IntPtr BaseAddress, byte[] Buffer, uint BufferSize, out uint NumberOfBytesWritten);

        [DllImport("ntdll.dll", SetLastError = true)]
        private static extern int NtSetInformationProcess(IntPtr ProcessHandle, int ProcessInformationClass, ref int ProcessInformation, int ProcessInformationLength);

        [DllImport("kernel32.dll")]
        private static extern IntPtr GetCurrentProcess();

        [DllImport("kernel32.dll")]
        private static extern bool SetPriorityClass(IntPtr hProcess, uint dwPriorityClass);

        [DllImport("kernel32.dll")]
        private static extern bool OpenProcessToken(IntPtr ProcessHandle, uint DesiredAccess, out IntPtr TokenHandle);

        [DllImport("kernel32.dll")]
        private static extern bool LookupPrivilegeValue(string lpSystemName, string lpName, out LUID lpLuid);

        [DllImport("kernel32.dll")]
        private static extern bool AdjustTokenPrivileges(IntPtr TokenHandle, bool DisableAllPrivileges, ref TOKEN_PRIVILEGES NewState, uint BufferLength, IntPtr PreviousState, IntPtr ReturnLength);

        [DllImport("kernel32.dll")]
        private static extern IntPtr GetModuleHandle(string lpModuleName);

        [DllImport("kernel32.dll")]
        private static extern IntPtr GetProcAddress(IntPtr hModule, string lpProcName);

        [DllImport("kernel32.dll")]
        private static extern bool VirtualProtect(IntPtr lpAddress, uint dwSize, uint flNewProtect, out uint lpflOldProtect);

        [DllImport("kernel32.dll")]
        private static extern bool SetThreadPriority(IntPtr hThread, int nPriority);

        [DllImport("kernel32.dll")]
        private static extern IntPtr GetCurrentThread();
        #endregion

        #region Structs
        [StructLayout(LayoutKind.Sequential)]
        public struct MEMORY_BASIC_INFORMATION64
        {
            public UIntPtr BaseAddress;
            public UIntPtr AllocationBase;
            public uint AllocationProtect;
            public uint __alignment1;
            public ulong RegionSize;
            public uint State;
            public uint Protect;
            public uint Type;
            public uint __alignment2;
        }

        public struct MEMORY_BASIC_INFORMATION
        {
            public UIntPtr BaseAddress;
            public UIntPtr AllocationBase;
            public uint AllocationProtect;
            public long RegionSize;
            public uint State;
            public uint Protect;
            public uint Type;
        }

        public struct SYSTEM_INFO
        {
            public ushort processorArchitecture;
            private ushort reserved;
            public uint pageSize;
            public UIntPtr minimumApplicationAddress;
            public UIntPtr maximumApplicationAddress;
            public IntPtr activeProcessorMask;
            public uint numberOfProcessors;
            public uint processorType;
            public uint allocationGranularity;
            public ushort processorLevel;
            public ushort processorRevision;
        }

        [StructLayout(LayoutKind.Sequential)]
        private struct LUID { public uint LowPart; public int HighPart; }

        [StructLayout(LayoutKind.Sequential)]
        private struct LUID_AND_ATTRIBUTES { public LUID Luid; public uint Attributes; }

        [StructLayout(LayoutKind.Sequential)]
        private struct TOKEN_PRIVILEGES
        {
            public uint PrivilegeCount;
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
            public LUID_AND_ATTRIBUTES[] Privileges;
        }
        #endregion

        #region Fields
        public Process theProc = null;
        public IntPtr pHandle;
        private bool _is64Bit;
        public bool Is64Bit { get => _is64Bit; private set => _is64Bit = value; }

        private List<MEMORY_BASIC_INFORMATION> _cachedRegions = null;
        private DateTime _cacheTime = DateTime.MinValue;
        private const int CACHE_DURATION_MS = 10000;

        // 🔥 LOW-END PC KE LIYE OPTIMIZED
        private const int BUFFER_SIZE = 5 * 1024 * 1024; // 5 MB (RAM friendly)
        private static int MAX_PARALLELISM = Math.Max(2, Environment.ProcessorCount); // CPU cores ke hisab se

        private const uint PROCESS_ALL_ACCESS = 0x1F0FFF;
        private const uint MEM_COMMIT = 0x1000;
        private const uint PAGE_NOACCESS = 0x01;
        private const uint PAGE_GUARD = 0x100;

        private const uint HIGH_PRIORITY_CLASS = 0x00000080;
        private const uint NORMAL_PRIORITY_CLASS = 0x00000020;
        private const int THREAD_PRIORITY_TIME_CRITICAL = 15;
        private const int THREAD_PRIORITY_NORMAL = 0;
        #endregion

        #region Constructor
        public INTERNAL()
        {
            EnableDebugPrivilege();
            PatchETW();
            HideFromTaskManager();
        }

        private void EnableDebugPrivilege()
        {
            try
            {
                IntPtr hToken;
                IntPtr currentProcess = GetCurrentProcess();

                if (!OpenProcessToken(currentProcess, 0x0020 | 0x0008, out hToken))
                    return;

                LUID luid;
                if (LookupPrivilegeValue(null, "SeDebugPrivilege", out luid))
                {
                    TOKEN_PRIVILEGES tp = new TOKEN_PRIVILEGES
                    {
                        PrivilegeCount = 1,
                        Privileges = new LUID_AND_ATTRIBUTES[1]
                        {
                            new LUID_AND_ATTRIBUTES { Luid = luid, Attributes = 0x2 }
                        }
                    };
                    AdjustTokenPrivileges(hToken, false, ref tp, 0, IntPtr.Zero, IntPtr.Zero);
                }

                CloseHandle(hToken);
            }
            catch { }
        }

        private void PatchETW()
        {
            try
            {
                IntPtr ntdll = GetModuleHandle("ntdll.dll");
                if (ntdll == IntPtr.Zero) return;

                IntPtr etwFunc = GetProcAddress(ntdll, "EtwEventWrite");
                if (etwFunc == IntPtr.Zero) return;

                byte[] patch = new byte[] { 0x31, 0xC0, 0xC3 };
                uint oldProtect;
                VirtualProtect(etwFunc, (uint)patch.Length, 0x40, out oldProtect);
                Marshal.Copy(patch, 0, etwFunc, patch.Length);
                VirtualProtect(etwFunc, (uint)patch.Length, oldProtect, out _);
            }
            catch { }
        }

        private void HideFromTaskManager()
        {
            try
            {
                int hide = 1;
                NtSetInformationProcess(GetCurrentProcess(), 0x1F, ref hide, sizeof(int));
            }
            catch { }
        }
        #endregion

        #region 🔥 SPEED BOOST — NO FREEZE

        public void BoostCpuPriority()
        {
            try
            {
                SetPriorityClass(GetCurrentProcess(), HIGH_PRIORITY_CLASS);
                SetThreadPriority(GetCurrentThread(), THREAD_PRIORITY_TIME_CRITICAL);
            }
            catch { }
        }

        public void RestoreCpuPriority()
        {
            try
            {
                SetPriorityClass(GetCurrentProcess(), NORMAL_PRIORITY_CLASS);
                SetThreadPriority(GetCurrentThread(), THREAD_PRIORITY_NORMAL);
            }
            catch { }
        }
        #endregion

        #region VirtualQuery Wrapper
        public UIntPtr VirtualQueryEx(IntPtr hProcess, UIntPtr lpAddress, out MEMORY_BASIC_INFORMATION lpBuffer)
        {
            MEMORY_BASIC_INFORMATION64 info64;
            UIntPtr result = Native_VirtualQueryEx(hProcess, lpAddress, out info64, new UIntPtr((uint)Marshal.SizeOf(typeof(MEMORY_BASIC_INFORMATION64))));
            lpBuffer = new MEMORY_BASIC_INFORMATION
            {
                BaseAddress = info64.BaseAddress,
                AllocationBase = info64.AllocationBase,
                AllocationProtect = info64.AllocationProtect,
                RegionSize = (long)info64.RegionSize,
                State = info64.State,
                Protect = info64.Protect,
                Type = info64.Type
            };
            return result;
        }
        #endregion

        #region Process Management
        public bool IsAdmin()
        {
            using (WindowsIdentity identity = WindowsIdentity.GetCurrent())
            {
                return new WindowsPrincipal(identity).IsInRole(WindowsBuiltInRole.Administrator);
            }
        }

        public bool OpenProcess(int pid)
        {
            if (pid <= 0) return false;
            try
            {
                if (this.theProc != null && this.theProc.Id == pid && this.pHandle != IntPtr.Zero) return true;

                this.theProc = Process.GetProcessById(pid);
                if (this.theProc == null) return false;

                this.pHandle = OpenProcess(PROCESS_ALL_ACCESS, false, pid);
                if (this.pHandle == IntPtr.Zero) return false;

                bool isWow64;
                IsWow64Process(this.pHandle, out isWow64);
                this.Is64Bit = (Environment.Is64BitOperatingSystem && !isWow64);

                _cachedRegions = null;
                _cachedRegionsAll = null;
                return true;
            }
            catch { return false; }
        }
        #endregion

        #region High Performance Scan
        private struct PatternData
        {
            public byte[] Bytes;
            public byte[] Mask;
            public int Length;
            public bool Valid;
        }

        private PatternData ParsePattern(string patternString)
        {
            if (string.IsNullOrWhiteSpace(patternString))
                return new PatternData { Valid = false };

            var parts = patternString.Split(new[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
            var p = new PatternData
            {
                Bytes = new byte[parts.Length],
                Mask = new byte[parts.Length],
                Length = parts.Length,
                Valid = true
            };

            for (int i = 0; i < parts.Length; i++)
            {
                if (parts[i] == "??" || parts[i] == "?")
                {
                    p.Mask[i] = 0x00;
                    p.Bytes[i] = 0x00;
                }
                else
                {
                    p.Mask[i] = 0xFF;
                    p.Bytes[i] = Convert.ToByte(parts[i], 16);
                }
            }
            return p;
        }

        private List<MEMORY_BASIC_INFORMATION> _cachedRegionsAll = null;
        private DateTime _cacheTimeAll = DateTime.MinValue;

        private List<MEMORY_BASIC_INFORMATION> GetMemoryRegions(bool allRegions = false)
        {
            if (!allRegions)
            {
                if (_cachedRegions != null && (DateTime.Now - _cacheTime).TotalMilliseconds < CACHE_DURATION_MS)
                    return _cachedRegions;
            }
            else
            {
                if (_cachedRegionsAll != null && (DateTime.Now - _cacheTimeAll).TotalMilliseconds < CACHE_DURATION_MS)
                    return _cachedRegionsAll;
            }

            var memoryRegions = new List<MEMORY_BASIC_INFORMATION>();
            GetSystemInfo(out SYSTEM_INFO sysInfo);

            ulong minStart = sysInfo.minimumApplicationAddress.ToUInt64();
            ulong maxEnd = sysInfo.maximumApplicationAddress.ToUInt64();
            UIntPtr currentAddr = new UIntPtr(minStart);

            while (currentAddr.ToUInt64() < maxEnd)
            {
                if (VirtualQueryEx(pHandle, currentAddr, out MEMORY_BASIC_INFORMATION mem) == UIntPtr.Zero)
                    break;

                bool isCommit = mem.State == MEM_COMMIT;
                bool isAccessible = (mem.Protect & PAGE_NOACCESS) == 0 && (mem.Protect & PAGE_GUARD) == 0;

                if (isCommit && isAccessible)
                {
                    bool isWritable = (mem.Protect & 0x04) > 0 || (mem.Protect & 0x40) > 0;
                    if (allRegions || isWritable)
                        memoryRegions.Add(mem);
                }

                currentAddr = new UIntPtr(currentAddr.ToUInt64() + (ulong)mem.RegionSize);
            }

            if (allRegions) { _cachedRegionsAll = memoryRegions; _cacheTimeAll = DateTime.Now; }
            else { _cachedRegions = memoryRegions; _cacheTime = DateTime.Now; }
            return memoryRegions;
        }

        /// <summary>
        /// 🔥 ULTRA FAST AoB Scan — LOW-END PC OPTIMIZED
        /// </summary>
        public Task<IEnumerable<long>> AoBScan(string search, bool writable = true, bool executable = false, string file = "", bool allRegions = false)
        {
            return Task.Run(() =>
            {
                var foundAddresses = new ConcurrentBag<long>();
                var pattern = ParsePattern(search);
                if (!pattern.Valid) return (IEnumerable<long>)foundAddresses;

                // 🔥 BOOST CPU
                BoostCpuPriority();

                try
                {
                    var memoryRegions = GetMemoryRegions(allRegions);
                    if (memoryRegions.Count == 0) return foundAddresses;

                    // 🔥 LOW-END PC KE LIYE — CPU cores ke hisab se parallelism
                    int parallelism = Math.Max(2, Environment.ProcessorCount);

                    Parallel.ForEach(memoryRegions, new ParallelOptions { MaxDegreeOfParallelism = parallelism }, (region) =>
                    {
                        if (region.RegionSize <= 0 || region.RegionSize > int.MaxValue) return;

                        ulong regionSize = (ulong)region.RegionSize;
                        ulong bytesRead = 0;
                        byte[] buffer = new byte[BUFFER_SIZE];

                        while (bytesRead < regionSize)
                        {
                            int toRead = (int)Math.Min(BUFFER_SIZE, regionSize - bytesRead);
                            IntPtr readAddr = new IntPtr((long)(region.BaseAddress.ToUInt64() + bytesRead));

                            uint ntBytesRead;
                            uint status = NtReadVirtualMemory(pHandle, readAddr, buffer, (uint)toRead, out ntBytesRead);

                            if (status != 0)
                            {
                                IntPtr bytesReadPtr;
                                if (!ReadProcessMemoryNative(pHandle, readAddr, buffer, (IntPtr)toRead, out bytesReadPtr))
                                    break;
                            }

                            unsafe
                            {
                                fixed (byte* pBuffer = buffer)
                                fixed (byte* pPattern = pattern.Bytes)
                                fixed (byte* pMask = pattern.Mask)
                                {
                                    int limit = toRead - pattern.Length;
                                    for (int i = 0; i <= limit; i++)
                                    {
                                        if (pMask[0] == 0xFF && pBuffer[i] != pPattern[0]) continue;

                                        bool match = true;
                                        for (int j = 1; j < pattern.Length; j++)
                                        {
                                            if (pMask[j] == 0xFF && pBuffer[i + j] != pPattern[j])
                                            {
                                                match = false;
                                                break;
                                            }
                                        }

                                        if (match)
                                        {
                                            foundAddresses.Add((long)region.BaseAddress.ToUInt64() + (long)bytesRead + i);
                                        }
                                    }
                                }
                            }

                            bytesRead += (ulong)toRead;
                        }
                    });

                    return (IEnumerable<long>)foundAddresses;
                }
                finally
                {
                    RestoreCpuPriority();
                }
            });
        }
        #endregion

        #region Helpers
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public bool WriteMemory(string address, string type, string value, string offset = "")
        {
            try
            {
                if (pHandle == IntPtr.Zero) return false;

                long addrVal = Convert.ToInt64(address, 16);
                if (!string.IsNullOrEmpty(offset)) addrVal += Convert.ToInt64(offset, 16);

                IntPtr target = new IntPtr(addrVal);
                byte[] data = null;

                switch (type.ToLower())
                {
                    case "int": data = BitConverter.GetBytes(int.Parse(value)); break;
                    case "float": data = BitConverter.GetBytes(float.Parse(value)); break;
                    case "double": data = BitConverter.GetBytes(double.Parse(value)); break;
                    case "long": data = BitConverter.GetBytes(long.Parse(value)); break;
                    case "string": data = Encoding.UTF8.GetBytes(value); break;
                    case "byte": data = new byte[] { byte.Parse(value) }; break;
                    case "hex":
                        string[] hex = value.Split(' ');
                        data = new byte[hex.Length];
                        for (int i = 0; i < hex.Length; i++) data[i] = Convert.ToByte(hex[i], 16);
                        break;
                }

                if (data != null)
                {
                    uint bytesWritten;
                    uint status = NtWriteVirtualMemory(pHandle, target, data, (uint)data.Length, out bytesWritten);
                    if (status == 0 && bytesWritten == data.Length)
                        return true;

                    IntPtr bytesWrittenPtr;
                    return WriteProcessMemoryNative(pHandle, target, data, (IntPtr)data.Length, out bytesWrittenPtr);
                }
            }
            catch { }
            return false;
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public int ReadInt(long address)
        {
            try
            {
                byte[] buffer = new byte[4];
                uint bytesRead;
                uint status = NtReadVirtualMemory(pHandle, new IntPtr(address), buffer, 4, out bytesRead);
                if (status == 0)
                    return BitConverter.ToInt32(buffer, 0);

                IntPtr bytesReadPtr;
                ReadProcessMemoryNative(pHandle, new IntPtr(address), buffer, (IntPtr)4, out bytesReadPtr);
                return BitConverter.ToInt32(buffer, 0);
            }
            catch { return 0; }
        }

        public Task<IEnumerable<long>> AoBScan2(string search, bool writable = false, bool executable = false, string file = "")
        {
            return AoBScan(search, writable, executable, file);
        }

        // ★★★ FEATURE: ESP OVERLAY read primitives
        //     ADDITIVE ONLY — aimbot / AoB / WriteMemory code touch pannala
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public float ReadFloat(long address)
        {
            try
            {
                byte[] buffer = new byte[4];
                uint bytesRead;
                if (NtReadVirtualMemory(pHandle, new IntPtr(address), buffer, 4, out bytesRead) == 0 && bytesRead == 4)
                    return BitConverter.ToSingle(buffer, 0);

                IntPtr bytesReadPtr;
                ReadProcessMemoryNative(pHandle, new IntPtr(address), buffer, (IntPtr)4, out bytesReadPtr);
                return BitConverter.ToSingle(buffer, 0);
            }
            catch { return 0f; }
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public long ReadPtr(long address)
        {
            try
            {
                byte[] buffer = new byte[8];
                uint bytesRead;
                if (NtReadVirtualMemory(pHandle, new IntPtr(address), buffer, 8, out bytesRead) == 0 && bytesRead == 8)
                    return BitConverter.ToInt64(buffer, 0);

                IntPtr bytesReadPtr;
                ReadProcessMemoryNative(pHandle, new IntPtr(address), buffer, (IntPtr)8, out bytesReadPtr);
                return BitConverter.ToInt64(buffer, 0);
            }
            catch { return 0; }
        }

        public bool ReadBytes(long address, byte[] buffer)
        {
            try
            {
                uint bytesRead;
                if (NtReadVirtualMemory(pHandle, new IntPtr(address), buffer, (uint)buffer.Length, out bytesRead) == 0 && bytesRead == (uint)buffer.Length)
                    return true;

                IntPtr bytesReadPtr;
                ReadProcessMemoryNative(pHandle, new IntPtr(address), buffer, (IntPtr)buffer.Length, out bytesReadPtr);
                return bytesReadPtr.ToInt64() == buffer.Length;
            }
            catch { return false; }
        }

        public float ReadFloat(long address, int offset)
        {
            return ReadFloat(address + offset);
        }

        public long ReadPtr(long address, int offset)
        {
            return ReadPtr(address + offset);
        }
        #endregion
    }
}