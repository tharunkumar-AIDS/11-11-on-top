﻿using AYUSH;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Gma.System.MouseKeyHook;
using DiscordRPC;
using FAST_MEMORY;
using Nazmulscope;

namespace zafkialontop
{
    public partial class Form1 : Form
    {
        // ═══════════════════════════════════════════════════════════════
        // 11:11 ON TOP — FEATURE MAP (section files: Test.cs mari taniya)
        //  ★ AIMBOT      : Aimbot.cs — pattern + RunAimbotScan + INJECT button + aim hotkey
        //  ★ CHAMS       : Chams.cs — CHAMSMENU.dll download + inject (LOCATION button)
        //  ★ EXTERNAL    : External.cs — Sniper Scope/Switch + Glitch + Speed (AoB patterns)
        //  ★ SETTINGS    : Settings.cs — Theme(+custom) + Streamer + Hide key + Ping/FPS
        //  ★ BYPASS      : Bypass.cs — Hyper-V check/fix + Emulator auto-launch/kill
        //  ★ TEST        : Test.cs — KXC port (AYUSH backend)
        //  ★ CORE (ingga): emulator find + nav + hotkey poll + Discord + glow timer + UpdateStatus
        // ═══════════════════════════════════════════════════════════════




        public static INTERNAL AYUSH = new INTERNAL();


        // FIX: Win11/MSI la process name vera mari irukkum — list la thedu
        // v2: MSI App Player + BlueStacks ENDAA version naalum work aaganum:
        //     1) known process names  2) window title  3) install folder path
        private static readonly string[] EmulatorNames = new string[]
        {
            "HD-Player", "HD-Player64", "MsiPlayer", "MsiPlayer64",
            "Bluestacks", "BlueStacksApp", "BlueStacks", "aow_exe", "BstkVM"
        };

        private static Process FindEmulator()
        {
            // Pass 1: known names (BS4/BS5/BSX/MSI — ella versionukkum)
            foreach (string n in EmulatorNames)
            {
                try
                {
                    var p = Process.GetProcessesByName(n).FirstOrDefault();
                    if (p != null) return p;
                }
                catch { }
            }

            // Pass 2: NEW version la name maathirundhalum window title-la kedaikkum
            //   ("BlueStacks 5", "MSI App Player 5" etc.)
            try
            {
                foreach (var p in Process.GetProcesses())
                {
                    try
                    {
                        if (p.MainWindowHandle == IntPtr.Zero) continue;
                        string t = p.MainWindowTitle ?? "";
                        if (t.Contains("BlueStacks") || t.Contains("MSI App Player")) return p;
                    }
                    catch { }
                }
            }
            catch { }

            // Pass 3: folder path-la thedu (BlueStacks_msi5 / BlueStacks_nxt / MSI App Player
            //   — install path version maathalum idhu work aagum)
            try
            {
                foreach (var p in Process.GetProcesses())
                {
                    try
                    {
                        if (p.MainWindowHandle == IntPtr.Zero) continue;
                        string path = "";
                        try { path = (p.MainModule.FileName ?? "").ToLower(); } catch { }
                        if (path.Contains("bluestacks") || path.Contains("msi app player"))
                            return p;
                    }
                    catch { }
                }
            }
            catch { }

            return null;
        }

        private static string EmuName()
        {
            try
            {
                var p = FindEmulator();
                if (p != null) return p.ProcessName;
            }
            catch { }
            return "HD-Player";
        }

        // ★★★ CORE: Hide hotkey + Aimbot hotkey (global key poll, 50ms timer)
        // ============ HOTKEY HIDE (CUSTOM KEY = MAIN) ============
        [DllImport("user32.dll")]
        public static extern short GetAsyncKeyState(int vKey);
        [DllImport("user32.dll")]
        public static extern bool SetWindowDisplayAffinity(IntPtr hwnd, uint affinity);

        // ★★★ CORE: Discord Rich Presence (profile activity status)
        // ============ DISCORD ACTIVITY (RICH PRESENCE) ============
        // discord.com/developers/applications la app create panni Application ID ah inga podu
        private const string DiscordAppId = "1554829164631031908";
        private DiscordRpcClient discordClient;
        private System.Windows.Forms.Timer rpcTimer;
        private Keys hideKey = Keys.None;
        private bool isHidden = false;
        private bool wasHidePressed = false;
        private System.Windows.Forms.Timer hotkeyTimer;
        private IKeyboardMouseEvents keyHook;

        public Form1()
        {
            InitializeComponent();
            // ★ FIX: Guna shadow = tani LAYERED window → WDA capture exclusion work aagadhu
            //   → stream capture la gray outline leak. Shadow window create aagave aagadhu.
            guna2BorderlessForm1.HasFormShadow = false;
            this.Icon = System.Drawing.Icon.ExtractAssociatedIcon(System.Windows.Forms.Application.ExecutablePath);
            ResetPanelLayout();
            LoadTheme();
            InitSettingsIO();   // ★ settings save/load + log viewer wiring (ApplyTheme ku munnadi)
            ApplyTheme();
            InitUiResize();
            DoubleBuffered = true;
            StartStatusTimer();
            hotkeyTimer = new System.Windows.Forms.Timer { Interval = 50 };
            hotkeyTimer.Tick += HotkeyTimer_Tick;
            hotkeyTimer.Start();
            this.Shown += Form1_Shown;
            this.FormClosing += Form1_FormClosing;
        }

        // ★★★ CORE: Layout safety net (Designer == output)
        //   Panels stacked (150,35), form (760,520) — Designer layum output layum same.
        //   Designer la thavari drag aanaalum inga runtime la correct aayidum.
        //   EDIT WORKFLOW: Document Outline (View → Other Windows) la panel/child
        //   click panni select pannu → Properties window la Text/position edit pannu.
        //   Form outer edge ah drag pannadha. Visible ah kai vaiyadha (ShowSection paar).
        private void ResetPanelLayout()
        {
            this.ClientSize = new System.Drawing.Size(760, 520);
            System.Drawing.Point contentLoc = new System.Drawing.Point(150, 35);
            System.Drawing.Size contentSize = new System.Drawing.Size(610, 450);
            System.Windows.Forms.Panel[] pages = { pnlAimbot, pnlFfMax, pnlChams, pnlExternal, pnlSettings, pnlBypass, pnlTest };
            foreach (var pg in pages)
            {
                if (pg == null) continue;
                pg.Location = contentLoc;
                pg.Size = contentSize;
            }
            if (pnlBottom != null)
            {
                pnlBottom.Location = new System.Drawing.Point(0, 485);
                pnlBottom.Size = new System.Drawing.Size(760, 35);
            }
            ShowSection(currentSection);
        }

        private void Form1_Shown(object sender, EventArgs e)
        {
            ApplyStreamerMode();
            InitDiscordPresence();
        }

        private void InitDiscordPresence()
        {
            try
            {
                if (DiscordAppId == "PUT_YOUR_CLIENT_ID_HERE" || string.IsNullOrWhiteSpace(DiscordAppId))
                    return;
                discordClient = new DiscordRpcClient(DiscordAppId);
                discordClient.Initialize();
                discordClient.SetPresence(new RichPresence()
                {
                    Details = "11:11 External Panel",
                    State = "Free Fire Lobby",
                    Timestamps = Timestamps.Now
                });
                rpcTimer = new System.Windows.Forms.Timer { Interval = 2000 };
                rpcTimer.Tick += (sender, args) => { try { discordClient?.Invoke(); } catch { } };
                rpcTimer.Start();
            }
            catch { }
        }

        private void SetDiscordState(string state)
        {
            try
            {
                discordClient?.SetPresence(new RichPresence()
                {
                    Details = "11:11 External Panel",
                    State = state,
                    Timestamps = Timestamps.Now
                });
            }
            catch { }
        }


        private void HotkeyTimer_Tick(object sender, EventArgs e)
        {
            if (hideKey != Keys.None)
            {
                bool pressed = (GetAsyncKeyState((int)hideKey) & 0x8000) != 0;
                if (pressed && !wasHidePressed)
                {
                    if (!isHidden) { this.Hide(); this.ShowInTaskbar = false; isHidden = true; }
                    else { this.Show(); this.ShowInTaskbar = true; this.WindowState = FormWindowState.Normal; this.BringToFront(); this.Activate(); isHidden = false; }
                }
                wasHidePressed = pressed;
            }

            // AIMBOT HOTKEY (PER MATCH only)
            if (aimKeyMatch != Keys.None)
            {
                bool p = (GetAsyncKeyState((int)aimKeyMatch) & 0x8000) != 0;
                if (p && !wasAimMatchPressed) { RunAimbotHotkey(); }
                wasAimMatchPressed = p;
            }

            // FF MAX AIM HOTKEY (PER MATCH only)
            if (ffMaxKey != Keys.None)
            {
                bool pf = (GetAsyncKeyState((int)ffMaxKey) & 0x8000) != 0;
                if (pf && !wasFfMaxPressed) { RunFfMaxHotkey(); }
                wasFfMaxPressed = pf;
            }
        }



        // ★★★ CORE: Sidebar nav (AIMBOT/CHAMS/EXTERNAL/SETTINGS/BYPASS/ESP panels)
        // ============ SIDEBAR SECTIONS ============
        private string currentSection = "aimbot";
        private System.Drawing.Color navOnColor = System.Drawing.Color.Maroon;
        private System.Drawing.Color navOffColor = System.Drawing.Color.FromArgb(30, 30, 30);
        private System.Drawing.Color navTextColor = System.Drawing.Color.White;

        private void ShowSection(string name)
        {
            currentSection = name;
            pnlAimbot.Visible = (name == "aimbot");
            pnlChams.Visible = (name == "chams");
            pnlExternal.Visible = (name == "external");
            pnlSettings.Visible = (name == "settings");
            pnlBypass.Visible = (name == "bypass");
            pnlTest.Visible = (name == "test");
            pnlFfMax.Visible = (name == "ffmax");   // Designer control — eppavume non-null
            btnNavAimbot.FillColor = (name == "aimbot") ? navOnColor : navOffColor;
            btnNavFfMax.FillColor = (name == "ffmax") ? navOnColor : navOffColor;
            btnNavFfMax.ForeColor = (name == "ffmax") ? System.Drawing.Color.White : navTextColor;
            btnNavChams.FillColor = (name == "chams") ? navOnColor : navOffColor;
            btnNavExternal.FillColor = (name == "external") ? navOnColor : navOffColor;
            btnNavSettings.FillColor = (name == "settings") ? navOnColor : navOffColor;
            btnNavBypass.FillColor = (name == "bypass") ? navOnColor : navOffColor;
            btnNavTest.FillColor = (name == "test") ? navOnColor : navOffColor;
            btnNavAimbot.ForeColor = (name == "aimbot") ? System.Drawing.Color.White : navTextColor;
            btnNavChams.ForeColor = (name == "chams") ? System.Drawing.Color.White : navTextColor;
            btnNavExternal.ForeColor = (name == "external") ? System.Drawing.Color.White : navTextColor;
            btnNavSettings.ForeColor = (name == "settings") ? System.Drawing.Color.White : navTextColor;
            btnNavBypass.ForeColor = (name == "bypass") ? System.Drawing.Color.White : navTextColor;
            btnNavTest.ForeColor = (name == "test") ? System.Drawing.Color.White : navTextColor;
        }

        private void btnNavAimbot_Click(object sender, EventArgs e) { ShowSection("aimbot"); }

        private void btnNavChams_Click(object sender, EventArgs e) { ShowSection("chams"); }
        private void btnNavExternal_Click(object sender, EventArgs e) { ShowSection("external"); }
        private void btnNavSettings_Click(object sender, EventArgs e) { ShowSection("settings"); }
        private void btnNavBypass_Click(object sender, EventArgs e) { ShowSection("bypass"); }
        private void btnNavTest_Click(object sender, EventArgs e) { ShowSection("test"); }





        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            try { frames++; } catch { }
            e.Graphics.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
        }

        // FIX: Windows DWM drop-shadow capture la outline ah kaatum — class level la off
        protected override CreateParams CreateParams
        {
            get
            {
                const int CS_DROPSHADOW = 0x00020000;
                CreateParams cp = base.CreateParams;
                cp.ClassStyle &= ~CS_DROPSHADOW;
                return cp;
            }
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)        {
            try
            {
                scopeHook?.Dispose();
                if (sniperAddresses.Count > 0) { byte[] o = ParseHex(sniperSearch); foreach (var a in sniperAddresses) sniperMem.WriteBytes(a, o); }
                if (switchAddresses.Count > 0) foreach (var a in switchAddresses) nazmulscope.AobReplace(a, switchSearch);
                if (glitchAddresses.Count > 0) foreach (var a in glitchAddresses) hackMem.WriteBytes(a, ParseHex(glitchSearch));
                if (speedAddresses.Count > 0) { byte[] o = ParseHex(speedSearch); foreach (var a in speedAddresses) hackMem.WriteBytes(a, o); }
            }
            catch { }
            if (hotkeyTimer != null)
            {
                hotkeyTimer.Stop();
                hotkeyTimer.Dispose();
            }
            if (keyHook != null)
            {
                keyHook.Dispose();
            }
            if (aimKeyHook != null)
            {
                try { aimKeyHook.Dispose(); } catch { }
            }
            try
            {
                if (rpcTimer != null) { rpcTimer.Stop(); rpcTimer.Dispose(); }
                if (statusTimer != null) { try { statusTimer.Stop(); statusTimer.Dispose(); } catch { } }
                if (discordClient != null) { discordClient.Dispose(); discordClient = null; }
            }
            catch { }
        }





       
















        private void label2_Click(object sender, EventArgs e)
        {

        }







        [DllImport("kernel32.dll")]
        public static extern IntPtr OpenProcess(int dwDesiredAccess, bool bInheritHandle, int dwProcessId);
        [DllImport("kernel32", CharSet = CharSet.Ansi, ExactSpelling = true, SetLastError = true)]
        static extern IntPtr GetProcAddress(IntPtr hModule, string procName);
        [DllImport("kernel32.dll", SetLastError = true, ExactSpelling = true)]
        static extern IntPtr VirtualAllocEx(IntPtr hProcess, IntPtr lpAddress,
        uint dwSize, uint flAllocationType, uint flProtect);
        [DllImport("kernel32.dll", SetLastError = true)]
        static extern bool WriteProcessMemory(IntPtr hProcess, IntPtr lpBaseAddress, byte[] lpBuffer, uint nSize, out UIntPtr lpNumberOfBytesWritten);
        [DllImport("kernel32.dll")]
        static extern IntPtr CreateRemoteThread(IntPtr hProcess, IntPtr lpThreadAttributes, uint dwStackSize, IntPtr lpStartAddress, IntPtr lpParameter, uint dwCreationFlags, IntPtr lpThreadId);
        [DllImport("kernel32.dll", SetLastError = true)]
        static extern uint WaitForSingleObject(IntPtr hHandle, uint dwMilliseconds);
        [DllImport("kernel32.dll", SetLastError = true)]
        static extern bool GetExitCodeThread(IntPtr hThread, out uint lpExitCode);
        const int PROCESS_CREATE_THREAD = 0x0002;
        const int PROCESS_QUERY_INFORMATION = 0x0400;
        const int PROCESS_VM_OPERATION = 0x0008;
        const int PROCESS_VM_WRITE = 0x0020;
        const int PROCESS_VM_READ = 0x0010;
        const uint MEM_COMMIT = 0x00001000;
        const uint MEM_RESERVE = 0x00002000;
        const uint PAGE_READWRITE = 4;

        [DllImport("kernel32.dll", CharSet = CharSet.Auto)]
        public static extern IntPtr GetModuleHandle(string lpModuleName);
        [DllImport("kernel32.dll", SetLastError = true)]
        static extern bool CloseSnapHandle(IntPtr hObject);











        private void UpdateStatus(string t, Color? c = null) { if (Sta.InvokeRequired) Sta.Invoke(new Action(() => UpdateStatus(t, c))); else { Sta.Text = t; if (c.HasValue) Sta.ForeColor = c.Value; NotifyToast(t, c); } }

        // Ellatukum toast: Green/Lime=success, Red=error, vera=info
        private void NotifyToast(string t, Color? c)
        {
            try
            {
                if (!c.HasValue) { Toast.Info("STATUS", t); return; }
                Color col = c.Value;
                if (col.ToArgb() == Color.Red.ToArgb()) Toast.Error("STATUS", t);
                else if (col.ToArgb() == Color.Lime.ToArgb() || col.ToArgb() == Color.Green.ToArgb()) Toast.Success("STATUS", t);
                else Toast.Info("STATUS", t);
            }
            catch { }
        }
        private byte[] ParseHex(string hex) { var p = hex.Split(' '); byte[] b = new byte[p.Length]; for (int i = 0; i < p.Length; i++) b[i] = p[i] == "??" || p[i] == "?" ? (byte)0 : Convert.ToByte(p[i], 16); return b; }


        private void shayanHeader1_Load(object sender, EventArgs e)
        {

        }

        private void lblHyperVal_Click(object sender, EventArgs e)
        {

        }
    }
}

