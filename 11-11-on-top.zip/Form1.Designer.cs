namespace zafkialontop
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.barAim = new System.Windows.Forms.Panel();
            this.divAim = new System.Windows.Forms.Panel();
            this.barFfMax = new System.Windows.Forms.Panel();
            this.divFfMax = new System.Windows.Forms.Panel();
            this.barChams = new System.Windows.Forms.Panel();
            this.divChams = new System.Windows.Forms.Panel();
            this.barExt = new System.Windows.Forms.Panel();
            this.divExt = new System.Windows.Forms.Panel();
            this.barSet = new System.Windows.Forms.Panel();
            this.divSet = new System.Windows.Forms.Panel();
            this.barBypass = new System.Windows.Forms.Panel();
            this.divBypass = new System.Windows.Forms.Panel();
            this.barTest = new System.Windows.Forms.Panel();
            this.divTest = new System.Windows.Forms.Panel();
            this.cardAimMatch = new System.Windows.Forms.Panel();
            this.cardAimRun = new System.Windows.Forms.Panel();
            this.cardFfMaxRow = new System.Windows.Forms.Panel();
            this.cardFfMaxRun = new System.Windows.Forms.Panel();
            this.cardChamsFix = new System.Windows.Forms.Panel();
            this.cardChamsTrans = new System.Windows.Forms.Panel();
            this.cardChamsRun = new System.Windows.Forms.Panel();
            this.cardScope = new System.Windows.Forms.Panel();
            this.cardGlitch = new System.Windows.Forms.Panel();
            this.cardSpeed = new System.Windows.Forms.Panel();
            this.cardSwitch = new System.Windows.Forms.Panel();
            this.cardScopeKey = new System.Windows.Forms.Panel();
            this.cardSetTheme = new System.Windows.Forms.Panel();
            this.cardSetAccent = new System.Windows.Forms.Panel();
            this.cardSetBg = new System.Windows.Forms.Panel();
            this.cardSetHide = new System.Windows.Forms.Panel();
            this.cardSetStream = new System.Windows.Forms.Panel();
            this.cardSetLog = new System.Windows.Forms.Panel();
            this.cardBpOb1 = new System.Windows.Forms.Panel();
            this.cardBpOb2 = new System.Windows.Forms.Panel();
            this.cardBpEmuAuto = new System.Windows.Forms.Panel();
            this.cardBpEmuKill = new System.Windows.Forms.Panel();
            this.cardBpHyper = new System.Windows.Forms.Panel();
            this.cardBpHyperFix = new System.Windows.Forms.Panel();
            this.cardTestSaim = new System.Windows.Forms.Panel();
            this.cardTest5566 = new System.Windows.Forms.Panel();
            this.cardTestSwitch = new System.Windows.Forms.Panel();
            this.lblAimMatchDesc = new System.Windows.Forms.Label();
            this.lblFfMaxDesc = new System.Windows.Forms.Label();
            this.lblChamsFixDesc = new System.Windows.Forms.Label();
            this.lblChamsTransDesc = new System.Windows.Forms.Label();
            this.lblScopeDesc = new System.Windows.Forms.Label();
            this.lblGlitchDesc = new System.Windows.Forms.Label();
            this.lblSpeedDesc = new System.Windows.Forms.Label();
            this.lblSwitchDesc = new System.Windows.Forms.Label();
            this.lblRowScopeKey = new System.Windows.Forms.Label();
            this.lblScopeKeyDesc = new System.Windows.Forms.Label();
            this.lblTestSaimDesc = new System.Windows.Forms.Label();
            this.lblTest5566Desc = new System.Windows.Forms.Label();
            this.lblTestSwitchDesc = new System.Windows.Forms.Label();
            this.lblExtInfo = new System.Windows.Forms.Label();
            this.guna2BorderlessForm1 = new Guna.UI2.WinForms.Guna2BorderlessForm(this.components);
            this.shayanHeader1 = new ShayanUI.ShayanHeader();
            this.pnlSide = new System.Windows.Forms.Panel();
            this.lblVerSide = new System.Windows.Forms.Label();
            this.btnNavBypass = new Guna.UI2.WinForms.Guna2Button();
            this.btnNavTest = new Guna.UI2.WinForms.Guna2Button();
            this.btnNavSettings = new Guna.UI2.WinForms.Guna2Button();
            this.btnNavExternal = new Guna.UI2.WinForms.Guna2Button();
            this.btnNavChams = new Guna.UI2.WinForms.Guna2Button();
            this.btnNavAimbot = new Guna.UI2.WinForms.Guna2Button();
            this.btnNavFfMax = new Guna.UI2.WinForms.Guna2Button();
            this.pnlAimbot = new System.Windows.Forms.Panel();
            this.pnlFfMax = new System.Windows.Forms.Panel();
            this.btnFfMaxRun = new Guna.UI2.WinForms.Guna2GradientButton();
            this.btnFfMaxKey = new Guna.UI2.WinForms.Guna2Button();
            this.lblFfMaxTitle = new System.Windows.Forms.Label();
            this.lblFfMaxInfo = new System.Windows.Forms.Label();
            this.lblFfMaxRow = new System.Windows.Forms.Label();
            this.btnAimKeyMatch = new Guna.UI2.WinForms.Guna2Button();
            this.lblRowAimMatch = new System.Windows.Forms.Label();
            this.lblAimInfo = new System.Windows.Forms.Label();
            this.btnAimRun = new Guna.UI2.WinForms.Guna2GradientButton();
            this.lblAimTitle = new System.Windows.Forms.Label();
            this.pnlChams = new System.Windows.Forms.Panel();
            this.lblChamsInfo = new System.Windows.Forms.Label();
            this.btnChamsRun = new Guna.UI2.WinForms.Guna2GradientButton();
            this.lblChamsTitle = new System.Windows.Forms.Label();
            this.chkChamsFix64 = new Guna.UI2.WinForms.Guna2CustomCheckBox();
            this.lblChamsFix64 = new System.Windows.Forms.Label();
            this.chkChamsTrans = new Guna.UI2.WinForms.Guna2CustomCheckBox();
            this.lblChamsTrans = new System.Windows.Forms.Label();
            this.pnlExternal = new System.Windows.Forms.Panel();
            this.chkSpeed = new Guna.UI2.WinForms.Guna2CustomCheckBox();
            this.lblSpeed = new System.Windows.Forms.Label();
            this.chkGlitch = new Guna.UI2.WinForms.Guna2CustomCheckBox();
            this.lblGlitch = new System.Windows.Forms.Label();
            this.chkSwitch = new Guna.UI2.WinForms.Guna2CustomCheckBox();
            this.lblSwitch = new System.Windows.Forms.Label();
            this.btnScopeKey = new Guna.UI2.WinForms.Guna2Button();
            this.chkScope = new Guna.UI2.WinForms.Guna2CustomCheckBox();
            this.lblScope = new System.Windows.Forms.Label();
            this.lblExtTitle = new System.Windows.Forms.Label();
            this.pnlSettings = new System.Windows.Forms.Panel();
            this.btnTheme = new Guna.UI2.WinForms.Guna2Button();
            this.btnAccentColor = new Guna.UI2.WinForms.Guna2Button();
            this.lblRowAccent = new System.Windows.Forms.Label();
            this.btnBgColor = new Guna.UI2.WinForms.Guna2Button();
            this.lblRowBgColor = new System.Windows.Forms.Label();
            this.lblRowTheme = new System.Windows.Forms.Label();
            this.btnHideKey = new Guna.UI2.WinForms.Guna2Button();
            this.lblRowHide = new System.Windows.Forms.Label();
            this.btnStreamer = new Guna.UI2.WinForms.Guna2Button();
            this.lblRowStream = new System.Windows.Forms.Label();
            this.lblSetTitle = new System.Windows.Forms.Label();
            this.lblRowLog = new System.Windows.Forms.Label();
            this.btnViewLog = new Guna.UI2.WinForms.Guna2Button();
            this.pnlTest = new System.Windows.Forms.Panel();
            this.chkTestSaim = new Guna.UI2.WinForms.Guna2CustomCheckBox();
            this.lblTestSaim = new System.Windows.Forms.Label();
            this.chkTestSwitch = new Guna.UI2.WinForms.Guna2CustomCheckBox();
            this.lblTestSwitch = new System.Windows.Forms.Label();
            this.chkTest5566 = new Guna.UI2.WinForms.Guna2CustomCheckBox();
            this.lblTest5566 = new System.Windows.Forms.Label();
            this.lblTestTitle = new System.Windows.Forms.Label();
            this.pnlBypass = new System.Windows.Forms.Panel();
            this.lblHyperVal = new System.Windows.Forms.Label();
            this.btnBypassOb1 = new Guna.UI2.WinForms.Guna2GradientButton();
            this.lblRowBypassOb1 = new System.Windows.Forms.Label();
            this.btnBypassOb2 = new Guna.UI2.WinForms.Guna2GradientButton();
            this.lblRowBypassOb2 = new System.Windows.Forms.Label();
            this.btnEmuAuto = new Guna.UI2.WinForms.Guna2GradientButton();
            this.lblRowEmuAuto = new System.Windows.Forms.Label();
            this.btnEmuKill = new Guna.UI2.WinForms.Guna2GradientButton();
            this.lblRowEmuKill = new System.Windows.Forms.Label();
            this.btnHyperFix = new Guna.UI2.WinForms.Guna2GradientButton();
            this.lblRowHyperFix = new System.Windows.Forms.Label();
            this.btnHyperCheck = new Guna.UI2.WinForms.Guna2Button();
            this.lblRowHyper = new System.Windows.Forms.Label();
            this.lblBypassTitle = new System.Windows.Forms.Label();
            this.pnlBottom = new System.Windows.Forms.Panel();
            this.lblFps = new System.Windows.Forms.Label();
            this.lblPing = new System.Windows.Forms.Label();
            this.Sta = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.pnlSide.SuspendLayout();
            this.pnlAimbot.SuspendLayout();
            this.pnlFfMax.SuspendLayout();
            this.pnlChams.SuspendLayout();
            this.pnlExternal.SuspendLayout();
            this.pnlSettings.SuspendLayout();
            this.pnlTest.SuspendLayout();
            this.pnlBypass.SuspendLayout();
            this.pnlBottom.SuspendLayout();
            this.SuspendLayout();
            // 
            // guna2BorderlessForm1
            // 
            this.guna2BorderlessForm1.ContainerControl = this;
            this.guna2BorderlessForm1.DockIndicatorTransparencyValue = 0.6D;
            this.guna2BorderlessForm1.ResizeForm = false;
            this.guna2BorderlessForm1.ShadowColor = System.Drawing.Color.Transparent;
            this.guna2BorderlessForm1.TransparentWhileDrag = true;
            // 
            // shayanHeader1
            // 
            this.shayanHeader1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(20)))), ((int)(((byte)(20)))));
            this.shayanHeader1.Dock = System.Windows.Forms.DockStyle.Top;
            this.shayanHeader1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.shayanHeader1.Location = new System.Drawing.Point(0, 0);
            this.shayanHeader1.Logo = global::zafkialontop.Properties.Resources.IMG_20260925_095320_643;
            this.shayanHeader1.Name = "shayanHeader1";
            this.shayanHeader1.Size = new System.Drawing.Size(760, 35);
            this.shayanHeader1.TabIndex = 15;
            this.shayanHeader1.Title = "11:11 ON TOP";
            this.shayanHeader1.Load += new System.EventHandler(this.shayanHeader1_Load);
            // 
            // pnlSide
            // 
            this.pnlSide.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(20)))), ((int)(((byte)(20)))));
            this.pnlSide.Controls.Add(this.lblVerSide);
            this.pnlSide.Controls.Add(this.btnNavBypass);
            this.pnlSide.Controls.Add(this.btnNavTest);
            this.pnlSide.Controls.Add(this.btnNavSettings);
            this.pnlSide.Controls.Add(this.btnNavExternal);
            this.pnlSide.Controls.Add(this.btnNavChams);
            this.pnlSide.Controls.Add(this.btnNavAimbot);
            this.pnlSide.Controls.Add(this.btnNavFfMax);
            this.pnlSide.Location = new System.Drawing.Point(0, 35);
            this.pnlSide.Name = "pnlSide";
            this.pnlSide.Size = new System.Drawing.Size(150, 450);
            this.pnlSide.TabIndex = 30;
            // 
            // lblVerSide
            // 
            this.lblVerSide.AutoSize = true;
            this.lblVerSide.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.lblVerSide.ForeColor = System.Drawing.Color.Red;
            this.lblVerSide.Location = new System.Drawing.Point(10, 420);
            this.lblVerSide.Name = "lblVerSide";
            this.lblVerSide.Size = new System.Drawing.Size(38, 15);
            this.lblVerSide.TabIndex = 4;
            this.lblVerSide.Text = "OB55";
            // 
            // btnNavBypass
            // 
            this.btnNavBypass.BorderRadius = 8;
            this.btnNavBypass.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.btnNavBypass.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.btnNavBypass.ForeColor = System.Drawing.Color.White;
            this.btnNavBypass.Location = new System.Drawing.Point(10, 244);
            this.btnNavBypass.Name = "btnNavBypass";
            this.btnNavBypass.Size = new System.Drawing.Size(130, 40);
            this.btnNavBypass.TabIndex = 5;
            this.btnNavBypass.Text = "BYPASS";
            this.btnNavBypass.Click += new System.EventHandler(this.btnNavBypass_Click);
            // 
            // btnNavTest
            // 
            this.btnNavTest.BorderRadius = 8;
            this.btnNavTest.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.btnNavTest.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.btnNavTest.ForeColor = System.Drawing.Color.White;
            this.btnNavTest.Location = new System.Drawing.Point(10, 290);
            this.btnNavTest.Name = "btnNavTest";
            this.btnNavTest.Size = new System.Drawing.Size(130, 40);
            this.btnNavTest.TabIndex = 7;
            this.btnNavTest.Text = "TEST";
            this.btnNavTest.Click += new System.EventHandler(this.btnNavTest_Click);
            // 
            // btnNavSettings
            // 
            this.btnNavSettings.BorderRadius = 8;
            this.btnNavSettings.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.btnNavSettings.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.btnNavSettings.ForeColor = System.Drawing.Color.White;
            this.btnNavSettings.Location = new System.Drawing.Point(10, 198);
            this.btnNavSettings.Name = "btnNavSettings";
            this.btnNavSettings.Size = new System.Drawing.Size(130, 40);
            this.btnNavSettings.TabIndex = 3;
            this.btnNavSettings.Text = "SETTINGS";
            this.btnNavSettings.Click += new System.EventHandler(this.btnNavSettings_Click);
            // 
            // btnNavExternal
            // 
            this.btnNavExternal.BorderRadius = 8;
            this.btnNavExternal.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.btnNavExternal.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.btnNavExternal.ForeColor = System.Drawing.Color.White;
            this.btnNavExternal.Location = new System.Drawing.Point(10, 152);
            this.btnNavExternal.Name = "btnNavExternal";
            this.btnNavExternal.Size = new System.Drawing.Size(130, 40);
            this.btnNavExternal.TabIndex = 2;
            this.btnNavExternal.Text = "EXTERNAL";
            this.btnNavExternal.Click += new System.EventHandler(this.btnNavExternal_Click);
            // 
            // btnNavChams
            // 
            this.btnNavChams.BorderRadius = 8;
            this.btnNavChams.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.btnNavChams.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.btnNavChams.ForeColor = System.Drawing.Color.White;
            this.btnNavChams.Location = new System.Drawing.Point(10, 106);
            this.btnNavChams.Name = "btnNavChams";
            this.btnNavChams.Size = new System.Drawing.Size(130, 40);
            this.btnNavChams.TabIndex = 1;
            this.btnNavChams.Text = "CHAMS";
            this.btnNavChams.Click += new System.EventHandler(this.btnNavChams_Click);
            // 
            // btnNavAimbot
            // 
            this.btnNavAimbot.BorderRadius = 8;
            this.btnNavAimbot.FillColor = System.Drawing.Color.Maroon;
            this.btnNavAimbot.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.btnNavAimbot.ForeColor = System.Drawing.Color.White;
            this.btnNavAimbot.Location = new System.Drawing.Point(10, 14);
            this.btnNavAimbot.Name = "btnNavAimbot";
            this.btnNavAimbot.Size = new System.Drawing.Size(130, 40);
            this.btnNavAimbot.TabIndex = 0;
            this.btnNavAimbot.Text = "FF GLOBAL AIM";
            this.btnNavAimbot.Click += new System.EventHandler(this.btnNavAimbot_Click);
            // 
            // btnNavFfMax
            // 
            this.btnNavFfMax.BorderRadius = 8;
            this.btnNavFfMax.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.btnNavFfMax.ForeColor = System.Drawing.Color.White;
            this.btnNavFfMax.Location = new System.Drawing.Point(10, 60);
            this.btnNavFfMax.Name = "btnNavFfMax";
            this.btnNavFfMax.Size = new System.Drawing.Size(130, 40);
            this.btnNavFfMax.TabIndex = 60;
            this.btnNavFfMax.Text = "FF MAX AIM";
            this.btnNavFfMax.Click += new System.EventHandler(this.btnNavFfMax_Click);
            // 
            // pnlAimbot
            // 
            this.cardAimMatch.Controls.Add(this.btnAimKeyMatch);
            this.cardAimMatch.Controls.Add(this.lblRowAimMatch);
            this.pnlAimbot.Controls.Add(this.lblAimInfo);
            this.cardAimRun.Controls.Add(this.btnAimRun);
            this.pnlAimbot.Controls.Add(this.lblAimTitle);
            this.pnlAimbot.Controls.Add(this.cardAimRun);
            this.pnlAimbot.Controls.Add(this.cardAimMatch);
            this.pnlAimbot.Controls.Add(this.barAim);
            this.pnlAimbot.Controls.Add(this.divAim);
            this.pnlAimbot.Location = new System.Drawing.Point(150, 35);
            this.pnlAimbot.Name = "pnlAimbot";
            this.pnlAimbot.Size = new System.Drawing.Size(610, 450);
            this.pnlAimbot.TabIndex = 31;
            // 
            // btnAimKeyMatch
            // 
            this.btnAimKeyMatch.BorderRadius = 6;
            this.btnAimKeyMatch.Font = new System.Drawing.Font("Segoe UI", 8F, System.Drawing.FontStyle.Bold);
            this.btnAimKeyMatch.ForeColor = System.Drawing.Color.White;
            this.btnAimKeyMatch.Location = new System.Drawing.Point(430, 22);
            this.btnAimKeyMatch.Name = "btnAimKeyMatch";
            this.btnAimKeyMatch.Size = new System.Drawing.Size(130, 30);
            this.btnAimKeyMatch.TabIndex = 4;
            this.btnAimKeyMatch.Text = "F9";
            this.btnAimKeyMatch.Click += new System.EventHandler(this.btnAimKeyMatch_Click);
            // 
            // lblRowAimMatch
            // 
            this.lblRowAimMatch.AutoSize = true;
            this.lblRowAimMatch.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
            this.lblRowAimMatch.ForeColor = System.Drawing.Color.Red;
            this.lblRowAimMatch.Location = new System.Drawing.Point(20, 12);
            this.lblRowAimMatch.Name = "lblRowAimMatch";
            this.lblRowAimMatch.Size = new System.Drawing.Size(231, 18);
            this.lblRowAimMatch.TabIndex = 3;
            this.lblRowAimMatch.Text = "AIMBOT HOTKEY (PER MATCH)";
            // 
            // lblAimInfo
            // 
            this.lblAimInfo.AutoSize = true;
            this.lblAimInfo.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.lblAimInfo.ForeColor = System.Drawing.Color.Gray;
            this.lblAimInfo.Location = new System.Drawing.Point(28, 58);
            this.lblAimInfo.Name = "lblAimInfo";
            this.lblAimInfo.Size = new System.Drawing.Size(219, 15);
            this.lblAimInfo.TabIndex = 2;
            this.lblAimInfo.Text = "Head/Chest swap • Emulator: HD-Player";
            // 
            // btnAimRun
            // 
            this.btnAimRun.BackColor = System.Drawing.Color.Transparent;
            this.btnAimRun.BorderRadius = 14;
            this.btnAimRun.FillColor = System.Drawing.Color.Red;
            this.btnAimRun.FillColor2 = System.Drawing.Color.Maroon;
            this.btnAimRun.Font = new System.Drawing.Font("Sitka Small", 11.25F, System.Drawing.FontStyle.Bold);
            this.btnAimRun.ForeColor = System.Drawing.Color.White;
            this.btnAimRun.Location = new System.Drawing.Point(15, 17);
            this.btnAimRun.Name = "btnAimRun";
            this.btnAimRun.Size = new System.Drawing.Size(550, 50);
            this.btnAimRun.TabIndex = 1;
            this.btnAimRun.Text = "INJECT AIMBOT";
            this.btnAimRun.Click += new System.EventHandler(this.guna2GradientButton1_Click);
            // 
            // lblAimTitle
            // 
            this.lblAimTitle.AutoSize = true;
            this.lblAimTitle.Font = new System.Drawing.Font("Segoe UI", 14F, System.Drawing.FontStyle.Bold);
            this.lblAimTitle.ForeColor = System.Drawing.Color.Red;
            this.lblAimTitle.Location = new System.Drawing.Point(28, 14);
            this.lblAimTitle.Name = "lblAimTitle";
            this.lblAimTitle.Size = new System.Drawing.Size(179, 25);
            this.lblAimTitle.TabIndex = 0;
            this.lblAimTitle.Text = "FF GLOBAL AIM";
            // 
            // pnlFfMax
            // 
            this.cardFfMaxRow.Controls.Add(this.btnFfMaxKey);
            this.cardFfMaxRow.Controls.Add(this.lblFfMaxRow);
            this.pnlFfMax.Controls.Add(this.lblFfMaxInfo);
            this.cardFfMaxRun.Controls.Add(this.btnFfMaxRun);
            this.pnlFfMax.Controls.Add(this.lblFfMaxTitle);
            this.pnlFfMax.Controls.Add(this.cardFfMaxRun);
            this.pnlFfMax.Controls.Add(this.cardFfMaxRow);
            this.pnlFfMax.Controls.Add(this.barFfMax);
            this.pnlFfMax.Controls.Add(this.divFfMax);
            this.pnlFfMax.Location = new System.Drawing.Point(150, 35);
            this.pnlFfMax.Name = "pnlFfMax";
            this.pnlFfMax.Size = new System.Drawing.Size(610, 450);
            this.pnlFfMax.TabIndex = 61;
            this.pnlFfMax.Visible = false;
            // 
            // lblFfMaxTitle
            // 
            this.lblFfMaxTitle.AutoSize = true;
            this.lblFfMaxTitle.Font = new System.Drawing.Font("Segoe UI", 14F, System.Drawing.FontStyle.Bold);
            this.lblFfMaxTitle.ForeColor = System.Drawing.Color.Red;
            this.lblFfMaxTitle.Location = new System.Drawing.Point(28, 14);
            this.lblFfMaxTitle.Name = "lblFfMaxTitle";
            this.lblFfMaxTitle.Size = new System.Drawing.Size(120, 25);
            this.lblFfMaxTitle.TabIndex = 0;
            this.lblFfMaxTitle.Text = "FF MAX AIM";
            // 
            // btnFfMaxRun
            // 
            this.btnFfMaxRun.BackColor = System.Drawing.Color.Transparent;
            this.btnFfMaxRun.BorderRadius = 14;
            this.btnFfMaxRun.FillColor = System.Drawing.Color.Red;
            this.btnFfMaxRun.FillColor2 = System.Drawing.Color.Maroon;
            this.btnFfMaxRun.Font = new System.Drawing.Font("Sitka Small", 11.25F, System.Drawing.FontStyle.Bold);
            this.btnFfMaxRun.ForeColor = System.Drawing.Color.White;
            this.btnFfMaxRun.Location = new System.Drawing.Point(15, 17);
            this.btnFfMaxRun.Name = "btnFfMaxRun";
            this.btnFfMaxRun.Size = new System.Drawing.Size(550, 50);
            this.btnFfMaxRun.TabIndex = 1;
            this.btnFfMaxRun.Text = "INJECT AIMBOT";
            this.btnFfMaxRun.Click += new System.EventHandler(this.btnFfMaxRun_Click);
            // 
            // lblFfMaxInfo
            // 
            this.lblFfMaxInfo.AutoSize = true;
            this.lblFfMaxInfo.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.lblFfMaxInfo.ForeColor = System.Drawing.Color.Gray;
            this.lblFfMaxInfo.Location = new System.Drawing.Point(28, 58);
            this.lblFfMaxInfo.Name = "lblFfMaxInfo";
            this.lblFfMaxInfo.Size = new System.Drawing.Size(219, 15);
            this.lblFfMaxInfo.TabIndex = 2;
            this.lblFfMaxInfo.Text = "Head/Chest swap  Emulator: HD-Player";
            // 
            // lblFfMaxRow
            // 
            this.lblFfMaxRow.AutoSize = true;
            this.lblFfMaxRow.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
            this.lblFfMaxRow.ForeColor = System.Drawing.Color.Red;
            this.lblFfMaxRow.Location = new System.Drawing.Point(20, 12);
            this.lblFfMaxRow.Name = "lblFfMaxRow";
            this.lblFfMaxRow.Size = new System.Drawing.Size(231, 18);
            this.lblFfMaxRow.TabIndex = 3;
            this.lblFfMaxRow.Text = "FF MAX HOTKEY (PER MATCH)";
            // 
            // btnFfMaxKey
            // 
            this.btnFfMaxKey.BorderRadius = 6;
            this.btnFfMaxKey.Font = new System.Drawing.Font("Segoe UI", 8F, System.Drawing.FontStyle.Bold);
            this.btnFfMaxKey.ForeColor = System.Drawing.Color.White;
            this.btnFfMaxKey.Location = new System.Drawing.Point(430, 22);
            this.btnFfMaxKey.Name = "btnFfMaxKey";
            this.btnFfMaxKey.Size = new System.Drawing.Size(130, 30);
            this.btnFfMaxKey.TabIndex = 4;
            this.btnFfMaxKey.Text = "F10";
            this.btnFfMaxKey.Click += new System.EventHandler(this.btnFfMaxKey_Click);
            // 
            // pnlChams
            // 
            this.pnlChams.Controls.Add(this.lblChamsInfo);
            this.cardChamsRun.Controls.Add(this.btnChamsRun);
            this.pnlChams.Controls.Add(this.lblChamsTitle);
            this.cardChamsFix.Controls.Add(this.chkChamsFix64);
            this.cardChamsFix.Controls.Add(this.lblChamsFix64);
            this.cardChamsTrans.Controls.Add(this.chkChamsTrans);
            this.cardChamsTrans.Controls.Add(this.lblChamsTrans);
            this.pnlChams.Controls.Add(this.cardChamsRun);
            this.pnlChams.Controls.Add(this.cardChamsFix);
            this.pnlChams.Controls.Add(this.cardChamsTrans);
            this.pnlChams.Controls.Add(this.barChams);
            this.pnlChams.Controls.Add(this.divChams);
            this.pnlChams.Location = new System.Drawing.Point(150, 35);
            this.pnlChams.Name = "pnlChams";
            this.pnlChams.Size = new System.Drawing.Size(610, 450);
            this.pnlChams.TabIndex = 32;
            this.pnlChams.Visible = false;
            // 
            // lblChamsInfo
            // 
            this.lblChamsInfo.AutoSize = true;
            this.lblChamsInfo.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.lblChamsInfo.ForeColor = System.Drawing.Color.Gray;
            this.lblChamsInfo.Location = new System.Drawing.Point(28, 58);
            this.lblChamsInfo.Name = "lblChamsInfo";
            this.lblChamsInfo.Size = new System.Drawing.Size(209, 15);
            this.lblChamsInfo.TabIndex = 2;
            this.lblChamsInfo.Text = "Downloads + injects CHAMSMENU.dll";
            // 
            // btnChamsRun
            // 
            this.btnChamsRun.BackColor = System.Drawing.Color.Transparent;
            this.btnChamsRun.BorderRadius = 14;
            this.btnChamsRun.FillColor = System.Drawing.Color.Red;
            this.btnChamsRun.FillColor2 = System.Drawing.Color.Maroon;
            this.btnChamsRun.Font = new System.Drawing.Font("Sitka Small", 11.25F, System.Drawing.FontStyle.Bold);
            this.btnChamsRun.ForeColor = System.Drawing.Color.White;
            this.btnChamsRun.Location = new System.Drawing.Point(15, 17);
            this.btnChamsRun.Name = "btnChamsRun";
            this.btnChamsRun.Size = new System.Drawing.Size(550, 50);
            this.btnChamsRun.TabIndex = 1;
            this.btnChamsRun.Text = "INJECT LOCATION";
            this.btnChamsRun.Click += new System.EventHandler(this.guna2GradientButton2_Click);
            // 
            // lblChamsTitle
            // 
            this.lblChamsTitle.AutoSize = true;
            this.lblChamsTitle.Font = new System.Drawing.Font("Segoe UI", 14F, System.Drawing.FontStyle.Bold);
            this.lblChamsTitle.ForeColor = System.Drawing.Color.Red;
            this.lblChamsTitle.Location = new System.Drawing.Point(28, 14);
            this.lblChamsTitle.Name = "lblChamsTitle";
            this.lblChamsTitle.Size = new System.Drawing.Size(143, 25);
            this.lblChamsTitle.TabIndex = 0;
            this.lblChamsTitle.Text = "CHAMS MENU";
            // 
            // chkChamsFix64
            // 
            this.chkChamsFix64.CheckedState.BorderColor = System.Drawing.Color.White;
            this.chkChamsFix64.CheckedState.BorderRadius = 0;
            this.chkChamsFix64.CheckedState.BorderThickness = 0;
            this.chkChamsFix64.CheckedState.FillColor = System.Drawing.Color.Red;
            this.chkChamsFix64.Location = new System.Drawing.Point(530, 28);
            this.chkChamsFix64.Name = "chkChamsFix64";
            this.chkChamsFix64.Size = new System.Drawing.Size(20, 20);
            this.chkChamsFix64.TabIndex = 6;
            this.chkChamsFix64.UncheckedState.BorderColor = System.Drawing.Color.Gray;
            this.chkChamsFix64.UncheckedState.BorderRadius = 0;
            this.chkChamsFix64.UncheckedState.BorderThickness = 0;
            this.chkChamsFix64.UncheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.chkChamsFix64.CheckedChanged += new System.EventHandler(this.chkChamsFix64_CheckedChanged);
            // 
            // lblChamsFix64
            // 
            this.lblChamsFix64.AutoSize = true;
            this.lblChamsFix64.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
            this.lblChamsFix64.ForeColor = System.Drawing.Color.White;
            this.lblChamsFix64.Location = new System.Drawing.Point(20, 12);
            this.lblChamsFix64.Name = "lblChamsFix64";
            this.lblChamsFix64.Size = new System.Drawing.Size(140, 18);
            this.lblChamsFix64.TabIndex = 5;
            this.lblChamsFix64.Text = "FIX CHAMS (64BIT)";
            // 
            // chkChamsTrans
            // 
            this.chkChamsTrans.CheckedState.BorderColor = System.Drawing.Color.White;
            this.chkChamsTrans.CheckedState.BorderRadius = 0;
            this.chkChamsTrans.CheckedState.BorderThickness = 0;
            this.chkChamsTrans.CheckedState.FillColor = System.Drawing.Color.Red;
            this.chkChamsTrans.Location = new System.Drawing.Point(530, 28);
            this.chkChamsTrans.Name = "chkChamsTrans";
            this.chkChamsTrans.Size = new System.Drawing.Size(20, 20);
            this.chkChamsTrans.TabIndex = 4;
            this.chkChamsTrans.UncheckedState.BorderColor = System.Drawing.Color.Gray;
            this.chkChamsTrans.UncheckedState.BorderRadius = 0;
            this.chkChamsTrans.UncheckedState.BorderThickness = 0;
            this.chkChamsTrans.UncheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.chkChamsTrans.CheckedChanged += new System.EventHandler(this.chkChamsTrans_CheckedChanged);
            // 
            // lblChamsTrans
            // 
            this.lblChamsTrans.AutoSize = true;
            this.lblChamsTrans.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
            this.lblChamsTrans.ForeColor = System.Drawing.Color.White;
            this.lblChamsTrans.Location = new System.Drawing.Point(20, 12);
            this.lblChamsTrans.Name = "lblChamsTrans";
            this.lblChamsTrans.Size = new System.Drawing.Size(118, 18);
            this.lblChamsTrans.TabIndex = 3;
            this.lblChamsTrans.Text = "TRANSPARENT";
            // 
            // pnlExternal
            // 
            this.cardSpeed.Controls.Add(this.chkSpeed);
            this.cardSpeed.Controls.Add(this.lblSpeed);
            this.cardGlitch.Controls.Add(this.chkGlitch);
            this.cardGlitch.Controls.Add(this.lblGlitch);
            this.cardSwitch.Controls.Add(this.chkSwitch);
            this.cardSwitch.Controls.Add(this.lblSwitch);
            this.cardScopeKey.Controls.Add(this.btnScopeKey);
            this.cardScope.Controls.Add(this.chkScope);
            this.cardScope.Controls.Add(this.lblScope);
            this.pnlExternal.Controls.Add(this.lblExtTitle);
            this.pnlExternal.Controls.Add(this.cardScopeKey);
            this.pnlExternal.Controls.Add(this.cardScope);
            this.pnlExternal.Controls.Add(this.cardGlitch);
            this.pnlExternal.Controls.Add(this.cardSpeed);
            this.pnlExternal.Controls.Add(this.cardSwitch);
            this.pnlExternal.Controls.Add(this.barExt);
            this.pnlExternal.Controls.Add(this.divExt);
            this.pnlExternal.Location = new System.Drawing.Point(150, 35);
            this.pnlExternal.Name = "pnlExternal";
            this.pnlExternal.Size = new System.Drawing.Size(610, 450);
            this.pnlExternal.TabIndex = 33;
            this.pnlExternal.Visible = false;
            // 
            // chkSpeed
            // 
            this.chkSpeed.CheckedState.BorderColor = System.Drawing.Color.White;
            this.chkSpeed.CheckedState.BorderRadius = 0;
            this.chkSpeed.CheckedState.BorderThickness = 0;
            this.chkSpeed.CheckedState.FillColor = System.Drawing.Color.Red;
            this.chkSpeed.Location = new System.Drawing.Point(235, 22);
            this.chkSpeed.Name = "chkSpeed";
            this.chkSpeed.Size = new System.Drawing.Size(20, 20);
            this.chkSpeed.TabIndex = 9;
            this.chkSpeed.UncheckedState.BorderColor = System.Drawing.Color.Gray;
            this.chkSpeed.UncheckedState.BorderRadius = 0;
            this.chkSpeed.UncheckedState.BorderThickness = 0;
            this.chkSpeed.UncheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.chkSpeed.CheckedChanged += new System.EventHandler(this.chkSpeed_CheckedChanged);
            // 
            // lblSpeed
            // 
            this.lblSpeed.AutoSize = true;
            this.lblSpeed.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
            this.lblSpeed.ForeColor = System.Drawing.Color.White;
            this.lblSpeed.Location = new System.Drawing.Point(20, 12);
            this.lblSpeed.Name = "lblSpeed";
            this.lblSpeed.Size = new System.Drawing.Size(104, 18);
            this.lblSpeed.TabIndex = 8;
            this.lblSpeed.Text = "SPEED HACK";
            // 
            // chkGlitch
            // 
            this.chkGlitch.CheckedState.BorderColor = System.Drawing.Color.White;
            this.chkGlitch.CheckedState.BorderRadius = 0;
            this.chkGlitch.CheckedState.BorderThickness = 0;
            this.chkGlitch.CheckedState.FillColor = System.Drawing.Color.Red;
            this.chkGlitch.Location = new System.Drawing.Point(235, 22);
            this.chkGlitch.Name = "chkGlitch";
            this.chkGlitch.Size = new System.Drawing.Size(20, 20);
            this.chkGlitch.TabIndex = 7;
            this.chkGlitch.UncheckedState.BorderColor = System.Drawing.Color.Gray;
            this.chkGlitch.UncheckedState.BorderRadius = 0;
            this.chkGlitch.UncheckedState.BorderThickness = 0;
            this.chkGlitch.UncheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.chkGlitch.CheckedChanged += new System.EventHandler(this.chkGlitch_CheckedChanged);
            // 
            // lblGlitch
            // 
            this.lblGlitch.AutoSize = true;
            this.lblGlitch.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
            this.lblGlitch.ForeColor = System.Drawing.Color.White;
            this.lblGlitch.Location = new System.Drawing.Point(20, 12);
            this.lblGlitch.Name = "lblGlitch";
            this.lblGlitch.Size = new System.Drawing.Size(99, 18);
            this.lblGlitch.TabIndex = 6;
            this.lblGlitch.Text = "GLITCH FIRE";
            // 
            // chkSwitch
            // 
            this.chkSwitch.CheckedState.BorderColor = System.Drawing.Color.White;
            this.chkSwitch.CheckedState.BorderRadius = 0;
            this.chkSwitch.CheckedState.BorderThickness = 0;
            this.chkSwitch.CheckedState.FillColor = System.Drawing.Color.Red;
            this.chkSwitch.Location = new System.Drawing.Point(235, 22);
            this.chkSwitch.Name = "chkSwitch";
            this.chkSwitch.Size = new System.Drawing.Size(20, 20);
            this.chkSwitch.TabIndex = 5;
            this.chkSwitch.UncheckedState.BorderColor = System.Drawing.Color.Gray;
            this.chkSwitch.UncheckedState.BorderRadius = 0;
            this.chkSwitch.UncheckedState.BorderThickness = 0;
            this.chkSwitch.UncheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.chkSwitch.CheckedChanged += new System.EventHandler(this.chkSwitch_CheckedChanged);
            // 
            // lblSwitch
            // 
            this.lblSwitch.AutoSize = true;
            this.lblSwitch.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
            this.lblSwitch.ForeColor = System.Drawing.Color.White;
            this.lblSwitch.Location = new System.Drawing.Point(20, 12);
            this.lblSwitch.Name = "lblSwitch";
            this.lblSwitch.Size = new System.Drawing.Size(126, 18);
            this.lblSwitch.TabIndex = 4;
            this.lblSwitch.Text = "SNIPER SWITCH";
            // 
            // btnScopeKey
            // 
            this.btnScopeKey.BorderRadius = 4;
            this.btnScopeKey.Font = new System.Drawing.Font("Segoe UI", 8F, System.Drawing.FontStyle.Bold);
            this.btnScopeKey.ForeColor = System.Drawing.Color.White;
            this.btnScopeKey.Location = new System.Drawing.Point(430, 22);
            this.btnScopeKey.Name = "btnScopeKey";
            this.btnScopeKey.Size = new System.Drawing.Size(90, 24);
            this.btnScopeKey.TabIndex = 3;
            this.btnScopeKey.Text = "-";
            this.btnScopeKey.Click += new System.EventHandler(this.btnScopeKey_Click);
            // 
            // chkScope
            // 
            this.chkScope.CheckedState.BorderColor = System.Drawing.Color.White;
            this.chkScope.CheckedState.BorderRadius = 0;
            this.chkScope.CheckedState.BorderThickness = 0;
            this.chkScope.CheckedState.FillColor = System.Drawing.Color.Red;
            this.chkScope.Location = new System.Drawing.Point(235, 22);
            this.chkScope.Name = "chkScope";
            this.chkScope.Size = new System.Drawing.Size(20, 20);
            this.chkScope.TabIndex = 2;
            this.chkScope.UncheckedState.BorderColor = System.Drawing.Color.Gray;
            this.chkScope.UncheckedState.BorderRadius = 0;
            this.chkScope.UncheckedState.BorderThickness = 0;
            this.chkScope.UncheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.chkScope.CheckedChanged += new System.EventHandler(this.chkScope_CheckedChanged);
            // 
            // lblScope
            // 
            this.lblScope.AutoSize = true;
            this.lblScope.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
            this.lblScope.ForeColor = System.Drawing.Color.White;
            this.lblScope.Location = new System.Drawing.Point(20, 12);
            this.lblScope.Name = "lblScope";
            this.lblScope.Size = new System.Drawing.Size(120, 18);
            this.lblScope.TabIndex = 1;
            this.lblScope.Text = "SNIPER SCOPE";
            // 
            // lblExtTitle
            // 
            this.lblExtTitle.AutoSize = true;
            this.lblExtTitle.Font = new System.Drawing.Font("Segoe UI", 14F, System.Drawing.FontStyle.Bold);
            this.lblExtTitle.ForeColor = System.Drawing.Color.Red;
            this.lblExtTitle.Location = new System.Drawing.Point(28, 14);
            this.lblExtTitle.Name = "lblExtTitle";
            this.lblExtTitle.Size = new System.Drawing.Size(200, 25);
            this.lblExtTitle.TabIndex = 0;
            this.lblExtTitle.Text = "EXTERNAL FEATURES";
            // 
            // pnlSettings
            // 
            this.cardSetTheme.Controls.Add(this.btnTheme);
            this.cardSetAccent.Controls.Add(this.btnAccentColor);
            this.cardSetAccent.Controls.Add(this.lblRowAccent);
            this.cardSetBg.Controls.Add(this.btnBgColor);
            this.cardSetBg.Controls.Add(this.lblRowBgColor);
            this.cardSetTheme.Controls.Add(this.lblRowTheme);
            this.cardSetHide.Controls.Add(this.btnHideKey);
            this.cardSetHide.Controls.Add(this.lblRowHide);
            this.cardSetStream.Controls.Add(this.btnStreamer);
            this.cardSetStream.Controls.Add(this.lblRowStream);
            this.pnlSettings.Controls.Add(this.lblSetTitle);
            this.cardSetLog.Controls.Add(this.btnViewLog);
            this.cardSetLog.Controls.Add(this.lblRowLog);
            this.pnlSettings.Controls.Add(this.cardSetTheme);
            this.pnlSettings.Controls.Add(this.cardSetAccent);
            this.pnlSettings.Controls.Add(this.cardSetBg);
            this.pnlSettings.Controls.Add(this.cardSetHide);
            this.pnlSettings.Controls.Add(this.cardSetStream);
            this.pnlSettings.Controls.Add(this.cardSetLog);
            this.pnlSettings.Controls.Add(this.barSet);
            this.pnlSettings.Controls.Add(this.divSet);
            this.pnlSettings.Location = new System.Drawing.Point(150, 35);
            this.pnlSettings.Name = "pnlSettings";
            this.pnlSettings.Size = new System.Drawing.Size(610, 450);
            this.pnlSettings.TabIndex = 34;
            this.pnlSettings.Visible = false;
            // 
            // btnTheme
            // 
            this.btnTheme.BorderRadius = 6;
            this.btnTheme.Font = new System.Drawing.Font("Segoe UI", 8F, System.Drawing.FontStyle.Bold);
            this.btnTheme.ForeColor = System.Drawing.Color.White;
            this.btnTheme.Location = new System.Drawing.Point(430, 10);
            this.btnTheme.Name = "btnTheme";
            this.btnTheme.Size = new System.Drawing.Size(130, 30);
            this.btnTheme.TabIndex = 8;
            this.btnTheme.Text = "RED";
            this.btnTheme.Click += new System.EventHandler(this.btnTheme_Click);
            // 
            // btnAccentColor
            // 
            this.btnAccentColor.BorderRadius = 6;
            this.btnAccentColor.Font = new System.Drawing.Font("Segoe UI", 8F, System.Drawing.FontStyle.Bold);
            this.btnAccentColor.ForeColor = System.Drawing.Color.White;
            this.btnAccentColor.Location = new System.Drawing.Point(430, 10);
            this.btnAccentColor.Name = "btnAccentColor";
            this.btnAccentColor.Size = new System.Drawing.Size(130, 30);
            this.btnAccentColor.TabIndex = 12;
            this.btnAccentColor.Text = "PICK...";
            this.btnAccentColor.Click += new System.EventHandler(this.btnAccentColor_Click);
            // 
            // lblRowAccent
            // 
            this.lblRowAccent.AutoSize = true;
            this.lblRowAccent.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
            this.lblRowAccent.ForeColor = System.Drawing.Color.White;
            this.lblRowAccent.Location = new System.Drawing.Point(20, 16);
            this.lblRowAccent.Name = "lblRowAccent";
            this.lblRowAccent.Size = new System.Drawing.Size(127, 18);
            this.lblRowAccent.TabIndex = 11;
            this.lblRowAccent.Text = "ACCENT COLOR";
            // 
            // btnBgColor
            // 
            this.btnBgColor.BorderRadius = 6;
            this.btnBgColor.Font = new System.Drawing.Font("Segoe UI", 8F, System.Drawing.FontStyle.Bold);
            this.btnBgColor.ForeColor = System.Drawing.Color.White;
            this.btnBgColor.Location = new System.Drawing.Point(430, 10);
            this.btnBgColor.Name = "btnBgColor";
            this.btnBgColor.Size = new System.Drawing.Size(130, 30);
            this.btnBgColor.TabIndex = 10;
            this.btnBgColor.Text = "PICK...";
            this.btnBgColor.Click += new System.EventHandler(this.btnBgColor_Click);
            // 
            // lblRowBgColor
            // 
            this.lblRowBgColor.AutoSize = true;
            this.lblRowBgColor.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
            this.lblRowBgColor.ForeColor = System.Drawing.Color.White;
            this.lblRowBgColor.Location = new System.Drawing.Point(20, 16);
            this.lblRowBgColor.Name = "lblRowBgColor";
            this.lblRowBgColor.Size = new System.Drawing.Size(88, 18);
            this.lblRowBgColor.TabIndex = 9;
            this.lblRowBgColor.Text = "BG COLOR";
            // 
            // lblRowTheme
            // 
            this.lblRowTheme.AutoSize = true;
            this.lblRowTheme.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
            this.lblRowTheme.ForeColor = System.Drawing.Color.Red;
            this.lblRowTheme.Location = new System.Drawing.Point(20, 16);
            this.lblRowTheme.Name = "lblRowTheme";
            this.lblRowTheme.Size = new System.Drawing.Size(0, 18);
            this.lblRowTheme.TabIndex = 7;
            // 
            // btnHideKey
            // 
            this.btnHideKey.BorderRadius = 6;
            this.btnHideKey.Font = new System.Drawing.Font("Segoe UI", 8F, System.Drawing.FontStyle.Bold);
            this.btnHideKey.ForeColor = System.Drawing.Color.White;
            this.btnHideKey.Location = new System.Drawing.Point(430, 10);
            this.btnHideKey.Name = "btnHideKey";
            this.btnHideKey.Size = new System.Drawing.Size(130, 30);
            this.btnHideKey.TabIndex = 4;
            this.btnHideKey.Text = "NONE";
            this.btnHideKey.Click += new System.EventHandler(this.btnHideKey_Click);
            // 
            // lblRowHide
            // 
            this.lblRowHide.AutoSize = true;
            this.lblRowHide.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
            this.lblRowHide.ForeColor = System.Drawing.Color.White;
            this.lblRowHide.Location = new System.Drawing.Point(20, 16);
            this.lblRowHide.Name = "lblRowHide";
            this.lblRowHide.Size = new System.Drawing.Size(157, 18);
            this.lblRowHide.TabIndex = 3;
            this.lblRowHide.Text = "HIDE MENU HOTKEY";
            // 
            // btnStreamer
            // 
            this.btnStreamer.BorderRadius = 6;
            this.btnStreamer.Font = new System.Drawing.Font("Segoe UI", 8F, System.Drawing.FontStyle.Bold);
            this.btnStreamer.ForeColor = System.Drawing.Color.White;
            this.btnStreamer.Location = new System.Drawing.Point(430, 10);
            this.btnStreamer.Name = "btnStreamer";
            this.btnStreamer.Size = new System.Drawing.Size(130, 30);
            this.btnStreamer.TabIndex = 2;
            this.btnStreamer.Text = "ON";
            this.btnStreamer.Click += new System.EventHandler(this.btnStreamer_Click);
            // 
            // lblRowStream
            // 
            this.lblRowStream.AutoSize = true;
            this.lblRowStream.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
            this.lblRowStream.ForeColor = System.Drawing.Color.White;
            this.lblRowStream.Location = new System.Drawing.Point(20, 16);
            this.lblRowStream.Name = "lblRowStream";
            this.lblRowStream.Size = new System.Drawing.Size(120, 18);
            this.lblRowStream.TabIndex = 1;
            this.lblRowStream.Text = "STREAM MODE";
            // 
            // lblSetTitle
            // 
            this.lblSetTitle.AutoSize = true;
            this.lblSetTitle.Font = new System.Drawing.Font("Segoe UI", 14F, System.Drawing.FontStyle.Bold);
            this.lblSetTitle.ForeColor = System.Drawing.Color.Red;
            this.lblSetTitle.Location = new System.Drawing.Point(28, 14);
            this.lblSetTitle.Name = "lblSetTitle";
            this.lblSetTitle.Size = new System.Drawing.Size(101, 25);
            this.lblSetTitle.TabIndex = 0;
            this.lblSetTitle.Text = "SETTINGS";
            // 
            // lblRowLog
            // 
            this.lblRowLog.AutoSize = true;
            this.lblRowLog.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
            this.lblRowLog.ForeColor = System.Drawing.Color.White;
            this.lblRowLog.Location = new System.Drawing.Point(20, 16);
            this.lblRowLog.Name = "lblRowLog";
            this.lblRowLog.Size = new System.Drawing.Size(90, 18);
            this.lblRowLog.TabIndex = 100;
            this.lblRowLog.Text = "SCAN LOG";
            // 
            // btnViewLog
            // 
            this.btnViewLog.BorderRadius = 6;
            this.btnViewLog.Font = new System.Drawing.Font("Segoe UI", 8F, System.Drawing.FontStyle.Bold);
            this.btnViewLog.ForeColor = System.Drawing.Color.White;
            this.btnViewLog.Location = new System.Drawing.Point(430, 10);
            this.btnViewLog.Name = "btnViewLog";
            this.btnViewLog.Size = new System.Drawing.Size(130, 30);
            this.btnViewLog.TabIndex = 101;
            this.btnViewLog.Text = "VIEW LOG";
            this.btnViewLog.Click += new System.EventHandler(this.btnViewLog_Click);
            // 
            // pnlTest
            // 
            this.cardTestSaim.Controls.Add(this.chkTestSaim);
            this.cardTestSaim.Controls.Add(this.lblTestSaim);
            this.cardTestSwitch.Controls.Add(this.chkTestSwitch);
            this.cardTestSwitch.Controls.Add(this.lblTestSwitch);
            this.cardTest5566.Controls.Add(this.chkTest5566);
            this.cardTest5566.Controls.Add(this.lblTest5566);
            this.pnlTest.Controls.Add(this.lblTestTitle);
            this.pnlTest.Controls.Add(this.cardTestSaim);
            this.pnlTest.Controls.Add(this.cardTest5566);
            this.pnlTest.Controls.Add(this.cardTestSwitch);
            this.pnlTest.Controls.Add(this.barTest);
            this.pnlTest.Controls.Add(this.divTest);
            this.pnlTest.Location = new System.Drawing.Point(150, 35);
            this.pnlTest.Name = "pnlTest";
            this.pnlTest.Size = new System.Drawing.Size(610, 450);
            this.pnlTest.TabIndex = 38;
            this.pnlTest.Visible = false;
            // 
            // chkTestSaim
            // 
            this.chkTestSaim.CheckedState.BorderColor = System.Drawing.Color.White;
            this.chkTestSaim.CheckedState.BorderRadius = 0;
            this.chkTestSaim.CheckedState.BorderThickness = 0;
            this.chkTestSaim.CheckedState.FillColor = System.Drawing.Color.Red;
            this.chkTestSaim.Location = new System.Drawing.Point(530, 26);
            this.chkTestSaim.Name = "chkTestSaim";
            this.chkTestSaim.Size = new System.Drawing.Size(20, 20);
            this.chkTestSaim.TabIndex = 8;
            this.chkTestSaim.UncheckedState.BorderColor = System.Drawing.Color.Gray;
            this.chkTestSaim.UncheckedState.BorderRadius = 0;
            this.chkTestSaim.UncheckedState.BorderThickness = 0;
            this.chkTestSaim.UncheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.chkTestSaim.CheckedChanged += new System.EventHandler(this.chkTestSaim_CheckedChanged);
            // 
            // lblTestSaim
            // 
            this.lblTestSaim.AutoSize = true;
            this.lblTestSaim.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
            this.lblTestSaim.ForeColor = System.Drawing.Color.White;
            this.lblTestSaim.Location = new System.Drawing.Point(20, 12);
            this.lblTestSaim.Name = "lblTestSaim";
            this.lblTestSaim.Size = new System.Drawing.Size(192, 18);
            this.lblTestSaim.TabIndex = 7;
            this.lblTestSaim.Text = "SNIPER AIM (MAINTANCE)";
            // 
            // chkTestSwitch
            // 
            this.chkTestSwitch.CheckedState.BorderColor = System.Drawing.Color.White;
            this.chkTestSwitch.CheckedState.BorderRadius = 0;
            this.chkTestSwitch.CheckedState.BorderThickness = 0;
            this.chkTestSwitch.CheckedState.FillColor = System.Drawing.Color.Red;
            this.chkTestSwitch.Location = new System.Drawing.Point(530, 26);
            this.chkTestSwitch.Name = "chkTestSwitch";
            this.chkTestSwitch.Size = new System.Drawing.Size(20, 20);
            this.chkTestSwitch.TabIndex = 6;
            this.chkTestSwitch.UncheckedState.BorderColor = System.Drawing.Color.Gray;
            this.chkTestSwitch.UncheckedState.BorderRadius = 0;
            this.chkTestSwitch.UncheckedState.BorderThickness = 0;
            this.chkTestSwitch.UncheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.chkTestSwitch.CheckedChanged += new System.EventHandler(this.chkTestSwitch_CheckedChanged);
            // 
            // lblTestSwitch
            // 
            this.lblTestSwitch.AutoSize = true;
            this.lblTestSwitch.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
            this.lblTestSwitch.ForeColor = System.Drawing.Color.White;
            this.lblTestSwitch.Location = new System.Drawing.Point(20, 12);
            this.lblTestSwitch.Name = "lblTestSwitch";
            this.lblTestSwitch.Size = new System.Drawing.Size(226, 18);
            this.lblTestSwitch.TabIndex = 5;
            this.lblTestSwitch.Text = "SNIPER SWITCH (MAINTANCE)";
            // 
            // chkTest5566
            // 
            this.chkTest5566.CheckedState.BorderColor = System.Drawing.Color.White;
            this.chkTest5566.CheckedState.BorderRadius = 0;
            this.chkTest5566.CheckedState.BorderThickness = 0;
            this.chkTest5566.CheckedState.FillColor = System.Drawing.Color.Red;
            this.chkTest5566.Location = new System.Drawing.Point(530, 26);
            this.chkTest5566.Name = "chkTest5566";
            this.chkTest5566.Size = new System.Drawing.Size(20, 20);
            this.chkTest5566.TabIndex = 9;
            this.chkTest5566.UncheckedState.BorderColor = System.Drawing.Color.Gray;
            this.chkTest5566.UncheckedState.BorderRadius = 0;
            this.chkTest5566.UncheckedState.BorderThickness = 0;
            this.chkTest5566.UncheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.chkTest5566.CheckedChanged += new System.EventHandler(this.chkTest5566_CheckedChanged);
            // 
            // lblTest5566
            // 
            this.lblTest5566.AutoSize = true;
            this.lblTest5566.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
            this.lblTest5566.ForeColor = System.Drawing.Color.White;
            this.lblTest5566.Location = new System.Drawing.Point(20, 12);
            this.lblTest5566.Name = "lblTest5566";
            this.lblTest5566.Size = new System.Drawing.Size(78, 18);
            this.lblTest5566.TabIndex = 10;
            this.lblTest5566.Text = "TEST5566";
            // 
            // lblTestTitle
            // 
            this.lblTestTitle.AutoSize = true;
            this.lblTestTitle.Font = new System.Drawing.Font("Segoe UI", 14F, System.Drawing.FontStyle.Bold);
            this.lblTestTitle.ForeColor = System.Drawing.Color.Red;
            this.lblTestTitle.Location = new System.Drawing.Point(28, 14);
            this.lblTestTitle.Name = "lblTestTitle";
            this.lblTestTitle.Size = new System.Drawing.Size(60, 25);
            this.lblTestTitle.TabIndex = 0;
            this.lblTestTitle.Text = "TEST ";
            // 
            // pnlBypass
            // 
            this.cardBpHyper.Controls.Add(this.lblHyperVal);
            this.cardBpOb1.Controls.Add(this.btnBypassOb1);
            this.cardBpOb1.Controls.Add(this.lblRowBypassOb1);
            this.cardBpOb2.Controls.Add(this.btnBypassOb2);
            this.cardBpOb2.Controls.Add(this.lblRowBypassOb2);
            this.cardBpEmuAuto.Controls.Add(this.btnEmuAuto);
            this.cardBpEmuAuto.Controls.Add(this.lblRowEmuAuto);
            this.cardBpEmuKill.Controls.Add(this.btnEmuKill);
            this.cardBpEmuKill.Controls.Add(this.lblRowEmuKill);
            this.cardBpHyperFix.Controls.Add(this.btnHyperFix);
            this.cardBpHyperFix.Controls.Add(this.lblRowHyperFix);
            this.cardBpHyper.Controls.Add(this.btnHyperCheck);
            this.cardBpHyper.Controls.Add(this.lblRowHyper);
            this.pnlBypass.Controls.Add(this.lblBypassTitle);
            this.pnlBypass.Controls.Add(this.cardBpOb1);
            this.pnlBypass.Controls.Add(this.cardBpOb2);
            this.pnlBypass.Controls.Add(this.cardBpEmuAuto);
            this.pnlBypass.Controls.Add(this.cardBpEmuKill);
            this.pnlBypass.Controls.Add(this.cardBpHyper);
            this.pnlBypass.Controls.Add(this.cardBpHyperFix);
            this.pnlBypass.Controls.Add(this.barBypass);
            this.pnlBypass.Controls.Add(this.divBypass);
            this.pnlBypass.Location = new System.Drawing.Point(150, 35);
            this.pnlBypass.Name = "pnlBypass";
            this.pnlBypass.Size = new System.Drawing.Size(610, 450);
            this.pnlBypass.TabIndex = 37;
            this.pnlBypass.Visible = false;
            // 
            // lblHyperVal
            // 
            this.lblHyperVal.AutoSize = true;
            this.lblHyperVal.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.lblHyperVal.ForeColor = System.Drawing.Color.Gray;
            this.lblHyperVal.Location = new System.Drawing.Point(300, 14);
            this.lblHyperVal.Name = "lblHyperVal";
            this.lblHyperVal.Size = new System.Drawing.Size(84, 15);
            this.lblHyperVal.TabIndex = 7;
            this.lblHyperVal.Text = "Press CHECK...";
            // 
            // btnBypassOb1
            // 
            this.btnBypassOb1.BorderRadius = 10;
            this.btnBypassOb1.FillColor = System.Drawing.Color.Red;
            this.btnBypassOb1.FillColor2 = System.Drawing.Color.Maroon;
            this.btnBypassOb1.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.btnBypassOb1.ForeColor = System.Drawing.Color.White;
            this.btnBypassOb1.Location = new System.Drawing.Point(430, 9);
            this.btnBypassOb1.Name = "btnBypassOb1";
            this.btnBypassOb1.Size = new System.Drawing.Size(130, 30);
            this.btnBypassOb1.TabIndex = 11;
            this.btnBypassOb1.Text = "ENABLE";
            this.btnBypassOb1.Click += new System.EventHandler(this.btnBypassOb1_Click);
            // 
            // lblRowBypassOb1
            // 
            this.lblRowBypassOb1.AutoSize = true;
            this.lblRowBypassOb1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
            this.lblRowBypassOb1.ForeColor = System.Drawing.Color.White;
            this.lblRowBypassOb1.Location = new System.Drawing.Point(20, 14);
            this.lblRowBypassOb1.Name = "lblRowBypassOb1";
            this.lblRowBypassOb1.Size = new System.Drawing.Size(121, 18);
            this.lblRowBypassOb1.TabIndex = 10;
            this.lblRowBypassOb1.Text = "BYPASS OB55-1";
            // 
            // btnBypassOb2
            // 
            this.btnBypassOb2.BorderRadius = 10;
            this.btnBypassOb2.FillColor = System.Drawing.Color.Red;
            this.btnBypassOb2.FillColor2 = System.Drawing.Color.Maroon;
            this.btnBypassOb2.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.btnBypassOb2.ForeColor = System.Drawing.Color.White;
            this.btnBypassOb2.Location = new System.Drawing.Point(430, 9);
            this.btnBypassOb2.Name = "btnBypassOb2";
            this.btnBypassOb2.Size = new System.Drawing.Size(130, 30);
            this.btnBypassOb2.TabIndex = 13;
            this.btnBypassOb2.Text = "ENABLE";
            this.btnBypassOb2.Click += new System.EventHandler(this.btnBypassOb2_Click);
            // 
            // lblRowBypassOb2
            // 
            this.lblRowBypassOb2.AutoSize = true;
            this.lblRowBypassOb2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
            this.lblRowBypassOb2.ForeColor = System.Drawing.Color.White;
            this.lblRowBypassOb2.Location = new System.Drawing.Point(20, 14);
            this.lblRowBypassOb2.Name = "lblRowBypassOb2";
            this.lblRowBypassOb2.Size = new System.Drawing.Size(121, 18);
            this.lblRowBypassOb2.TabIndex = 12;
            this.lblRowBypassOb2.Text = "BYPASS OB55-2";
            // 
            // btnEmuAuto
            // 
            this.btnEmuAuto.BorderRadius = 10;
            this.btnEmuAuto.FillColor = System.Drawing.Color.Red;
            this.btnEmuAuto.FillColor2 = System.Drawing.Color.Maroon;
            this.btnEmuAuto.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.btnEmuAuto.ForeColor = System.Drawing.Color.White;
            this.btnEmuAuto.Location = new System.Drawing.Point(430, 9);
            this.btnEmuAuto.Name = "btnEmuAuto";
            this.btnEmuAuto.Size = new System.Drawing.Size(130, 30);
            this.btnEmuAuto.TabIndex = 9;
            this.btnEmuAuto.Text = "START";
            this.btnEmuAuto.Click += new System.EventHandler(this.btnEmuAuto_Click);
            // 
            // lblRowEmuAuto
            // 
            this.lblRowEmuAuto.AutoSize = true;
            this.lblRowEmuAuto.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
            this.lblRowEmuAuto.ForeColor = System.Drawing.Color.White;
            this.lblRowEmuAuto.Location = new System.Drawing.Point(20, 14);
            this.lblRowEmuAuto.Name = "lblRowEmuAuto";
            this.lblRowEmuAuto.Size = new System.Drawing.Size(136, 18);
            this.lblRowEmuAuto.TabIndex = 8;
            this.lblRowEmuAuto.Text = "AUTO EMULATOR";
            // 
            // btnEmuKill
            // 
            this.btnEmuKill.BorderRadius = 10;
            this.btnEmuKill.FillColor = System.Drawing.Color.Red;
            this.btnEmuKill.FillColor2 = System.Drawing.Color.Maroon;
            this.btnEmuKill.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.btnEmuKill.ForeColor = System.Drawing.Color.White;
            this.btnEmuKill.Location = new System.Drawing.Point(430, 9);
            this.btnEmuKill.Name = "btnEmuKill";
            this.btnEmuKill.Size = new System.Drawing.Size(130, 30);
            this.btnEmuKill.TabIndex = 6;
            this.btnEmuKill.Text = "KILL";
            this.btnEmuKill.Click += new System.EventHandler(this.btnEmuKill_Click);
            // 
            // lblRowEmuKill
            // 
            this.lblRowEmuKill.AutoSize = true;
            this.lblRowEmuKill.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
            this.lblRowEmuKill.ForeColor = System.Drawing.Color.White;
            this.lblRowEmuKill.Location = new System.Drawing.Point(20, 14);
            this.lblRowEmuKill.Name = "lblRowEmuKill";
            this.lblRowEmuKill.Size = new System.Drawing.Size(124, 18);
            this.lblRowEmuKill.TabIndex = 5;
            this.lblRowEmuKill.Text = "KILL EMULATOR";
            // 
            // btnHyperFix
            // 
            this.btnHyperFix.BorderRadius = 10;
            this.btnHyperFix.FillColor = System.Drawing.Color.Red;
            this.btnHyperFix.FillColor2 = System.Drawing.Color.Maroon;
            this.btnHyperFix.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.btnHyperFix.ForeColor = System.Drawing.Color.White;
            this.btnHyperFix.Location = new System.Drawing.Point(430, 9);
            this.btnHyperFix.Name = "btnHyperFix";
            this.btnHyperFix.Size = new System.Drawing.Size(130, 30);
            this.btnHyperFix.TabIndex = 4;
            this.btnHyperFix.Text = "FIX + REBOOT";
            this.btnHyperFix.Click += new System.EventHandler(this.btnHyperFix_Click);
            // 
            // lblRowHyperFix
            // 
            this.lblRowHyperFix.AutoSize = true;
            this.lblRowHyperFix.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
            this.lblRowHyperFix.ForeColor = System.Drawing.Color.White;
            this.lblRowHyperFix.Location = new System.Drawing.Point(20, 14);
            this.lblRowHyperFix.Name = "lblRowHyperFix";
            this.lblRowHyperFix.Size = new System.Drawing.Size(185, 18);
            this.lblRowHyperFix.TabIndex = 3;
            this.lblRowHyperFix.Text = "HYPER-V OFF (REBOOT)";
            // 
            // btnHyperCheck
            // 
            this.btnHyperCheck.BorderRadius = 6;
            this.btnHyperCheck.Font = new System.Drawing.Font("Segoe UI", 8F, System.Drawing.FontStyle.Bold);
            this.btnHyperCheck.ForeColor = System.Drawing.Color.White;
            this.btnHyperCheck.Location = new System.Drawing.Point(430, 9);
            this.btnHyperCheck.Name = "btnHyperCheck";
            this.btnHyperCheck.Size = new System.Drawing.Size(130, 30);
            this.btnHyperCheck.TabIndex = 2;
            this.btnHyperCheck.Text = "CHECK";
            this.btnHyperCheck.Click += new System.EventHandler(this.btnHyperCheck_Click);
            // 
            // lblRowHyper
            // 
            this.lblRowHyper.AutoSize = true;
            this.lblRowHyper.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
            this.lblRowHyper.ForeColor = System.Drawing.Color.Red;
            this.lblRowHyper.Location = new System.Drawing.Point(20, 14);
            this.lblRowHyper.Name = "lblRowHyper";
            this.lblRowHyper.Size = new System.Drawing.Size(135, 18);
            this.lblRowHyper.TabIndex = 1;
            this.lblRowHyper.Text = "HYPER-V STATUS";
            // 
            // lblBypassTitle
            // 
            this.lblBypassTitle.AutoSize = true;
            this.lblBypassTitle.Font = new System.Drawing.Font("Segoe UI", 14F, System.Drawing.FontStyle.Bold);
            this.lblBypassTitle.ForeColor = System.Drawing.Color.Red;
            this.lblBypassTitle.Location = new System.Drawing.Point(28, 14);
            this.lblBypassTitle.Name = "lblBypassTitle";
            this.lblBypassTitle.Size = new System.Drawing.Size(192, 25);
            this.lblBypassTitle.TabIndex = 0;
            this.lblBypassTitle.Text = "BYPASS & EMULATOR";
            // 
            // barAim
            // 
            this.barAim.Location = new System.Drawing.Point(15, 16);
            this.barAim.Name = "barAim";
            this.barAim.Size = new System.Drawing.Size(4, 24);
            // 
            // divAim
            // 
            this.divAim.Location = new System.Drawing.Point(15, 50);
            this.divAim.Name = "divAim";
            this.divAim.Size = new System.Drawing.Size(580, 1);
            // 
            // barFfMax
            // 
            this.barFfMax.Location = new System.Drawing.Point(15, 16);
            this.barFfMax.Name = "barFfMax";
            this.barFfMax.Size = new System.Drawing.Size(4, 24);
            // 
            // divFfMax
            // 
            this.divFfMax.Location = new System.Drawing.Point(15, 50);
            this.divFfMax.Name = "divFfMax";
            this.divFfMax.Size = new System.Drawing.Size(580, 1);
            // 
            // barChams
            // 
            this.barChams.Location = new System.Drawing.Point(15, 16);
            this.barChams.Name = "barChams";
            this.barChams.Size = new System.Drawing.Size(4, 24);
            // 
            // divChams
            // 
            this.divChams.Location = new System.Drawing.Point(15, 50);
            this.divChams.Name = "divChams";
            this.divChams.Size = new System.Drawing.Size(580, 1);
            // 
            // barExt
            // 
            this.barExt.Location = new System.Drawing.Point(15, 16);
            this.barExt.Name = "barExt";
            this.barExt.Size = new System.Drawing.Size(4, 24);
            // 
            // divExt
            // 
            this.divExt.Location = new System.Drawing.Point(15, 50);
            this.divExt.Name = "divExt";
            this.divExt.Size = new System.Drawing.Size(580, 1);
            // 
            // barSet
            // 
            this.barSet.Location = new System.Drawing.Point(15, 16);
            this.barSet.Name = "barSet";
            this.barSet.Size = new System.Drawing.Size(4, 24);
            // 
            // divSet
            // 
            this.divSet.Location = new System.Drawing.Point(15, 50);
            this.divSet.Name = "divSet";
            this.divSet.Size = new System.Drawing.Size(580, 1);
            // 
            // barBypass
            // 
            this.barBypass.Location = new System.Drawing.Point(15, 16);
            this.barBypass.Name = "barBypass";
            this.barBypass.Size = new System.Drawing.Size(4, 24);
            // 
            // divBypass
            // 
            this.divBypass.Location = new System.Drawing.Point(15, 50);
            this.divBypass.Name = "divBypass";
            this.divBypass.Size = new System.Drawing.Size(580, 1);
            // 
            // barTest
            // 
            this.barTest.Location = new System.Drawing.Point(15, 16);
            this.barTest.Name = "barTest";
            this.barTest.Size = new System.Drawing.Size(4, 24);
            // 
            // divTest
            // 
            this.divTest.Location = new System.Drawing.Point(15, 50);
            this.divTest.Name = "divTest";
            this.divTest.Size = new System.Drawing.Size(580, 1);
            // 
            // cardAimMatch
            // 
            this.cardAimMatch.Location = new System.Drawing.Point(15, 76);
            this.cardAimMatch.Name = "cardAimMatch";
            this.cardAimMatch.Size = new System.Drawing.Size(580, 78);
            // 
            // cardAimRun
            // 
            this.cardAimRun.Location = new System.Drawing.Point(15, 166);
            this.cardAimRun.Name = "cardAimRun";
            this.cardAimRun.Size = new System.Drawing.Size(580, 84);
            // 
            // cardFfMaxRow
            // 
            this.cardFfMaxRow.Location = new System.Drawing.Point(15, 76);
            this.cardFfMaxRow.Name = "cardFfMaxRow";
            this.cardFfMaxRow.Size = new System.Drawing.Size(580, 78);
            // 
            // cardFfMaxRun
            // 
            this.cardFfMaxRun.Location = new System.Drawing.Point(15, 166);
            this.cardFfMaxRun.Name = "cardFfMaxRun";
            this.cardFfMaxRun.Size = new System.Drawing.Size(580, 84);
            // 
            // cardChamsFix
            // 
            this.cardChamsFix.Location = new System.Drawing.Point(15, 76);
            this.cardChamsFix.Name = "cardChamsFix";
            this.cardChamsFix.Size = new System.Drawing.Size(580, 78);
            // 
            // cardChamsTrans
            // 
            this.cardChamsTrans.Location = new System.Drawing.Point(15, 162);
            this.cardChamsTrans.Name = "cardChamsTrans";
            this.cardChamsTrans.Size = new System.Drawing.Size(580, 78);
            // 
            // cardChamsRun
            // 
            this.cardChamsRun.Location = new System.Drawing.Point(15, 248);
            this.cardChamsRun.Name = "cardChamsRun";
            this.cardChamsRun.Size = new System.Drawing.Size(580, 84);
            // 
            // cardScope
            // 
            this.cardScope.Location = new System.Drawing.Point(15, 76);
            this.cardScope.Name = "cardScope";
            this.cardScope.Size = new System.Drawing.Size(283, 104);
            // 
            // cardGlitch
            // 
            this.cardGlitch.Location = new System.Drawing.Point(312, 76);
            this.cardGlitch.Name = "cardGlitch";
            this.cardGlitch.Size = new System.Drawing.Size(283, 104);
            // 
            // cardSpeed
            // 
            this.cardSpeed.Location = new System.Drawing.Point(15, 188);
            this.cardSpeed.Name = "cardSpeed";
            this.cardSpeed.Size = new System.Drawing.Size(283, 104);
            // 
            // cardSwitch
            // 
            this.cardSwitch.Location = new System.Drawing.Point(312, 188);
            this.cardSwitch.Name = "cardSwitch";
            this.cardSwitch.Size = new System.Drawing.Size(283, 104);
            // 
            // cardScopeKey
            // 
            this.cardScopeKey.Location = new System.Drawing.Point(15, 300);
            this.cardScopeKey.Name = "cardScopeKey";
            this.cardScopeKey.Size = new System.Drawing.Size(580, 78);
            // 
            // cardSetTheme
            // 
            this.cardSetTheme.Location = new System.Drawing.Point(15, 76);
            this.cardSetTheme.Name = "cardSetTheme";
            this.cardSetTheme.Size = new System.Drawing.Size(580, 52);
            // 
            // cardSetAccent
            // 
            this.cardSetAccent.Location = new System.Drawing.Point(15, 134);
            this.cardSetAccent.Name = "cardSetAccent";
            this.cardSetAccent.Size = new System.Drawing.Size(580, 52);
            // 
            // cardSetBg
            // 
            this.cardSetBg.Location = new System.Drawing.Point(15, 192);
            this.cardSetBg.Name = "cardSetBg";
            this.cardSetBg.Size = new System.Drawing.Size(580, 52);
            // 
            // cardSetHide
            // 
            this.cardSetHide.Location = new System.Drawing.Point(15, 250);
            this.cardSetHide.Name = "cardSetHide";
            this.cardSetHide.Size = new System.Drawing.Size(580, 52);
            // 
            // cardSetStream
            // 
            this.cardSetStream.Location = new System.Drawing.Point(15, 308);
            this.cardSetStream.Name = "cardSetStream";
            this.cardSetStream.Size = new System.Drawing.Size(580, 52);
            // 
            // cardSetLog
            // 
            this.cardSetLog.Location = new System.Drawing.Point(15, 366);
            this.cardSetLog.Name = "cardSetLog";
            this.cardSetLog.Size = new System.Drawing.Size(580, 52);
            // 
            // cardBpOb1
            // 
            this.cardBpOb1.Location = new System.Drawing.Point(15, 76);
            this.cardBpOb1.Name = "cardBpOb1";
            this.cardBpOb1.Size = new System.Drawing.Size(580, 48);
            // 
            // cardBpOb2
            // 
            this.cardBpOb2.Location = new System.Drawing.Point(15, 128);
            this.cardBpOb2.Name = "cardBpOb2";
            this.cardBpOb2.Size = new System.Drawing.Size(580, 48);
            // 
            // cardBpEmuAuto
            // 
            this.cardBpEmuAuto.Location = new System.Drawing.Point(15, 180);
            this.cardBpEmuAuto.Name = "cardBpEmuAuto";
            this.cardBpEmuAuto.Size = new System.Drawing.Size(580, 48);
            // 
            // cardBpEmuKill
            // 
            this.cardBpEmuKill.Location = new System.Drawing.Point(15, 232);
            this.cardBpEmuKill.Name = "cardBpEmuKill";
            this.cardBpEmuKill.Size = new System.Drawing.Size(580, 48);
            // 
            // cardBpHyper
            // 
            this.cardBpHyper.Location = new System.Drawing.Point(15, 284);
            this.cardBpHyper.Name = "cardBpHyper";
            this.cardBpHyper.Size = new System.Drawing.Size(580, 48);
            // 
            // cardBpHyperFix
            // 
            this.cardBpHyperFix.Location = new System.Drawing.Point(15, 336);
            this.cardBpHyperFix.Name = "cardBpHyperFix";
            this.cardBpHyperFix.Size = new System.Drawing.Size(580, 48);
            // 
            // cardTestSaim
            // 
            this.cardTestSaim.Location = new System.Drawing.Point(15, 76);
            this.cardTestSaim.Name = "cardTestSaim";
            this.cardTestSaim.Size = new System.Drawing.Size(580, 70);
            // 
            // cardTest5566
            // 
            this.cardTest5566.Location = new System.Drawing.Point(15, 154);
            this.cardTest5566.Name = "cardTest5566";
            this.cardTest5566.Size = new System.Drawing.Size(580, 70);
            // 
            // cardTestSwitch
            // 
            this.cardTestSwitch.Location = new System.Drawing.Point(15, 232);
            this.cardTestSwitch.Name = "cardTestSwitch";
            this.cardTestSwitch.Size = new System.Drawing.Size(580, 70);
            // 
            // lblAimMatchDesc
            // 
            this.cardAimMatch.Controls.Add(this.lblAimMatchDesc);
            this.lblAimMatchDesc.AutoSize = false;
            this.lblAimMatchDesc.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.lblAimMatchDesc.ForeColor = System.Drawing.Color.White;
            this.lblAimMatchDesc.Location = new System.Drawing.Point(20, 36);
            this.lblAimMatchDesc.Name = "lblAimMatchDesc";
            this.lblAimMatchDesc.Size = new System.Drawing.Size(400, 16);
            this.lblAimMatchDesc.Text = "Press the hotkey once per match to run the aimbot scan";
            // 
            // lblFfMaxDesc
            // 
            this.cardFfMaxRow.Controls.Add(this.lblFfMaxDesc);
            this.lblFfMaxDesc.AutoSize = false;
            this.lblFfMaxDesc.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.lblFfMaxDesc.ForeColor = System.Drawing.Color.White;
            this.lblFfMaxDesc.Location = new System.Drawing.Point(20, 36);
            this.lblFfMaxDesc.Name = "lblFfMaxDesc";
            this.lblFfMaxDesc.Size = new System.Drawing.Size(400, 16);
            this.lblFfMaxDesc.Text = "Press the hotkey to run the FF MAX aim scan";
            // 
            // lblChamsFixDesc
            // 
            this.cardChamsFix.Controls.Add(this.lblChamsFixDesc);
            this.lblChamsFixDesc.AutoSize = false;
            this.lblChamsFixDesc.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.lblChamsFixDesc.ForeColor = System.Drawing.Color.White;
            this.lblChamsFixDesc.Location = new System.Drawing.Point(20, 36);
            this.lblChamsFixDesc.Name = "lblChamsFixDesc";
            this.lblChamsFixDesc.Size = new System.Drawing.Size(440, 16);
            this.lblChamsFixDesc.Text = "Fix chams for 64-bit emulator builds";
            // 
            // lblChamsTransDesc
            // 
            this.cardChamsTrans.Controls.Add(this.lblChamsTransDesc);
            this.lblChamsTransDesc.AutoSize = false;
            this.lblChamsTransDesc.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.lblChamsTransDesc.ForeColor = System.Drawing.Color.White;
            this.lblChamsTransDesc.Location = new System.Drawing.Point(20, 36);
            this.lblChamsTransDesc.Name = "lblChamsTransDesc";
            this.lblChamsTransDesc.Size = new System.Drawing.Size(440, 16);
            this.lblChamsTransDesc.Text = "See enemies through walls with transparency";
            // 
            // lblScopeDesc
            // 
            this.cardScope.Controls.Add(this.lblScopeDesc);
            this.lblScopeDesc.AutoSize = false;
            this.lblScopeDesc.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.lblScopeDesc.ForeColor = System.Drawing.Color.White;
            this.lblScopeDesc.Location = new System.Drawing.Point(20, 38);
            this.lblScopeDesc.Name = "lblScopeDesc";
            this.lblScopeDesc.Size = new System.Drawing.Size(190, 30);
            this.lblScopeDesc.Text = "Sniper scope aim improvement";
            // 
            // lblGlitchDesc
            // 
            this.cardGlitch.Controls.Add(this.lblGlitchDesc);
            this.lblGlitchDesc.AutoSize = false;
            this.lblGlitchDesc.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.lblGlitchDesc.ForeColor = System.Drawing.Color.White;
            this.lblGlitchDesc.Location = new System.Drawing.Point(20, 38);
            this.lblGlitchDesc.Name = "lblGlitchDesc";
            this.lblGlitchDesc.Size = new System.Drawing.Size(190, 30);
            this.lblGlitchDesc.Text = "Fix the screen glitch effect";
            // 
            // lblSpeedDesc
            // 
            this.cardSpeed.Controls.Add(this.lblSpeedDesc);
            this.lblSpeedDesc.AutoSize = false;
            this.lblSpeedDesc.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.lblSpeedDesc.ForeColor = System.Drawing.Color.White;
            this.lblSpeedDesc.Location = new System.Drawing.Point(20, 38);
            this.lblSpeedDesc.Name = "lblSpeedDesc";
            this.lblSpeedDesc.Size = new System.Drawing.Size(190, 30);
            this.lblSpeedDesc.Text = "Small speed boost while moving";
            // 
            // lblSwitchDesc
            // 
            this.cardSwitch.Controls.Add(this.lblSwitchDesc);
            this.lblSwitchDesc.AutoSize = false;
            this.lblSwitchDesc.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.lblSwitchDesc.ForeColor = System.Drawing.Color.White;
            this.lblSwitchDesc.Location = new System.Drawing.Point(20, 38);
            this.lblSwitchDesc.Name = "lblSwitchDesc";
            this.lblSwitchDesc.Size = new System.Drawing.Size(190, 30);
            this.lblSwitchDesc.Text = "Fast weapon switch boost";
            // 
            // lblRowScopeKey
            // 
            this.cardScopeKey.Controls.Add(this.lblRowScopeKey);
            this.lblRowScopeKey.AutoSize = false;
            this.lblRowScopeKey.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
            this.lblRowScopeKey.ForeColor = System.Drawing.Color.White;
            this.lblRowScopeKey.Location = new System.Drawing.Point(20, 12);
            this.lblRowScopeKey.Name = "lblRowScopeKey";
            this.lblRowScopeKey.Size = new System.Drawing.Size(300, 20);
            this.lblRowScopeKey.Text = "SCOPE HOTKEY";
            // 
            // lblScopeKeyDesc
            // 
            this.cardScopeKey.Controls.Add(this.lblScopeKeyDesc);
            this.lblScopeKeyDesc.AutoSize = false;
            this.lblScopeKeyDesc.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.lblScopeKeyDesc.ForeColor = System.Drawing.Color.White;
            this.lblScopeKeyDesc.Location = new System.Drawing.Point(20, 36);
            this.lblScopeKeyDesc.Name = "lblScopeKeyDesc";
            this.lblScopeKeyDesc.Size = new System.Drawing.Size(400, 16);
            this.lblScopeKeyDesc.Text = "Press the hotkey to toggle the scope feature";
            // 
            // lblTestSaimDesc
            // 
            this.cardTestSaim.Controls.Add(this.lblTestSaimDesc);
            this.lblTestSaimDesc.AutoSize = false;
            this.lblTestSaimDesc.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.lblTestSaimDesc.ForeColor = System.Drawing.Color.White;
            this.lblTestSaimDesc.Location = new System.Drawing.Point(20, 36);
            this.lblTestSaimDesc.Name = "lblTestSaimDesc";
            this.lblTestSaimDesc.Size = new System.Drawing.Size(440, 16);
            this.lblTestSaimDesc.Text = "Enable the aim test toggle";
            // 
            // lblTest5566Desc
            // 
            this.cardTest5566.Controls.Add(this.lblTest5566Desc);
            this.lblTest5566Desc.AutoSize = false;
            this.lblTest5566Desc.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.lblTest5566Desc.ForeColor = System.Drawing.Color.White;
            this.lblTest5566Desc.Location = new System.Drawing.Point(20, 36);
            this.lblTest5566Desc.Name = "lblTest5566Desc";
            this.lblTest5566Desc.Size = new System.Drawing.Size(440, 16);
            this.lblTest5566Desc.Text = "Enable the 5566 search and replace test";
            // 
            // lblTestSwitchDesc
            // 
            this.cardTestSwitch.Controls.Add(this.lblTestSwitchDesc);
            this.lblTestSwitchDesc.AutoSize = false;
            this.lblTestSwitchDesc.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.lblTestSwitchDesc.ForeColor = System.Drawing.Color.White;
            this.lblTestSwitchDesc.Location = new System.Drawing.Point(20, 36);
            this.lblTestSwitchDesc.Name = "lblTestSwitchDesc";
            this.lblTestSwitchDesc.Size = new System.Drawing.Size(440, 16);
            this.lblTestSwitchDesc.Text = "Enable the switch test toggle";
            // 
            // lblExtInfo
            // 
            this.pnlExternal.Controls.Add(this.lblExtInfo);
            this.lblExtInfo.AutoSize = false;
            this.lblExtInfo.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.lblExtInfo.ForeColor = System.Drawing.Color.White;
            this.lblExtInfo.Location = new System.Drawing.Point(28, 58);
            this.lblExtInfo.Name = "lblExtInfo";
            this.lblExtInfo.Size = new System.Drawing.Size(500, 16);
            this.lblExtInfo.Text = "Toggle external gameplay features";
            // 
            // pnlBottom
            // 
            this.pnlBottom.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(20)))), ((int)(((byte)(20)))));
            this.pnlBottom.Controls.Add(this.lblFps);
            this.pnlBottom.Controls.Add(this.lblPing);
            this.pnlBottom.Controls.Add(this.Sta);
            this.pnlBottom.Controls.Add(this.label2);
            this.pnlBottom.Location = new System.Drawing.Point(0, 485);
            this.pnlBottom.Name = "pnlBottom";
            this.pnlBottom.Size = new System.Drawing.Size(760, 35);
            this.pnlBottom.TabIndex = 35;
            // 
            // lblFps
            // 
            this.lblFps.AutoSize = true;
            this.lblFps.BackColor = System.Drawing.Color.Transparent;
            this.lblFps.Font = new System.Drawing.Font("Segoe UI", 8F, System.Drawing.FontStyle.Bold);
            this.lblFps.ForeColor = System.Drawing.Color.Cyan;
            this.lblFps.Location = new System.Drawing.Point(660, 10);
            this.lblFps.Name = "lblFps";
            this.lblFps.Size = new System.Drawing.Size(40, 13);
            this.lblFps.TabIndex = 3;
            this.lblFps.Text = "FPS: --";
            // 
            // lblPing
            // 
            this.lblPing.AutoSize = true;
            this.lblPing.BackColor = System.Drawing.Color.Transparent;
            this.lblPing.Font = new System.Drawing.Font("Segoe UI", 8F, System.Drawing.FontStyle.Bold);
            this.lblPing.ForeColor = System.Drawing.Color.Lime;
            this.lblPing.Location = new System.Drawing.Point(560, 10);
            this.lblPing.Name = "lblPing";
            this.lblPing.Size = new System.Drawing.Size(48, 13);
            this.lblPing.TabIndex = 2;
            this.lblPing.Text = "PING: --";
            // 
            // Sta
            // 
            this.Sta.AutoSize = true;
            this.Sta.BackColor = System.Drawing.Color.Transparent;
            this.Sta.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Sta.ForeColor = System.Drawing.Color.White;
            this.Sta.Location = new System.Drawing.Point(100, 9);
            this.Sta.Name = "Sta";
            this.Sta.Size = new System.Drawing.Size(33, 18);
            this.Sta.TabIndex = 1;
            this.Sta.Text = "N/A";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Javanese Text", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(8, 2);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(87, 32);
            this.label2.TabIndex = 0;
            this.label2.Text = "STATUS : ";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Black;
            this.ClientSize = new System.Drawing.Size(760, 520);
            this.Controls.Add(this.pnlBottom);
            this.Controls.Add(this.pnlTest);
            this.Controls.Add(this.pnlBypass);
            this.Controls.Add(this.pnlSettings);
            this.Controls.Add(this.pnlExternal);
            this.Controls.Add(this.pnlChams);
            this.Controls.Add(this.pnlAimbot);
            this.Controls.Add(this.pnlFfMax);
            this.Controls.Add(this.pnlSide);
            this.Controls.Add(this.shayanHeader1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Form1";
            this.Text = "11:11 ON TOP";
            this.pnlSide.ResumeLayout(false);
            this.pnlSide.PerformLayout();
            this.pnlAimbot.ResumeLayout(false);
            this.pnlAimbot.PerformLayout();
            this.pnlFfMax.ResumeLayout(false);
            this.pnlFfMax.PerformLayout();
            this.pnlChams.ResumeLayout(false);
            this.pnlChams.PerformLayout();
            this.pnlExternal.ResumeLayout(false);
            this.pnlExternal.PerformLayout();
            this.pnlSettings.ResumeLayout(false);
            this.pnlSettings.PerformLayout();
            this.pnlTest.ResumeLayout(false);
            this.pnlTest.PerformLayout();
            this.pnlBypass.ResumeLayout(false);
            this.pnlBypass.PerformLayout();
            this.pnlBottom.ResumeLayout(false);
            this.pnlBottom.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel barAim;
        private System.Windows.Forms.Panel divAim;
        private System.Windows.Forms.Panel barFfMax;
        private System.Windows.Forms.Panel divFfMax;
        private System.Windows.Forms.Panel barChams;
        private System.Windows.Forms.Panel divChams;
        private System.Windows.Forms.Panel barExt;
        private System.Windows.Forms.Panel divExt;
        private System.Windows.Forms.Panel barSet;
        private System.Windows.Forms.Panel divSet;
        private System.Windows.Forms.Panel barBypass;
        private System.Windows.Forms.Panel divBypass;
        private System.Windows.Forms.Panel barTest;
        private System.Windows.Forms.Panel divTest;
        private System.Windows.Forms.Panel cardAimMatch;
        private System.Windows.Forms.Panel cardAimRun;
        private System.Windows.Forms.Panel cardFfMaxRow;
        private System.Windows.Forms.Panel cardFfMaxRun;
        private System.Windows.Forms.Panel cardChamsFix;
        private System.Windows.Forms.Panel cardChamsTrans;
        private System.Windows.Forms.Panel cardChamsRun;
        private System.Windows.Forms.Panel cardScope;
        private System.Windows.Forms.Panel cardGlitch;
        private System.Windows.Forms.Panel cardSpeed;
        private System.Windows.Forms.Panel cardSwitch;
        private System.Windows.Forms.Panel cardScopeKey;
        private System.Windows.Forms.Panel cardSetTheme;
        private System.Windows.Forms.Panel cardSetAccent;
        private System.Windows.Forms.Panel cardSetBg;
        private System.Windows.Forms.Panel cardSetHide;
        private System.Windows.Forms.Panel cardSetStream;
        private System.Windows.Forms.Panel cardSetLog;
        private System.Windows.Forms.Panel cardBpOb1;
        private System.Windows.Forms.Panel cardBpOb2;
        private System.Windows.Forms.Panel cardBpEmuAuto;
        private System.Windows.Forms.Panel cardBpEmuKill;
        private System.Windows.Forms.Panel cardBpHyper;
        private System.Windows.Forms.Panel cardBpHyperFix;
        private System.Windows.Forms.Panel cardTestSaim;
        private System.Windows.Forms.Panel cardTest5566;
        private System.Windows.Forms.Panel cardTestSwitch;
        private System.Windows.Forms.Label lblAimMatchDesc;
        private System.Windows.Forms.Label lblFfMaxDesc;
        private System.Windows.Forms.Label lblChamsFixDesc;
        private System.Windows.Forms.Label lblChamsTransDesc;
        private System.Windows.Forms.Label lblScopeDesc;
        private System.Windows.Forms.Label lblGlitchDesc;
        private System.Windows.Forms.Label lblSpeedDesc;
        private System.Windows.Forms.Label lblSwitchDesc;
        private System.Windows.Forms.Label lblRowScopeKey;
        private System.Windows.Forms.Label lblScopeKeyDesc;
        private System.Windows.Forms.Label lblTestSaimDesc;
        private System.Windows.Forms.Label lblTest5566Desc;
        private System.Windows.Forms.Label lblTestSwitchDesc;
        private System.Windows.Forms.Label lblExtInfo;
        private Guna.UI2.WinForms.Guna2BorderlessForm guna2BorderlessForm1;
        private ShayanUI.ShayanHeader shayanHeader1;
        private System.Windows.Forms.Panel pnlSide;
        private Guna.UI2.WinForms.Guna2Button btnNavAimbot;
        private Guna.UI2.WinForms.Guna2Button btnNavFfMax;
        private System.Windows.Forms.Panel pnlFfMax;
        private Guna.UI2.WinForms.Guna2GradientButton btnFfMaxRun;
        private Guna.UI2.WinForms.Guna2Button btnFfMaxKey;
        private System.Windows.Forms.Label lblFfMaxTitle;
        private System.Windows.Forms.Label lblFfMaxInfo;
        private System.Windows.Forms.Label lblFfMaxRow;
        private Guna.UI2.WinForms.Guna2Button btnNavChams;
        private Guna.UI2.WinForms.Guna2Button btnNavExternal;
        private Guna.UI2.WinForms.Guna2Button btnNavSettings;
        private Guna.UI2.WinForms.Guna2Button btnNavBypass;
        private Guna.UI2.WinForms.Guna2Button btnNavTest;
        private System.Windows.Forms.Label lblVerSide;
        private System.Windows.Forms.Panel pnlAimbot;
        private System.Windows.Forms.Label lblAimTitle;
        private Guna.UI2.WinForms.Guna2GradientButton btnAimRun;
        private System.Windows.Forms.Label lblAimInfo;
        private System.Windows.Forms.Label lblRowAimMatch;
        private Guna.UI2.WinForms.Guna2Button btnAimKeyMatch;
        private System.Windows.Forms.Panel pnlChams;
        private System.Windows.Forms.Label lblChamsTitle;
        private Guna.UI2.WinForms.Guna2GradientButton btnChamsRun;
        private System.Windows.Forms.Label lblChamsInfo;
        private System.Windows.Forms.Panel pnlExternal;
        private System.Windows.Forms.Label lblExtTitle;
        private System.Windows.Forms.Label lblScope;
        private Guna.UI2.WinForms.Guna2CustomCheckBox chkScope;
        private Guna.UI2.WinForms.Guna2Button btnScopeKey;
        private System.Windows.Forms.Label lblSwitch;
        private Guna.UI2.WinForms.Guna2CustomCheckBox chkSwitch;
        private System.Windows.Forms.Label lblGlitch;
        private Guna.UI2.WinForms.Guna2CustomCheckBox chkGlitch;
        private System.Windows.Forms.Label lblSpeed;
        private Guna.UI2.WinForms.Guna2CustomCheckBox chkSpeed;
        private System.Windows.Forms.Panel pnlSettings;
        private System.Windows.Forms.Label lblSetTitle;
        private System.Windows.Forms.Label lblRowLog;
        private Guna.UI2.WinForms.Guna2Button btnViewLog;
        private System.Windows.Forms.Label lblRowStream;
        private Guna.UI2.WinForms.Guna2Button btnStreamer;
        private System.Windows.Forms.Label lblRowHide;
        private Guna.UI2.WinForms.Guna2Button btnHideKey;
        private Guna.UI2.WinForms.Guna2Button btnTheme;
        private System.Windows.Forms.Label lblRowTheme;
        private Guna.UI2.WinForms.Guna2Button btnBgColor;
        private System.Windows.Forms.Label lblRowBgColor;
        private Guna.UI2.WinForms.Guna2Button btnAccentColor;
        private System.Windows.Forms.Label lblRowAccent;
        private System.Windows.Forms.Panel pnlBypass;
        private System.Windows.Forms.Label lblBypassTitle;
        private System.Windows.Forms.Label lblRowHyper;
        private Guna.UI2.WinForms.Guna2Button btnHyperCheck;
        private System.Windows.Forms.Label lblRowHyperFix;
        private Guna.UI2.WinForms.Guna2GradientButton btnHyperFix;
        private System.Windows.Forms.Label lblRowEmuKill;
        private Guna.UI2.WinForms.Guna2GradientButton btnEmuKill;
        private System.Windows.Forms.Label lblRowEmuAuto;
        private Guna.UI2.WinForms.Guna2GradientButton btnEmuAuto;
        private System.Windows.Forms.Label lblHyperVal;
        private Guna.UI2.WinForms.Guna2GradientButton btnBypassOb1;
        private System.Windows.Forms.Label lblRowBypassOb1;
        private Guna.UI2.WinForms.Guna2GradientButton btnBypassOb2;
        private System.Windows.Forms.Label lblRowBypassOb2;
        private System.Windows.Forms.Panel pnlTest;
        private System.Windows.Forms.Label lblTestTitle;
        private System.Windows.Forms.Label lblTestSwitch;
        private Guna.UI2.WinForms.Guna2CustomCheckBox chkTestSwitch;
        private System.Windows.Forms.Label lblTestSaim;
        private Guna.UI2.WinForms.Guna2CustomCheckBox chkTestSaim;
        private Guna.UI2.WinForms.Guna2CustomCheckBox chkTest5566;
        private System.Windows.Forms.Label lblTest5566;
        private System.Windows.Forms.Label lblChamsTrans;
        private Guna.UI2.WinForms.Guna2CustomCheckBox chkChamsTrans;
        private System.Windows.Forms.Label lblChamsFix64;
        private Guna.UI2.WinForms.Guna2CustomCheckBox chkChamsFix64;
        private System.Windows.Forms.Panel pnlBottom;
        private System.Windows.Forms.Label label2;
        public System.Windows.Forms.Label Sta;
        private System.Windows.Forms.Label lblPing;
        private System.Windows.Forms.Label lblFps;
    }
}
