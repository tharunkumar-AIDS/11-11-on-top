﻿using AIMBOT_AI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace zafkialontop
{
    internal static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.ThreadException += (s, e) =>
                MessageBox.Show("Error: " + e.Exception.GetType().Name + "\n" + e.Exception.Message, "Crash Report");
            AppDomain.CurrentDomain.UnhandledException += (s, e) =>
                MessageBox.Show("Error: " + (e.ExceptionObject as Exception)?.Message, "Crash Report");
            LoginForm login = new LoginForm();

            // Login வெற்றிகரமாக முடிந்தால் மட்டுமே Form1 ஓபன் ஆகும்
            if (login.ShowDialog() == DialogResult.OK)
            {
                Application.Run(new Form1());
            }
        
        
        }
    }
}
