﻿using AYUSH;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Gma.System.MouseKeyHook;
using DiscordRPC;
using FAST_MEMORY;
using Nazmulscope;

namespace zafkialontop
{
    // EXTERNAL section (sniper/scope/switch/glitch/speed AoB) — taniya file (partial class, Form1 oda same class)
    public partial class Form1
    {
        // ★★★ FEATURE: EXTERNAL — sniper/scope/switch/glitch/speed AoB patterns + checkboxes (merged single page)
        // ============ EXTERNAL SECTION (merged single page) ============
        private nazmulexe nazmulscope = new nazmulexe();
        private FAST_MEMORY.FastMemory sniperMem = new FAST_MEMORY.FastMemory();
        private FAST_MEMORY.FastMemory hackMem = new FAST_MEMORY.FastMemory();

        private bool sniperLoaded = false;
        private Keys scopeKey = Keys.None;
        private IKeyboardMouseEvents scopeHook;
        private int ScopeDelay = 90;
        private List<long> sniperAddresses = new List<long>();
        private string sniperSearch = "00 00 00 00 A0 42 00 00 C0 3F 33 33 13 40 00 00 D0 3F 00 00 80 3F 01 00 01 00 ?? ?? ?? ?? ?? ?? ?? ?? 00 00 00 00 FF FF FF FF 64 D9 03 00 B1 B2 03 00 B6 B2 03 00 B1 B2 03 00 01 00 00 00 9A 99 99 3E FF FF FF FF 08 00 00 00 00 00 60 40 CD CC 8C 3F 8F C2 F5 3C CD CC CC 3D 06 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 80 3F 33 33 13 40 00 00 B0 3F 00 00 80 3F 01 00 00 00 ?? ?? ?? ?? ?? ?? ?? ?? 00 00 00 00 ?? ?? ?? ?? ?? ?? ?? 00 ?? ?? ?? 00 ?? ?? ?? 00 ?? ?? ?? 00 ?? 00 ?? 00 ?? ?? ?? ?? ?? ?? ?? 00 ?? 00 ?? 00 ?? 00 ?? ?? ?? ?? ?? ?? ?? ?? ?? ?? ?? ?? ?? ?? ?? 00 ?? 00 ?? ?? ?? ?? ?? 00 ?? ?? ?? 00 ?? ?? ?? 00 ?? ?? ?? 00 ??";
        private string sniperReplace = "00 00 00 00 A0 42 00 00 C0 3F 33 33 13 40 00 00 D0 3F 00 00 80 3F 01 00 01 00 ?? ?? ?? ?? ?? ?? ?? ?? 00 00 00 00 FF FF FF FF 64 D9 03 00 B1 B2 03 00 B6 B2 03 00 B1 B2 03 00 01 00 00 00 9A 99 99 3E FF FF FF FF 08 00 00 00 00 00 60 40 CD CC 8C 3F 8F C2 F5 3C CD CC CC 3D 06 00 00 00 00 00 00 3E 00 00 00 00 00 00 00 00 00 00 00 00 00 00 80 3F 33 33 13 40 00 00 B0 3F 00 00 80 3F 01 00 00 00 ?? ?? ?? ?? ?? ?? ?? ?? 00 00 00 00 ?? ?? ?? ?? ?? ?? ?? 00 ?? ?? ?? 00 ?? ?? ?? 00 ?? ?? ?? 00 ?? 00 ?? 00 ?? ?? ?? ?? ?? ?? ?? 00 ?? 00 ?? 00 ?? 00 ?? ?? ?? ?? ?? ?? ?? ?? ?? ?? ?? ?? ?? ?? ?? 00 ?? 00 ?? ?? ?? ?? ?? 00 ?? ?? ?? 00 ?? ?? ?? 00 ?? ?? ?? 00 ??";

        private List<long> switchAddresses = new List<long>();
        private string switchSearch = "3F 00 00 80 3E 00 00 00 00 04 00 00 00 00 00 80 3F 00 00 20 41 00 00 34 42 01 00 00 00 01 00 00 00 00 00 00 00 00 00 00 00 00 00 80 3F";
        private string switchReplace = "1A 00 00 80 1A 00 00 00 00 04 00 00 00 00 00 80 3F 00 00 20 41 00 00 34 42 01 00 00 00 01 00 00 00 00 00 00 00 00 00 00 00 00 00 80 3F";

        private List<long> glitchAddresses = new List<long>();
        private string glitchSearch = "90 C1 00 00 70 41 01 00 00 00 00 00 C0 3F 00 00 00 3F 00 00 80 3F";
        private string glitchReplace = "90 C1 00 00 70 41 01 00 00 00 00 00 00 BF 00 00 00 3F 00 00 80 3F";

        private List<long> speedAddresses = new List<long>();
        private string speedSearch = "02 2B 07 3D 02 2B 07 3D 02 2B 07 3D 00 00 00 00 9B 6C F2 41 49 00 00 00";
        private string speedReplace = "0A D7 A3 3C 02 2B 07 3D 02 2B 07 3D 00 00 00 00 9B 6C F2 41 49 00 00 00";

        private void RegisterScopeHook()
        {
            scopeHook?.Dispose(); scopeHook = Hook.GlobalEvents();
            scopeHook.KeyDown += async (s, ev) => { if (ev.KeyCode == scopeKey && sniperLoaded && sniperAddresses.Count > 0) { byte[] r = ParseHex(sniperReplace); foreach (var a in sniperAddresses) sniperMem.WriteBytes(a, r); UpdateStatus($"Scope ON ({ScopeDelay}ms)", Color.Cyan); await Task.Delay(ScopeDelay); byte[] o = ParseHex(sniperSearch); foreach (var a in sniperAddresses) sniperMem.WriteBytes(a, o); UpdateStatus("Scope OFF", Color.Gray); } };
        }

        private void btnScopeKey_Click(object sender, EventArgs e)
        {
            var btn = sender as Guna.UI2.WinForms.Guna2Button; btn.Text = "..."; UpdateStatus("Press key for Scope... (ESC cancel)", Color.Yellow);
            scopeHook?.Dispose(); scopeHook = Hook.GlobalEvents();
            scopeHook.KeyDown += (s, ev) => { if (ev.KeyCode == Keys.Escape) { btn.Text = scopeKey == Keys.None ? "-" : scopeKey.ToString(); scopeHook.Dispose(); return; } scopeKey = ev.KeyCode; btn.Text = scopeKey.ToString(); scopeHook.Dispose(); UpdateStatus($"Scope Key: {scopeKey}", Color.Lime); RegisterScopeHook(); };
        }

        private async void chkScope_CheckedChanged(object sender, EventArgs e)
        {
            if (chkScope.Checked) { if (!sniperMem.OpenProcess(EmuName())) { UpdateStatus("Emulator Not Found! (" + EmuName() + "?)", Color.Red); chkScope.Checked = false; return; } UpdateStatus("Scanning Sniper Scope...", Color.Yellow); var r = await sniperMem.ScanPattern(sniperSearch); sniperAddresses = r.ToList(); if (sniperAddresses.Count > 0) { sniperLoaded = true; byte[] rep = ParseHex(sniperReplace); foreach (var a in sniperAddresses) sniperMem.WriteBytes(a, rep); UpdateStatus($"Sniper ON ({sniperAddresses.Count})", Color.Lime); } else { UpdateStatus("Pattern Not Found!", Color.Red); chkScope.Checked = false; } }
            else { byte[] o = ParseHex(sniperSearch); foreach (var a in sniperAddresses) sniperMem.WriteBytes(a, o); sniperAddresses.Clear(); sniperLoaded = false; UpdateStatus("Sniper OFF", Color.Gray); }
        }

        private async void chkSwitch_CheckedChanged(object sender, EventArgs e)
        {
            if (chkSwitch.Checked) { if (!nazmulscope.SetProcess(EmulatorNames)) { UpdateStatus("Emulator Not Found!", Color.Red); chkSwitch.Checked = false; return; } UpdateStatus("Loading Sniper Switch...", Color.Yellow); var r = await nazmulscope.AoBScan(switchSearch); switchAddresses = r.Distinct().ToList(); if (switchAddresses.Count > 0) { foreach (var a in switchAddresses) nazmulscope.AobReplace(a, switchReplace); UpdateStatus($"Switch ON ({switchAddresses.Count})", Color.Lime); } else { UpdateStatus("Pattern Not Found!", Color.Red); chkSwitch.Checked = false; } }
            else { foreach (var a in switchAddresses) nazmulscope.AobReplace(a, switchSearch); switchAddresses.Clear(); UpdateStatus("Switch OFF", Color.Gray); }
        }

        private async void chkGlitch_CheckedChanged(object sender, EventArgs e)
        {
            if (chkGlitch.Checked) { if (!hackMem.OpenProcess(EmuName())) { UpdateStatus("Emulator Not Found! (" + EmuName() + "?)", Color.Red); chkGlitch.Checked = false; return; } UpdateStatus("Loading Glitch Fire...", Color.Yellow); var r = await hackMem.ScanAndReplace(glitchSearch, glitchReplace); glitchAddresses = r.addresses; if (glitchAddresses.Count > 0) UpdateStatus($"Glitch ON ({glitchAddresses.Count})", Color.Lime); else { UpdateStatus("Pattern Not Found!", Color.Red); chkGlitch.Checked = false; } }
            else { foreach (var a in glitchAddresses) hackMem.WriteBytes(a, ParseHex(glitchSearch)); glitchAddresses.Clear(); UpdateStatus("Glitch OFF", Color.Gray); }
        }


        private async void chkSpeed_CheckedChanged(object sender, EventArgs e)
        {
            if (chkSpeed.Checked) { if (!hackMem.OpenProcess(EmuName())) { UpdateStatus("Emulator Not Found! (" + EmuName() + "?)", Color.Red); chkSpeed.Checked = false; return; } UpdateStatus("Loading Speed Hack...", Color.Yellow); var r = await hackMem.ScanAndReplace(speedSearch, speedReplace); speedAddresses = r.addresses; if (speedAddresses.Count > 0) UpdateStatus($"Speed ON ({speedAddresses.Count})", Color.Lime); else { UpdateStatus("Pattern Not Found!", Color.Red); chkSpeed.Checked = false; } }
            else { byte[] o = ParseHex(speedSearch); foreach (var a in speedAddresses) hackMem.WriteBytes(a, o); speedAddresses.Clear(); UpdateStatus("Speed OFF", Color.Gray); }
        }

    }
}
