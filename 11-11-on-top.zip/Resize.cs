using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Runtime.InteropServices;
using System.Windows.Forms;

namespace zafkialontop
{
    // ★★★ FEATURE: MANUAL RESIZE — edge/corner drag resize + proportional UI scaling ★★★
    //   Rendu mechanism (rendume resize trigger pannum, edhulaa work aanaalum podhum):
    //   1. IMessageFilter — mouse form edge zone la vandha resize cursor + SC_SIZE.
    //      Bare form surface (right gap mari) mela work aagum.
    //   2. INVISIBLE RESIZE STRIPS — edges la thin controls, KEEZH IRUKURA PANEL ODA
    //      EXACT COLOR (visual change ZERO). pnlBottom/pnlSide children ah cover
    //      pannum panels mela um direct MouseDown → resize. Strips MouseDown log
    //      Temp\opencode\resize_log.txt la (diagnostic).
    //   Resize aana ella controls um base layout (760x520) la irundhu proportion-ah
    //   scale aagum (original bounds store → factor recompute → drift illa).
    public partial class Form1
    {
        private class CtrlOrig { public Control C; public Rectangle B; public float FS; }

        private List<CtrlOrig> uiOrig;
        private Size uiBase;
        private bool uiScaling;
        private float uiFontApplied = 1f;
        private ResizeFilter resizeFilter;
        private List<ResizeStrip> resizeStrips;

        // WMSZ_* directions (SC_SIZE | dir)
        private const int WMSZ_LEFT = 1, WMSZ_RIGHT = 2, WMSZ_TOP = 3, WMSZ_TOPLEFT = 4,
                          WMSZ_TOPRIGHT = 5, WMSZ_BOTTOM = 6, WMSZ_BOTTOMLEFT = 7, WMSZ_BOTTOMRIGHT = 8;
        private const int WM_MOUSEMOVE = 0x0200, WM_LBUTTONDOWN = 0x0201,
                          WM_SYSCOMMAND = 0x0112, SC_SIZE = 0xF000;
        private const string RESIZE_LOG = "resize_log.txt";

        [DllImport("user32.dll")]
        private static extern bool ReleaseCapture();
        [DllImport("user32.dll")]
        private static extern IntPtr SendMessage(IntPtr hWnd, int msg, IntPtr wParam, IntPtr lParam);

        private static void LogResize(string what)
        {
            try
            {
                var dir = Path.Combine(Environment.GetEnvironmentVariable("TEMP") ?? "", "opencode");
                if (!Directory.Exists(dir)) Directory.CreateDirectory(dir);
                File.AppendAllText(Path.Combine(dir, RESIZE_LOG),
                    DateTime.Now.ToString("HH:mm:ss") + " " + what + " cursor=" + Cursor.Position + "\r\n");
            }
            catch { }
        }

        private void InitUiResize()
        {
            try
            {
                this.MinimumSize = new Size(532, 364);      // 70% base ku keezh — content romba chinnadha aagadhu
                uiBase = this.ClientSize;                   // 760x520 = scale 1.0
                uiOrig = new List<CtrlOrig>();
                CollectUiOrig(this);
                this.SizeChanged += (s, e) => { ApplyUiScale(); UpdateStripBounds(); };
                CreateResizeStrips();
                resizeFilter = new ResizeFilter(this);
                Application.AddMessageFilter(resizeFilter);
            }
            catch { }
        }

        private void CollectUiOrig(Control parent)
        {
            foreach (Control c in parent.Controls)
            {
                if (c == glowOverlay) continue;             // Dock.Fill — resize automatic
                uiOrig.Add(new CtrlOrig { C = c, B = c.Bounds, FS = c.Font.Size });
                CollectUiOrig(c);
            }
        }

        // ★ Invisible resize strips — keezh panel oda same color → theriyave theriyadhu
        private void CreateResizeStrips()
        {
            resizeStrips = new List<ResizeStrip>
            {
                new ResizeStrip(WMSZ_LEFT,  Cursors.SizeWE)  { Name = "rzL" },
                new ResizeStrip(WMSZ_RIGHT, Cursors.SizeWE)  { Name = "rzR" },
                new ResizeStrip(WMSZ_BOTTOM,Cursors.SizeNS)  { Name = "rzB" },
                new ResizeStrip(WMSZ_BOTTOMLEFT,  Cursors.SizeNESW) { Name = "rzBL" },
                new ResizeStrip(WMSZ_BOTTOMRIGHT, Cursors.SizeNWSE) { Name = "rzBR" }
            };
            foreach (var s in resizeStrips)
            {
                s.TabStop = false;
                this.Controls.Add(s);
                s.BringToFront();
            }
            UpdateStripBounds();
            SyncStripColors();
        }

        private void UpdateStripBounds()
        {
            if (resizeStrips == null) return;
            try
            {
                int w = ClientSize.Width, h = ClientSize.Height;
                int top = shayanHeader1 != null ? shayanHeader1.Bottom : 35;   // header ku keezh — title drag free
                foreach (var s in resizeStrips)
                {
                    switch (s.Name)
                    {
                        case "rzL": s.Bounds = new Rectangle(0, top, 8, h - top); break;
                        case "rzR": s.Bounds = new Rectangle(w - 8, top, 8, h - top); break;
                        case "rzB": s.Bounds = new Rectangle(0, h - 10, w, 10); break;
                        case "rzBL": s.Bounds = new Rectangle(0, h - 14, 14, 14); break;
                        case "rzBR": s.Bounds = new Rectangle(w - 14, h - 14, 14, 14); break;
                    }
                }
            }
            catch { }
        }

        // Theme maarinaalum strips ku keezh panel color oda match aaganum (invisible ah irukanum)
        private void SyncStripColors()
        {
            if (resizeStrips == null) return;
            try
            {
                Color side = pnlSide != null ? pnlSide.BackColor : BackColor;
                Color bottom = pnlBottom != null ? pnlBottom.BackColor : BackColor;
                foreach (var s in resizeStrips)
                {
                    if (s.Name == "rzL") s.BackColor = side;
                    else if (s.Name == "rzR") s.BackColor = BackColor;
                    else s.BackColor = bottom;                    // rzB, rzBL, rzBR
                }
            }
            catch { }
        }

        private void ApplyUiScale()
        {
            if (uiOrig == null || uiOrig.Count == 0 || uiScaling) return;
            uiScaling = true;
            try
            {
                float sx = (float)ClientSize.Width / uiBase.Width;
                float sy = (float)ClientSize.Height / uiBase.Height;
                foreach (var o in uiOrig)
                {
                    o.C.Bounds = new Rectangle(
                        (int)Math.Round(o.B.X * sx), (int)Math.Round(o.B.Y * sy),
                        (int)Math.Round(o.B.Width * sx), (int)Math.Round(o.B.Height * sy));
                }
                // font scale — debounce (drag la GDI churn kammi aagum, lag illa)
                float f = Math.Min(sx, sy);
                if (Math.Abs(f - uiFontApplied) > 0.06f)
                {
                    uiFontApplied = f;
                    foreach (var o in uiOrig)
                    {
                        float ns = o.FS * f;
                        if (ns < 5f) ns = 5f;
                        try { o.C.Font = new Font(o.C.Font.FontFamily, ns, o.C.Font.Style, o.C.Font.Unit); }
                        catch { }
                    }
                }
            }
            catch { }
            finally { uiScaling = false; }
        }

        // ★ Invisible strip — direct MouseDown → Windows resize loop
        private class ResizeStrip : Control
        {
            public int Dir;
            public ResizeStrip(int dir, Cursor cur) { Dir = dir; Cursor = cur; }

            protected override void OnMouseDown(MouseEventArgs e)
            {
                base.OnMouseDown(e);
                if (e.Button != MouseButtons.Left) return;
                var f = Parent as Form1;
                if (f == null || f.WindowState != FormWindowState.Normal) return;
                LogResize("STRIP dir=" + Dir);
                var p = Cursor.Position;
                ReleaseCapture();
                IntPtr lp = (IntPtr)((p.Y << 16) | (p.X & 0xFFFF));
                SendMessage(f.Handle, WM_SYSCOMMAND, (IntPtr)(SC_SIZE | Dir), lp);
            }
        }

        // ★ Mouse edge detection — app-wide filter, bare form surface mela work aagum
        private class ResizeFilter : IMessageFilter
        {
            private const int EDGE = 8;        // edge zone px
            private const int CORNER = 16;     // corner zone px
            private readonly Form1 f;

            public ResizeFilter(Form1 form) { f = form; }

            public bool PreFilterMessage(ref Message m)
            {
                try
                {
                    if (f == null || f.IsDisposed || !f.IsHandleCreated) return false;
                    if (f.WindowState != FormWindowState.Normal) return false;
                    if (m.Msg != WM_MOUSEMOVE && m.Msg != WM_LBUTTONDOWN) return false;

                    var p = Cursor.Position;
                    var r = f.DesktopBounds;   // borderless → window ≈ client
                    if (!r.Contains(p)) return false;

                    int dir = HitDir(r, p);
                    if (dir == 0) return false;

                    if (m.Msg == WM_MOUSEMOVE)
                    {
                        Cursor.Current = DirCursor(dir);
                        return false;          // move ah thinnaadhu — controls um normal ah move aagum
                    }
                    // WM_LBUTTONDOWN edge zone la → resize loop start
                    LogResize("FILTER dir=" + dir);
                    ReleaseCapture();
                    IntPtr lp = (IntPtr)((p.Y << 16) | (p.X & 0xFFFF));
                    SendMessage(f.Handle, WM_SYSCOMMAND, (IntPtr)(SC_SIZE | dir), lp);
                    return true;               // down ah vizhukkadhu — resize loop own pannum
                }
                catch { return false; }
            }

            private static int HitDir(Rectangle r, Point p)
            {
                int dx = p.X - r.Left, dy = p.Y - r.Top;
                if (dx <= CORNER && dy <= CORNER) return WMSZ_TOPLEFT;
                if (dx >= r.Width - CORNER && dy <= CORNER) return WMSZ_TOPRIGHT;
                if (dx <= CORNER && dy >= r.Height - CORNER) return WMSZ_BOTTOMLEFT;
                if (dx >= r.Width - CORNER && dy >= r.Height - CORNER) return WMSZ_BOTTOMRIGHT;
                if (dx <= EDGE) return WMSZ_LEFT;
                if (dx >= r.Width - EDGE) return WMSZ_RIGHT;
                if (dy <= EDGE) return WMSZ_TOP;
                if (dy >= r.Height - EDGE) return WMSZ_BOTTOM;
                return 0;
            }

            private static Cursor DirCursor(int dir)
            {
                switch (dir)
                {
                    case WMSZ_LEFT:
                    case WMSZ_RIGHT: return Cursors.SizeWE;
                    case WMSZ_TOP:
                    case WMSZ_BOTTOM: return Cursors.SizeNS;
                    case WMSZ_TOPLEFT:
                    case WMSZ_BOTTOMRIGHT: return Cursors.SizeNWSE;
                    default: return Cursors.SizeNESW;   // TOPRIGHT / BOTTOMLEFT
                }
            }
        }
    }
}
