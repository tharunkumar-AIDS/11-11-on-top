using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace zafkialontop
{
    // ★★★ CORE: FAST AoB scan engine — FF MAX AIM section indha helpers ah use pannum (tani file)
    //     ADDITIVE ONLY — Aimbot.cs / INTERNAL.cs THODAVE MATTEN (standing rule)
    //
    // Anchor prefilter: pattern oda first 4+ solid-byte run ah per-position check
    // → 255/256 positions instant skip. Test la verify pannirukom:
    //   OLD 266s vs NEW 13s (20.4x faster), rendu method um SAME addresses (100% correct)
    //
    // Smooth: scan threads BelowNormal priority + parallelism capped (4)
    //         → UI + game ku CPU munnadi kidaikum, lag illa
    // Guard:  scanRunId generation — stale progress messages final status ah
    //         overwrite pannaadhu
    public partial class Form1
    {
        // %TEMP%\11-11_scan_log.txt — ella PC layum work aagum (user support ku log send panna)
        private static readonly string SCAN_LOG = Path.Combine(Path.GetTempPath(), "11-11_scan_log.txt");
        private int scanRunId = 0;   // progress message generation guard — stale status overwrite thadukkom

        // ---------- regions scan — anchor prefilter loop (test la verified correct) ----------
        private List<long> FastScanRegions(IntPtr hProc, List<MBI> regions, byte[] pat, byte[] mask,
                                           int aPos, byte a0, byte a1, byte a2, byte a3, string label)
        {
            var results = new ConcurrentBag<long>();
            long bytesDone = 0, nextProgressMb = 512;
            int myRun = scanRunId;   // generation guard

            int par = Math.Min(4, Math.Max(2, Environment.ProcessorCount - 2)); // UI + game ku cores vittukudukom

            Parallel.ForEach(regions, new ParallelOptions { MaxDegreeOfParallelism = par }, (r) =>
            {
                Thread.CurrentThread.Priority = ThreadPriority.BelowNormal;   // UI + game smooth ah irukum
                try
                {
                long regionSize = r.RegionSize.ToInt64();
                if (regionSize <= 0) return;

                byte[] buffer = new byte[BUFFER_SCAN];
                long regionBase = r.BaseAddress.ToInt64();
                long bytesRead = 0;

                while (bytesRead < regionSize)
                {
                    int toRead = (int)Math.Min(BUFFER_SCAN, regionSize - bytesRead);
                    IntPtr readAddr = new IntPtr(regionBase + bytesRead);
                    IntPtr got;
                    if (!ReadProcessMemory(hProc, readAddr, buffer, (IntPtr)toRead, out got) || got.ToInt64() == 0)
                        break;

                    int usable = (int)got.ToInt64();
                    if (usable < pat.Length) { Interlocked.Add(ref bytesDone, usable); break; }
                    int limit = usable - pat.Length;

                    unsafe
                    {
                        fixed (byte* pBuffer = buffer, pPattern = pat, pMask = mask)
                        {
                            for (int i = 0; i <= limit; i++)
                            {
                                // 4-byte anchor check — 255/256 positions inga instant skip
                                if (pBuffer[i + aPos] != a0 || pBuffer[i + aPos + 1] != a1 ||
                                    pBuffer[i + aPos + 2] != a2 || pBuffer[i + aPos + 3] != a3) continue;

                                bool match = true;
                                for (int j = 0; j < pat.Length; j++)
                                {
                                    if (pMask[j] == 0xFF && pBuffer[i + j] != pPattern[j]) { match = false; break; }
                                }
                                if (match) results.Add(regionBase + bytesRead + i);
                            }
                        }
                    }

                    bytesRead += toRead;
                    long doneMb = Interlocked.Add(ref bytesDone, toRead) / (1024 * 1024);
                    if (doneMb >= nextProgressMb)
                    {
                        Interlocked.Add(ref nextProgressMb, 512);
                        int capturedRun = myRun; string capturedLabel = label;
                        try
                        {
                            BeginInvoke((MethodInvoker)delegate
                            {
                                if (scanRunId != capturedRun) return;   // stale — final status already set
                                UpdateStatus(capturedLabel + ": " + doneMb + " MB...", Color.Yellow);
                            });
                        }
                        catch { }
                    }
                }
                }
                finally { Thread.CurrentThread.Priority = ThreadPriority.Normal; }
            });

            var list = new List<long>(results);
            list.Sort();
            return list;
        }

        // ---------- pattern oda first 4+ solid-byte run — non-zero start prefer (00 runs common) ----------
        private static void FindAnchor(byte[] pat, byte[] mask, out int pos, out byte b0, out byte b1, out byte b2, out byte b3)
        {
            pos = -1; int fallback = -1;
            for (int j = 0; j + 3 < pat.Length; j++)
            {
                if (mask[j] == 0xFF && mask[j + 1] == 0xFF && mask[j + 2] == 0xFF && mask[j + 3] == 0xFF)
                {
                    if (fallback < 0) fallback = j;
                    if (pat[j] != 0) { pos = j; break; }
                }
            }
            if (pos < 0) pos = fallback;
            if (pos < 0) pos = 0; // extreme case — pattern la 4-solid run e illa (log la theriyum)
            b0 = pat[pos]; b1 = pat[pos + 1]; b2 = pat[pos + 2]; b3 = pat[pos + 3];
        }

        // ---------- pattern parse ("??" = wildcard — AYUSH ParsePattern semantics same) ----------
        private static bool TryParsePattern(string s, out byte[] bytes, out byte[] mask)
        {
            bytes = null; mask = null;
            if (string.IsNullOrWhiteSpace(s)) return false;
            var parts = s.Split(new[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
            if (parts.Length < 4) return false;
            bytes = new byte[parts.Length]; mask = new byte[parts.Length];
            for (int i = 0; i < parts.Length; i++)
            {
                if (parts[i] == "??" || parts[i] == "?") { mask[i] = 0x00; bytes[i] = 0x00; }
                else { mask[i] = 0xFF; bytes[i] = Convert.ToByte(parts[i], 16); }
            }
            return true;
        }

        // ---------- AYUSH GetMemoryRegions oda exact replica — allRegions=true na writable filter skip ----------
        private static List<MBI> EnumWritableRegions(IntPtr hProc, bool allRegions)
        {
            var list = new List<MBI>();
            long addr = 0x10000;
            while (addr < 0x00007FFFFFFEFFFF)
            {
                MBI m;
                if (VirtualQueryEx(hProc, (UIntPtr)addr, out m, (UIntPtr)Marshal.SizeOf(typeof(MBI))) == UIntPtr.Zero)
                    break;
                long size = m.RegionSize.ToInt64();
                if (size <= 0) break;

                bool isCommit = m.State == ST_MEM_COMMIT;
                bool accessible = (m.Protect & ST_PAGE_NOACCESS) == 0 && (m.Protect & ST_PAGE_GUARD) == 0;
                if (isCommit && accessible)
                {
                    bool writable = (m.Protect & 0x04) > 0 || (m.Protect & 0x40) > 0;
                    if (allRegions || writable) list.Add(m);
                }
                addr += size;
            }
            return list;
        }

        private void FlushScanLog(StringBuilder log)
        {
            try { File.AppendAllText(SCAN_LOG, log.ToString() + Environment.NewLine + Environment.NewLine); } catch { }
        }

        // one-line log — scan attempts ella step um record (user PC troubleshooting)
        private static void LogScan(string line)
        {
            try
            {
                // size cap 2 MB — purge (user PC la log size um grow aagum)
                try
                {
                    var fi = new FileInfo(SCAN_LOG);
                    if (fi.Exists && fi.Length > 2 * 1024 * 1024) File.WriteAllText(SCAN_LOG, "");
                }
                catch { }
                File.AppendAllText(SCAN_LOG, DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + " | " + line + Environment.NewLine);
            }
            catch { }
        }

        // ---------- P/Invoke (self-contained — INTERNAL.cs thoda matten) ----------
        private const uint PROCESS_ACCESS = 0x0410; // VM_READ | QUERY_INFORMATION
        private const uint ST_MEM_COMMIT = 0x1000;      // Form1 la MEM_COMMIT already irukku — ST_ prefix
        private const uint ST_PAGE_NOACCESS = 0x01;
        private const uint ST_PAGE_GUARD = 0x100;
        private const int BUFFER_SCAN = 5 * 1024 * 1024; // 5 MB — AYUSH BUFFER_SIZE same

        [StructLayout(LayoutKind.Sequential)]
        private struct MBI
        {
            public IntPtr BaseAddress;
            public IntPtr AllocationBase;
            public uint AllocationProtect;
            public IntPtr RegionSize;
            public uint State;
            public uint Protect;
            public uint Type;
        }

        [DllImport("kernel32.dll", SetLastError = true)]
        private static extern IntPtr OpenProcess(uint access, bool inherit, int pid);

        [DllImport("kernel32.dll", SetLastError = true)]
        private static extern bool ReadProcessMemory(IntPtr h, IntPtr addr, byte[] buffer, IntPtr size, out IntPtr read);

        [DllImport("kernel32.dll", SetLastError = true)]
        private static extern UIntPtr VirtualQueryEx(IntPtr h, UIntPtr addr, out MBI mbi, UIntPtr len);

        [DllImport("kernel32.dll")]
        private static extern bool CloseHandle(IntPtr h);
    }
}
