﻿using AYUSH;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Gma.System.MouseKeyHook;
using DiscordRPC;
using FAST_MEMORY;
using Nazmulscope;

namespace zafkialontop
{
    // SETTINGS section (theme + streamer + hide key + ping/fps) — taniya file (partial class, Form1 oda same class)
    public partial class Form1
    {
        private const uint WDA_NONE = 0;
        private const uint WDA_EXCLUDEFROMCAPTURE = 0x11;
        public static bool StreamerOn = false;

        private delegate bool EnumWindowsProc(IntPtr hWnd, IntPtr lParam);
        [DllImport("user32.dll")]
        private static extern bool EnumWindows(EnumWindowsProc lpEnumFunc, IntPtr lParam);
        [DllImport("user32.dll")]
        private static extern uint GetWindowThreadProcessId(IntPtr hWnd, out uint lpdwProcessId);

        private System.Windows.Forms.Timer affinityTimer;

        private void ApplyStreamerMode()
        {
            try
            {
                // FIX: main form mattum illa — namma process oda ELLA window kum (shadow
                // window, glow overlay, toast, popup ellam) affinity apply. Oru window
                // miss aana capture la outline ah leak aagum (mobile screenshot issue).
                ApplyAffinityToAllProcessWindows(StreamerOn ? WDA_EXCLUDEFROMCAPTURE : WDA_NONE);
                if (StreamerOn)
                {
                    // pudhu windows (toast/popup) appram create aana adhavum cover — 2s sweep
                    if (affinityTimer == null)
                    {
                        affinityTimer = new System.Windows.Forms.Timer { Interval = 2000 };
                        affinityTimer.Tick += (s, e) => { if (StreamerOn) ApplyAffinityToAllProcessWindows(WDA_EXCLUDEFROMCAPTURE); };
                    }
                    affinityTimer.Start();
                }
                else if (affinityTimer != null) affinityTimer.Stop();
                // FIX: shadow permanent ah off — capture la edge outline varathu
                if (guna2BorderlessForm1 != null)
                    guna2BorderlessForm1.ShadowColor = System.Drawing.Color.Transparent;
                if (btnStreamer != null)
                    btnStreamer.Text = StreamerOn ? "HIDDEN" : "REC:ON";
                UpdateEdgeGlow();
            }
            catch { }
        }

        // Ella top-level window um (namma process) ku affinity apply — leak proof
        private void ApplyAffinityToAllProcessWindows(uint affinity)
        {
            try
            {
                uint pid = (uint)System.Diagnostics.Process.GetCurrentProcess().Id;
                EnumWindows((hWnd, lp) =>
                {
                    try
                    {
                        uint wpid;
                        GetWindowThreadProcessId(hWnd, out wpid);
                        if (wpid == pid)
                        {
                            try { SetWindowDisplayAffinity(hWnd, affinity); } catch { }
                        }
                    }
                    catch { }
                    return true;
                }, IntPtr.Zero);
            }
            catch { }
        }

        private void btnStreamer_Click(object sender, EventArgs e)
        {
            StreamerOn = !StreamerOn;
            ApplyStreamerMode();
            Sta.Text = StreamerOn ? "Streamer Mode ON (capture hidden)" : "Streamer Mode OFF";
            if (StreamerOn) Toast.Success("STREAMER", "Capture hidden!"); else Toast.Info("STREAMER", "Capture visible");
        }

        // ★★★ FEATURE: EDGE GLOW — streamer mode ON pana form edge la accent glow pulse ★★★
        // FIX: overlay tani top-level window la irundha capture la outline leak aachu
        //      (WDA_EXCLUDEFROMCAPTURE UpdateLayeredWindow window la work aagadhu —
        //       Windows limitation). Ippo idhu CHILD control:
        //      - parent (main form) exclusion child ku automatic → leak IMPOSSIBLE
        //      - controls mela um glow varum (top-most child), layout thodave illa
        private class GlowOverlayControl : System.Windows.Forms.Control
        {
            protected override System.Windows.Forms.CreateParams CreateParams
            {
                get
                {
                    var cp = base.CreateParams;
                    cp.ExStyle |= 0x00080000;  // WS_EX_LAYERED (ULW per-pixel alpha)
                    cp.ExStyle |= 0x00000020;  // WS_EX_TRANSPARENT (click-through)
                    return cp;
                }
            }
        }

        private System.Windows.Forms.Control glowOverlay;
        private System.Windows.Forms.Timer glowTimer;
        private System.Drawing.Bitmap glowBmp;
        private double glowPhase;
        private System.Drawing.Color themeAccentColor = System.Drawing.Color.Red;

        private void InitEdgeGlow()
        {
            glowOverlay = new GlowOverlayControl();
            glowOverlay.Dock = DockStyle.Fill;          // client area full — resize automatic
            this.Controls.Add(glowOverlay);
            glowOverlay.BringToFront();                 // ella controls melayum glow
            glowTimer = new System.Windows.Forms.Timer { Interval = 60 };
            glowTimer.Tick += (s, e) => GlowTick();
        }

        private void UpdateEdgeGlow()
        {
            try
            {
                if (StreamerOn)
                {
                    if (glowOverlay == null) InitEdgeGlow();
                    glowTimer.Start();
                }
                else
                {
                    if (glowTimer != null) glowTimer.Stop();
                    if (glowOverlay != null) RenderGlowFrame(true);   // empty frame — glow clear
                }
            }
            catch { }
        }

        private void GlowTick()
        {
            try
            {
                if (glowOverlay == null) return;
                if (!StreamerOn || !this.Visible || this.WindowState == FormWindowState.Minimized)
                    return;   // child parent oda automatic hide aagum
                glowPhase += 0.12;
                RenderGlowFrame();
            }
            catch { }
        }

        private void RenderGlowFrame(bool empty = false)
        {
            try
            {
                int w = this.ClientSize.Width, h = this.ClientSize.Height;
                if (w <= 0 || h <= 0) return;
                if (glowBmp == null || glowBmp.Width != w || glowBmp.Height != h)
                {
                    if (glowBmp != null) glowBmp.Dispose();
                    glowBmp = new System.Drawing.Bitmap(w, h, System.Drawing.Imaging.PixelFormat.Format32bppArgb);
                }
                using (var g = System.Drawing.Graphics.FromImage(glowBmp))
                {
                    g.Clear(System.Drawing.Color.Transparent);
                    if (!empty)
                    {
                        double pulse = Math.Sin(glowPhase) * 0.5 + 0.5;   // 0..1 soft pulse
                        for (int i = 0; i < 12; i++)
                        {
                            double fade = 1.0 - (i / 12.0);               // edge la bright → ulla fade
                            int a = (int)(220 * fade * (0.5 + 0.5 * pulse));
                            if (a <= 0) continue;
                            if (a > 255) a = 255;
                            using (var pen = new System.Drawing.Pen(System.Drawing.Color.FromArgb(a, themeAccentColor), 2f))
                                g.DrawRectangle(pen, i, i, w - 1 - i * 2, h - 1 - i * 2);
                        }
                    }
                }
                UpdateLayeredGlow(glowBmp);
            }
            catch { }
        }

        // ---- layered window blit (per-pixel alpha, soft glow) ----
        [StructLayout(LayoutKind.Sequential)]
        private struct GlowPOINT { public int X, Y; }
        [StructLayout(LayoutKind.Sequential)]
        private struct GlowSIZE { public int CX, CY; }
        [StructLayout(LayoutKind.Sequential)]
        private struct GlowBLENDFUNCTION { public byte BlendOp, BlendFlags, SourceConstantAlpha, AlphaFormat; }

        [DllImport("user32.dll")]
        private static extern IntPtr GetDC(IntPtr hWnd);
        [DllImport("user32.dll")]
        private static extern int ReleaseDC(IntPtr hWnd, IntPtr hDC);
        [DllImport("user32.dll", SetLastError = true)]
        private static extern bool UpdateLayeredWindow(IntPtr hWnd, IntPtr hdcDst, ref GlowPOINT pptDst, ref GlowSIZE pSize, IntPtr hDCSrc, ref GlowPOINT pptSrc, int crKey, ref GlowBLENDFUNCTION pblend, int dwFlags);
        [DllImport("gdi32.dll")]
        private static extern IntPtr CreateCompatibleDC(IntPtr hdc);
        [DllImport("gdi32.dll")]
        private static extern bool DeleteDC(IntPtr hdc);
        [DllImport("gdi32.dll")]
        private static extern IntPtr SelectObject(IntPtr hdc, IntPtr hObject);

        private void UpdateLayeredGlow(System.Drawing.Bitmap bmp)
        {
            IntPtr memDc = IntPtr.Zero, oldObj = IntPtr.Zero, screenDc = IntPtr.Zero;
            try
            {
                var fd = bmp.LockBits(new System.Drawing.Rectangle(0, 0, bmp.Width, bmp.Height),
                    System.Drawing.Imaging.ImageLockMode.ReadOnly, System.Drawing.Imaging.PixelFormat.Format32bppArgb);
                try
                {
                    screenDc = GetDC(IntPtr.Zero);
                    memDc = CreateCompatibleDC(screenDc);
                    oldObj = SelectObject(memDc, fd.Scan0);
                    var dst = new GlowPOINT { X = 0, Y = 0 };   // child → parent client coords
                    var size = new GlowSIZE { CX = bmp.Width, CY = bmp.Height };
                    var src = new GlowPOINT { X = 0, Y = 0 };
                    var blend = new GlowBLENDFUNCTION { BlendOp = 0, SourceConstantAlpha = 255, AlphaFormat = 1 };
                    UpdateLayeredWindow(glowOverlay.Handle, screenDc, ref dst, ref size, memDc, ref src, 0, ref blend, 2);
                }
                finally
                {
                    bmp.UnlockBits(fd);
                    if (oldObj != IntPtr.Zero) SelectObject(memDc, oldObj);
                    if (memDc != IntPtr.Zero) DeleteDC(memDc);
                    if (screenDc != IntPtr.Zero) ReleaseDC(IntPtr.Zero, screenDc);
                }
            }
            catch { }
        }

        private void btnHideKey_Click(object sender, EventArgs e)
        {
            var btn = sender as Guna.UI2.WinForms.Guna2Button;
            btn.Text = "...";
            Sta.Text = "Press key for Hide... (ESC cancel)";
            keyHook?.Dispose();
            keyHook = Hook.GlobalEvents();
            keyHook.KeyDown += (s, ev) => {
                if (ev.KeyCode == Keys.Escape) { btn.Text = (hideKey == Keys.None) ? "NONE" : hideKey.ToString(); keyHook.Dispose(); return; }
                hideKey = ev.KeyCode;
                btn.Text = hideKey.ToString();
                Sta.Text = "Hide Key: " + hideKey;
                keyHook.Dispose();
            };
        }

        // ★★★ FEATURE: SETTINGS — Theme (RED/PINK/custom) + registry save
        // ============ THEME (RED / PINK) ============
        private string appTheme = "RED";

        private string ThemeRegPath { get { return @"Software\zafkialontop"; } }

        private void LoadTheme()
        {
            try
            {
                var rk = Microsoft.Win32.Registry.CurrentUser.OpenSubKey(ThemeRegPath);
                if (rk != null)
                {
                    string t = rk.GetValue("Theme") as string;
                    if (!string.IsNullOrEmpty(t))
                    {
                        t = t.ToUpperInvariant();
                        if (t == "RED" || t == "PINK" || t == "TERM" || t == "CUSTOM") appTheme = t;
                    }
                    rk.Close();
                }
            }
            catch { }
        }

        private void SaveTheme()
        {
            try
            {
                var rk = Microsoft.Win32.Registry.CurrentUser.CreateSubKey(ThemeRegPath);
                rk.SetValue("Theme", appTheme);
                rk.Close();
            }
            catch { }
        }

        private static readonly string[] TitleLabels = new string[] {
            "lblAimTitle", "lblChamsTitle", "lblExtTitle", "lblSetTitle", "lblBypassTitle",
            "lblRowHide", "lblRowAimMatch", "lblRowAimToggle", "lblRowHyper", "lblSection", "lblVerSide",
            "lblRowScopeKey"
        };

        // ★ UI STRUCTURE (redesign): cards/bars/dividers colors theme oda follow — Designer-la color illa
        private static readonly string[] CardPanels = new string[] {
            "cardAimMatch", "cardAimRun", "cardFfMaxRow", "cardFfMaxRun", "cardChamsFix", "cardChamsTrans", "cardChamsRun",
            "cardScope", "cardGlitch", "cardSpeed", "cardSwitch", "cardScopeKey",
            "cardSetTheme", "cardSetAccent", "cardSetBg", "cardSetHide", "cardSetStream", "cardSetLog",
            "cardBpOb1", "cardBpOb2", "cardBpEmuAuto", "cardBpEmuKill", "cardBpHyper", "cardBpHyperFix",
            "cardTestSaim", "cardTest5566", "cardTestSwitch"
        };
        private static readonly string[] AccentPanels = new string[] {
            "barAim", "barFfMax", "barChams", "barExt", "barSet", "barBypass", "barTest"
        };
        private static readonly string[] LinePanels = new string[] {
            "divAim", "divFfMax", "divChams", "divExt", "divSet", "divBypass", "divTest"
        };

        private void ApplyTheme()
        {
            try
            {
                bool pink = (appTheme == "PINK");
                bool custom = (appTheme == "CUSTOM");
                bool term = (appTheme == "TERM");   // ★ Terminal Hacker — Consolas, green/amber on black
                System.Drawing.Color bg = custom ? LoadColor("ThemeBG", System.Drawing.Color.Black)
                    : (pink ? System.Drawing.Color.FromArgb(255, 192, 255) : System.Drawing.Color.Black);
                System.Drawing.Color panelBg = custom ? System.Drawing.Color.FromArgb(
                        Math.Max(bg.R - 20, 0), Math.Max(bg.G - 20, 0), Math.Max(bg.B - 20, 0))
                    : (pink ? System.Drawing.Color.White
                        : (term ? System.Drawing.Color.FromArgb(13, 17, 13) : System.Drawing.Color.FromArgb(20, 20, 20)));
                double lum = (0.299 * bg.R + 0.587 * bg.G + 0.114 * bg.B) / 255.0;
                System.Drawing.Color fore = custom ? (lum > 0.6 ? System.Drawing.Color.Black : System.Drawing.Color.White)
                    : (pink ? System.Drawing.Color.Black
                        : (term ? System.Drawing.Color.FromArgb(0, 255, 65) : System.Drawing.Color.White));
                System.Drawing.Color accent = custom ? LoadColor("ThemeAccent", System.Drawing.Color.Red)
                    : (term ? System.Drawing.Color.FromArgb(0, 255, 65) : System.Drawing.Color.Red);
                themeAccentColor = accent;   // edge glow um theme padi maarum
                System.Drawing.Color title = term ? System.Drawing.Color.FromArgb(255, 176, 0)
                    : (pink ? System.Drawing.Color.Blue : accent);
                System.Drawing.Color grad1 = term ? System.Drawing.Color.FromArgb(0, 70, 0)
                    : (pink ? System.Drawing.Color.DodgerBlue : accent);
                System.Drawing.Color grad2 = term ? System.Drawing.Color.FromArgb(0, 190, 60)
                    : (pink ? System.Drawing.Color.HotPink : System.Drawing.Color.Maroon);
                navOnColor = term ? System.Drawing.Color.FromArgb(0, 90, 0)
                    : (pink ? System.Drawing.Color.HotPink : accent);
                navOffColor = term ? System.Drawing.Color.FromArgb(14, 20, 14)
                    : (pink ? System.Drawing.Color.LightGray : System.Drawing.Color.FromArgb(30, 30, 30));
                navTextColor = fore;

                this.BackColor = bg;
                pnlSide.BackColor = panelBg;
                pnlBottom.BackColor = panelBg;

                // ★ UI CARDS — card/line = panelBg + 10 (subtle lift), accent bar = title color
                var cardSet = new System.Collections.Generic.HashSet<string>(CardPanels);
                var accentSet = new System.Collections.Generic.HashSet<string>(AccentPanels);
                var lineSet = new System.Collections.Generic.HashSet<string>(LinePanels);
                System.Drawing.Color cardBg = System.Drawing.Color.FromArgb(
                    Math.Min(panelBg.R + 10, 255), Math.Min(panelBg.G + 10, 255), Math.Min(panelBg.B + 10, 255));
                SetPanelRolesRecursive(this, cardSet, accentSet, lineSet, cardBg, title);

                var titles = new System.Collections.Generic.HashSet<string>(TitleLabels);
                SetForeRecursive(this, fore, title, titles);

                // TERM: Consolas + terminal buttons; RED/PINK: original Designer font/color restore
                // (munnadi call — grads loop kku munnadi → first call la pristine capture)
                ApplyTermStyle(this, term);

                Guna.UI2.WinForms.Guna2GradientButton[] grads = { btnAimRun, btnChamsRun, btnEmuKill, btnHyperFix };
                foreach (var b in grads)
                {
                    if (b == null) continue;
                    b.FillColor = grad1; b.FillColor2 = grad2;
                }

                Sta.ForeColor = fore;
                label2.ForeColor = fore;
                if (btnTheme != null) btnTheme.Text = appTheme;
                ShowSection(currentSection);
                SyncStripColors();   // resize strips ku keezh panel color match (invisible ah irukanum)
                Invalidate(true);
            }
            catch { }
        }

        private static void SetForeRecursive(System.Windows.Forms.Control parent, System.Drawing.Color fore, System.Drawing.Color title, System.Collections.Generic.HashSet<string> titles)
        {
            foreach (System.Windows.Forms.Control c in parent.Controls)
            {
                if (c is System.Windows.Forms.Label)
                {
                    c.ForeColor = titles.Contains(c.Name) ? title : fore;
                    // Transparent text: parent BG mela clean ah theriyum (black box varadhu)
                    try { c.BackColor = System.Drawing.Color.Transparent; } catch { }
                }
                if (c.HasChildren) SetForeRecursive(c, fore, title, titles);
            }
        }

        // ★ UI CARDS — card/bar/divider panels ku theme color apply (recursive)
        private static void SetPanelRolesRecursive(System.Windows.Forms.Control parent,
            System.Collections.Generic.HashSet<string> cards, System.Collections.Generic.HashSet<string> accents,
            System.Collections.Generic.HashSet<string> lines, System.Drawing.Color card, System.Drawing.Color accent)
        {
            foreach (System.Windows.Forms.Control c in parent.Controls)
            {
                if (cards.Contains(c.Name)) c.BackColor = card;
                else if (accents.Contains(c.Name)) c.BackColor = accent;
                else if (lines.Contains(c.Name)) c.BackColor = card;
                if (c.HasChildren) SetPanelRolesRecursive(c, cards, accents, lines, card, accent);
            }
        }

        // ★★★ FEATURE: TERMINAL HACKER THEME — Consolas font + green/amber buttons
        // ============ TERM STYLE (original capture + apply/restore) ============
        // First call la Designer pristine colors/fonts dictionary la capture,
        // TERM mode → Consolas + green restyle, RED/PINK ku thirumbi original restore.
        private readonly System.Collections.Generic.Dictionary<System.Windows.Forms.Control, System.Drawing.Font> origFonts
            = new System.Collections.Generic.Dictionary<System.Windows.Forms.Control, System.Drawing.Font>();
        private readonly System.Collections.Generic.Dictionary<System.Windows.Forms.Control, System.Drawing.Color> origFills
            = new System.Collections.Generic.Dictionary<System.Windows.Forms.Control, System.Drawing.Color>();
        private readonly System.Collections.Generic.Dictionary<System.Windows.Forms.Control, System.Drawing.Color> origFills2
            = new System.Collections.Generic.Dictionary<System.Windows.Forms.Control, System.Drawing.Color>();
        private readonly System.Collections.Generic.Dictionary<System.Windows.Forms.Control, System.Drawing.Color> origTexts
            = new System.Collections.Generic.Dictionary<System.Windows.Forms.Control, System.Drawing.Color>();

        private void ApplyTermStyle(System.Windows.Forms.Control parent, bool term)
        {
            try
            {
                // ★ Form1.Font MATTAI maathadhu — AutoScaleMode.Font la form size drift aagum
                //   (children ku mattum Consolas; form font original ah irukkanum)
                foreach (System.Windows.Forms.Control c in parent.Controls)
                {
                    // ---- capture (first call mattum — Designer pristine state) ----
                    if (!origFonts.ContainsKey(c))
                    {
                        origFonts[c] = c.Font;
                        var gg0 = c as Guna.UI2.WinForms.Guna2GradientButton;
                        var tb0 = c as Guna.UI2.WinForms.Guna2TextBox;
                        var gb0 = c as Guna.UI2.WinForms.Guna2Button;
                        if (gg0 != null)
                        {
                            origFills[c] = gg0.FillColor; origFills2[c] = gg0.FillColor2; origTexts[c] = gg0.ForeColor;
                        }
                        else if (tb0 != null) { origFills[c] = tb0.FillColor; origTexts[c] = tb0.ForeColor; }
                        else if (gb0 != null) { origFills[c] = gb0.FillColor; origTexts[c] = gb0.ForeColor; }
                    }

                    // ---- font: Consolas (size/style preserve) ↔ original ----
                    try
                    {
                        System.Drawing.Font of = origFonts[c];
                        c.Font = term ? new System.Drawing.Font("Consolas", of.Size, of.Style) : of;
                    }
                    catch { }

                    // ---- button / textbox colors ----
                    var grad = c as Guna.UI2.WinForms.Guna2GradientButton;
                    var txt = c as Guna.UI2.WinForms.Guna2TextBox;
                    var btn = c as Guna.UI2.WinForms.Guna2Button;
                    if (grad != null && origFills.ContainsKey(c))
                    {
                        if (term)
                        {
                            grad.FillColor = System.Drawing.Color.FromArgb(0, 70, 0);
                            grad.FillColor2 = System.Drawing.Color.FromArgb(0, 190, 60);
                        }
                        else
                        {
                            grad.FillColor = origFills[c];
                            if (origFills2.ContainsKey(c)) grad.FillColor2 = origFills2[c];
                        }
                    }
                    else if (txt != null && origFills.ContainsKey(c))
                    {
                        if (term)
                        {
                            txt.FillColor = System.Drawing.Color.FromArgb(0, 20, 0);
                            txt.ForeColor = System.Drawing.Color.FromArgb(0, 255, 65);
                        }
                        else { txt.FillColor = origFills[c]; txt.ForeColor = origTexts[c]; }
                    }
                    else if (btn != null && origFills.ContainsKey(c))
                    {
                        if (term)
                        {
                            btn.FillColor = System.Drawing.Color.FromArgb(0, 45, 0);
                            btn.ForeColor = System.Drawing.Color.FromArgb(0, 255, 65);
                        }
                        else { btn.FillColor = origFills[c]; btn.ForeColor = origTexts[c]; }
                    }

                    if (c.HasChildren) ApplyTermStyle(c, term);
                }
            }
            catch { }
        }

        private void btnTheme_Click(object sender, EventArgs e)
        {
            appTheme = (appTheme == "RED") ? "PINK" : (appTheme == "PINK") ? "TERM" : "RED";
            SaveTheme();
            ApplyTheme();
            Sta.Text = "Theme: " + appTheme;
            Toast.Info("THEME", "Theme: " + appTheme);
        }

        private System.Drawing.Color LoadColor(string name, System.Drawing.Color fallback)
        {
            try
            {
                var rk = Microsoft.Win32.Registry.CurrentUser.OpenSubKey(ThemeRegPath);
                if (rk != null)
                {
                    object v = rk.GetValue(name);
                    rk.Close();
                    if (v is int) return System.Drawing.Color.FromArgb((int)v);
                }
            }
            catch { }
            return fallback;
        }

        private void SaveColor(string name, System.Drawing.Color c)
        {
            try
            {
                var rk = Microsoft.Win32.Registry.CurrentUser.CreateSubKey(ThemeRegPath);
                rk.SetValue(name, c.ToArgb());
                rk.Close();
            }
            catch { }
        }

        private void btnBgColor_Click(object sender, EventArgs e)
        {
            using (var dlg = new System.Windows.Forms.ColorDialog())
            {
                dlg.Color = this.BackColor;
                if (dlg.ShowDialog() == System.Windows.Forms.DialogResult.OK)
                {
                    SaveColor("ThemeBG", dlg.Color);
                    appTheme = "CUSTOM";
                    SaveTheme();
                    ApplyTheme();
                    Sta.Text = "Theme: CUSTOM (BG)";
                }
            }
        }

        private void btnAccentColor_Click(object sender, EventArgs e)
        {
            using (var dlg = new System.Windows.Forms.ColorDialog())
            {
                if (dlg.ShowDialog() == System.Windows.Forms.DialogResult.OK)
                {
                    SaveColor("ThemeAccent", dlg.Color);
                    appTheme = "CUSTOM";
                    SaveTheme();
                    ApplyTheme();
                    Sta.Text = "Theme: CUSTOM (Accent)";
                }
            }
        }

        public static string LoadSavedTheme()
        {
            try
            {
                var rk = Microsoft.Win32.Registry.CurrentUser.OpenSubKey(@"Software\zafkialontop");
                if (rk != null)
                {
                    string t = rk.GetValue("Theme") as string;
                    rk.Close();
                    if (!string.IsNullOrEmpty(t)) return t.ToUpperInvariant();
                }
            }
            catch { }
            return "RED";
        }

        // ★★★ FEATURE: SETTINGS — Ping/FPS bottom bar
        // ============ PING + FPS ============
        private System.Windows.Forms.Timer statusTimer;
        private int frames;

        private void StartStatusTimer()
        {
            try
            {
                statusTimer = new System.Windows.Forms.Timer { Interval = 2000 };
                statusTimer.Tick += async (s, ev) =>
                {
                    try
                    {
                        if (lblFps != null) lblFps.Text = "FPS: " + (frames / 2);
                        frames = 0;
                    }
                    catch { }
                    try
                    {
                        var ping = new System.Net.NetworkInformation.Ping();
                        var rep = await ping.SendPingAsync("8.8.8.8", 1500);
                        if (lblPing != null)
                        {
                            if (rep.Status == System.Net.NetworkInformation.IPStatus.Success)
                            {
                                lblPing.Text = "PING: " + rep.RoundtripTime + "ms";
                                lblPing.ForeColor = rep.RoundtripTime < 120 ? System.Drawing.Color.Lime : System.Drawing.Color.Yellow;
                            }
                            else if (lblPing != null) lblPing.Text = "PING: --";
                        }
                        try { ping.Dispose(); } catch { }
                    }
                    catch { if (lblPing != null) lblPing.Text = "PING: --"; }
                };
                statusTimer.Start();
            }
            catch { }
        }

    }
}
