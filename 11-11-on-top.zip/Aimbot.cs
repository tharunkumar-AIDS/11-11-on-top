﻿using AYUSH;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Gma.System.MouseKeyHook;
using DiscordRPC;
using FAST_MEMORY;
using Nazmulscope;

namespace zafkialontop
{
    // FF GLOBAL AIM section (old FF global pattern + 0xB8/0xB4 — Oct 27 exe la recover pannen) — taniya file (partial class, Form1 oda same class)
    public partial class Form1
    {
        // ★★★ FEATURE: FF GLOBAL AIM — AoB pattern + offsets (INJECT AIMBOT button + hotkey use pannum)

        string AimbotScan = "FF 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 ?? ?? ?? ?? 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 ?? ?? ?? ?? 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 ?? ?? ?? ?? ?? ?? ?? ?? ?? ?? ?? ?? ?? ?? ?? ?? ?? ?? ?? ?? ?? ?? ?? ?? ?? ?? ?? ?? ?? ?? ?? ?? ?? ?? ?? ?? 00 00 00 00 00 00 00 00 00 00 00 00 00 00 A5 43";
        string headoffset = "0xB8";
        string chestoffset = "0xB4";

        // Already applied addresses
        private HashSet<long> appliedAddresses = new HashSet<long>();
        private string lastFailReason = "";

        // ============ AIMBOT HOTKEY (PER MATCH only) ============
        private Keys aimKeyMatch = Keys.F9;
        private bool wasAimMatchPressed = false;

        private IKeyboardMouseEvents aimKeyHook;

        private void CaptureAimKey(Guna.UI2.WinForms.Guna2Button btn, Action<Keys> set)
        {
            btn.Text = "...";
            Sta.Text = "Press key... (ESC cancel)";
            try { if (aimKeyHook != null) aimKeyHook.Dispose(); } catch { }
            aimKeyHook = Hook.GlobalEvents();
            aimKeyHook.KeyDown += (s, ev) => {
                try
                {
                    if (ev.KeyCode == Keys.Escape) { aimKeyHook.Dispose(); return; }
                    set(ev.KeyCode);
                    btn.Text = ev.KeyCode.ToString();
                    Sta.Text = "Aim Key: " + ev.KeyCode;
                }
                catch { }
                try { aimKeyHook.Dispose(); } catch { }
            };
        }

        private void btnAimKeyMatch_Click(object sender, EventArgs e)
        {
            CaptureAimKey(sender as Guna.UI2.WinForms.Guna2Button, (k) => aimKeyMatch = k);
        }

        private bool aimScanning = false;

        private async void RunAimbotHotkey()
        {
            if (aimScanning) return;
            aimScanning = true;
            try
            {
                Sta.Text = "⚡ Aimbot scanning...";
                Sta.ForeColor = System.Drawing.Color.Yellow;
                Console.Beep(600, 100);
                var (success, timeMs) = await RunAimbotScan();
                Sta.Text = success ? $"✅ Aimbot ON ({timeMs} ms)" : "❌ Aimbot miss";
                Sta.ForeColor = success ? System.Drawing.Color.Lime : System.Drawing.Color.Red;
                Console.Beep(success ? 500 : 240, success ? 150 : 300);
                if (success) Toast.Success("AIMBOT", "Aimbot ON!"); else Toast.Error("AIMBOT", "Aimbot miss!");
            }
            catch { }
            aimScanning = false;
        }

        // ★★★ FEATURE: FF GLOBAL AIM — scan+swap runner (button + hotkey rendum inga koopdum)
        private async Task<(bool success, long timeMs)> RunAimbotScan()
        {
            // 🔥 STOPWATCH START
            Stopwatch sw = Stopwatch.StartNew();

            try
            {
                long readOffset = Convert.ToInt64(headoffset, 16);
                long writeOffset = Convert.ToInt64(chestoffset, 16);

                Process proc = FindEmulator();
                if (proc == null)
                {
                    lastFailReason = "Emulator Not Found";
                    sw.Stop();
                    return (false, sw.ElapsedMilliseconds);
                }

                AYUSH.OpenProcess(proc.Id);

                var results = (await AYUSH.AoBScan(AimbotScan, writable: true, executable: false)).ToList();
                if (results.Count == 0)
                {
                    // Deep pass: writable-only la illa na ella readable regions layum thedu
                    results = (await AYUSH.AoBScan(AimbotScan, writable: true, executable: false, file: "", allRegions: true)).ToList();
                }
                if (results.Count == 0)
                {
                    lastFailReason = "Pattern Not Found (" + proc.ProcessName + ")";
                    sw.Stop();
                    return (false, sw.ElapsedMilliseconds);
                }

                foreach (long baseAddr in results)
                {
                    long addrHead = baseAddr + writeOffset;
                    long addrChest = baseAddr + readOffset;

                    if (appliedAddresses.Contains(addrHead))
                        continue;

                    int headVal = AYUSH.ReadInt(addrHead);
                    int chestVal = AYUSH.ReadInt(addrChest);

                    AYUSH.WriteMemory(addrChest.ToString("X"), "int", headVal.ToString());
                    AYUSH.WriteMemory(addrHead.ToString("X"), "int", chestVal.ToString());

                    appliedAddresses.Add(addrHead);
                }

                sw.Stop();
                return (true, sw.ElapsedMilliseconds);
            }
            catch
            {
                sw.Stop();
                return (false, sw.ElapsedMilliseconds);
            }
        }

        // ★★★ FEATURE: FF GLOBAL AIM — INJECT AIMBOT button handler
        private async void guna2GradientButton1_Click(object sender, EventArgs e)
        {
            Sta.Text = "Waiting...";
            Sta.ForeColor = System.Drawing.Color.White;

            var (success, timeMs) = await RunAimbotScan();

            if (success)
            {
                // 🔥 SPEED FORMAT
                string speedText;
                if (timeMs < 1000)
                    speedText = $"{timeMs} ms";
                else
                    speedText = $"{(timeMs / 1000.0):F2} sec";

                Sta.Text = $"✅ Injected in {speedText}";
                Sta.ForeColor = System.Drawing.Color.Lime;
                Toast.Success("AIMBOT", "Injected in " + speedText);
            }
            else
            {
                Sta.Text = $"❌ Failed ({timeMs} ms)";
                Sta.ForeColor = System.Drawing.Color.Red;
                Toast.Error("AIMBOT FAILED", lastFailReason);

                // 🔥 POPUP MESSAGE BOX
                MessageBox.Show(
                    "INJECTION FAILED\n\n" +
                    "Reason: " + lastFailReason + "\n" +
                    "Time: " + timeMs + " ms\n\n" +
                    "━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n" +
                    "HOW TO FIX (check in order)\n" +
                    "━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n" +
                    "1. Is the emulator running?\n" +
                    "     Open HD-Player / MsiPlayer / BlueStacks and stay inside a match.\n\n" +
                    "2. Run as Administrator\n" +
                    "     Right-click the panel → Run as administrator.\n\n" +
                    "3. Turn Hyper-V OFF (required on Win11)\n" +
                    "     Go to BYPASS section → CHECK → FIX + REBOOT.\n\n" +
                    "4. Use a Nougat 32-bit instance\n" +
                    "     Memory cannot be read on Hyper-V / 64-bit instances.\n\n" +
                    "5. Game updated (OB mismatch)\n" +
                    "     Pattern is outdated — wait for an update.\n\n" +
                    "━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n" +
                    "Still stuck? DM us on Discord with a screenshot!",
                    "11:11 — Injection Failed",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }
        }

    }
}
