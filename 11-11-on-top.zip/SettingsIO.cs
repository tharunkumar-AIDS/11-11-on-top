using System;
using System.Diagnostics;
using System.IO;
using System.Windows.Forms;

namespace zafkialontop
{
    // ★★★ FEATURE: SETTINGS SAVE/LOAD + LOG VIEWER — tani file
    //     ADDITIVE ONLY — Aimbot.cs / INTERNAL.cs thoda matten (standing rule)
    //
    //     Save pattern: HKCU\Software\zafkialontop (Theme save oda same registry)
    //       - HideKey       (HIDE MENU hotkey — Settings.cs la set aagum)
    //       - AimKeyMatch   (FF GLOBAL AIM hotkey, default F9)
    //       - FfMaxKey      (FF MAX AIM hotkey, default F10)
    //       - StreamerOn    (streamer mode state)
    //     Load: ctor la — keys sync + hotkey timer ku munnadi
    //     Save: event hooks (+= — existing handler touch illa) + FormClosing
    //
    //     Log viewer: SETTINGS panel la SCAN LOG / VIEW LOG button
    //       → %TEMP%\11-11_scan_log.txt (FastScan.cs SCAN_LOG) notepad la open
    public partial class Form1
    {
        // ---------- LOAD (ctor la — hotkey timer start ku munnadi) ----------
        private void LoadSettings()
        {
            try
            {
                var rk = Microsoft.Win32.Registry.CurrentUser.OpenSubKey(ThemeRegPath);
                if (rk != null)
                {
                    Keys k;
                    string hk = rk.GetValue("HideKey") as string;
                    if (!string.IsNullOrEmpty(hk) && hk != "NONE" && Enum.TryParse(hk, out k)) hideKey = k;

                    string ak = rk.GetValue("AimKeyMatch") as string;
                    if (!string.IsNullOrEmpty(ak) && Enum.TryParse(ak, out k)) aimKeyMatch = k;

                    string fk = rk.GetValue("FfMaxKey") as string;
                    if (!string.IsNullOrEmpty(fk) && Enum.TryParse(fk, out k)) ffMaxKey = k;

                    object so = rk.GetValue("StreamerOn");
                    if (so is int) StreamerOn = ((int)so != 0);

                    rk.Close();
                }
            }
            catch { }
        }

        // ---------- SAVE ----------
        private void SaveSettings()
        {
            try
            {
                var rk = Microsoft.Win32.Registry.CurrentUser.CreateSubKey(ThemeRegPath);
                rk.SetValue("HideKey", hideKey == Keys.None ? "NONE" : hideKey.ToString());
                rk.SetValue("AimKeyMatch", aimKeyMatch.ToString());
                rk.SetValue("FfMaxKey", ffMaxKey.ToString());
                rk.SetValue("StreamerOn", StreamerOn ? 1 : 0);
                rk.Close();
            }
            catch { }
        }

        // ---------- INIT (ctor la call) ----------
        private void InitSettingsIO()
        {
            try
            {
                LoadSettings();

                // key button texts — saved keys padi sync (defaults F9/F10/NONE aana
                // onnum maaradhu, changed aana matthu theriyum)
                if (btnHideKey != null) btnHideKey.Text = (hideKey == Keys.None) ? "NONE" : hideKey.ToString();
                if (btnAimKeyMatch != null) btnAimKeyMatch.Text = aimKeyMatch.ToString();
                if (btnFfMaxKey != null) btnFfMaxKey.Text = ffMaxKey.ToString();

                // save hooks — existing handlers nu + (avanga state change panna aprom)
                // btnHideKey / btnAimKeyMatch capture ASYNC — adhu FormClosing la save aagum
                if (btnStreamer != null) btnStreamer.Click += (s, e) => SaveSettings();
                this.FormClosing += (s, e) => SaveSettings();
            }
            catch { }
        }

        // ---------- LOG VIEWER (SETTINGS panel — VIEW LOG button) ----------
        private void btnViewLog_Click(object sender, EventArgs e)
        {
            try
            {
                if (!File.Exists(SCAN_LOG))
                {
                    Sta.Text = "No log yet — run FF MAX scan first";
                    Sta.ForeColor = System.Drawing.Color.Yellow;
                    Toast.Info("LOG", "No log file yet — run a scan first");
                    return;
                }
                Process.Start(SCAN_LOG);   // default .txt handler (notepad)
                Sta.Text = "Log opened";
                Sta.ForeColor = System.Drawing.Color.Lime;
            }
            catch (Exception ex)
            {
                Toast.Error("LOG", "Cannot open log: " + ex.Message);
            }
        }
    }
}
