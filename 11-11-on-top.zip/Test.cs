﻿using AYUSH;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace zafkialontop
{
    // TEST section — taniya file (partial class, Form1 oda same class)
    public partial class Form1
    {
        // ★★★ FEATURE: TEST (KXC port apdiye — aimbot ah thodathu, AYUSH backend) ★★★
        // DLLs exe ulla embedded (Native folder) — URL fallback matum GitHub
        // ⚠ Charms.dll REMOVED — Defender detect panniten (Trojan:MSIL/Zilla)
        private const string TestOpenglUrl = "https://raw.githubusercontent.com/tharunkumar-AIDS/11-11-on-top/main/opengl32.dll";
        // ★ transparent.dll — scan panniten: grabber/exfil 0, NETWORK ZERO (wininet/HTTP illa),
        //   inject APIs illa. Defender clean. GLEW/OpenGL based.
        private const string TestTransparentUrl = "https://raw.githubusercontent.com/tharunkumar-AIDS/11-11-on-top/main/transparent.dll";

        // Exe ulla irunthu DLL ah velila edukkum (download theva illa)
        private static bool ExtractNative(string resName, string fileName)
        {
            try
            {
                if (System.IO.File.Exists(fileName) && new System.IO.FileInfo(fileName).Length > 0)
                    return true;
                var asm = System.Reflection.Assembly.GetExecutingAssembly();
                using (var s = asm.GetManifestResourceStream("zafkialontop.Native." + resName))
                {
                    if (s == null) return false;
                    using (var f = System.IO.File.OpenWrite(fileName))
                    {
                        s.CopyTo(f);
                    }
                }
                return System.IO.File.Exists(fileName);
            }
            catch { return false; }
        }


        private async void chkTestSwitch_CheckedChanged(object sender, EventArgs e)
        {
            chkTestSwitch.Checked = true;
            await TestScanReplace("SWITCH",
                "00 00 00 00 00 00 80 40 00 00 00 00 00 00 00 00 00 00 80 BF 00 00 00 00 00 00 80 BF 00 00 00 00 00 00 00 00 00 00 80 3F 00 00 00 00 00 00 80 BF",
                "00 00 00 00 00 00 80 3f 00 00 00 00 00 00 00 00 00 00 80 bf 00 00 00 00 00 00 80 bf 00 00 00 00 00 00 00 00 00 00 80 3f 00 00 00 00 00 00 00 00");
        }

        private async void chkTestSaim_CheckedChanged(object sender, EventArgs e)
        {
            chkTestSaim.Checked = true;
            await TestScanReplace("SNIPER AIM",
                "FF FF FF FF 08 00 00 00 00 00 60 40 CD CC 8C 3F 8F C2 F5 3C CD CC CC 3D 06 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 80 3F 33 33 13 40 00 00 B0 3F 00 00 80 3F 01",
                "FF FF FF FF 08 00 00 00 00 00 60 40 CD CC 8C 3F 8F C2 F5 3C CD CC CC 3D 06 00 00 00 00 00 19 3F 00 00 00 00 00 00 00 00 00 00 00 00 00 00 80 3F 33 33 13 40 00 00 B0 3F 00 00 80 3F 01");
        }

        private async System.Threading.Tasks.Task TestScanReplace(string tag, string search, string replace)
        {
            try
            {
                Process proc = FindEmulator();
                if (proc == null) { UpdateStatus("Emulator Not Found!", Color.Red); Console.Beep(2000, 400); return; }
                AYUSH.OpenProcess(proc.Id);
                UpdateStatus(tag + ": Injecting...", Color.Yellow);
                var wl = (await AYUSH.AoBScan(search, writable: true, executable: false)).ToList();
                if (wl.Count == 0) { UpdateStatus(tag + ": Activation Failed!", Color.Red); Console.Beep(2000, 400); return; }
                foreach (long a in wl)
                    AYUSH.WriteMemory(a.ToString("X"), "hex", replace);
                UpdateStatus(tag + ": Activated (" + wl.Count + ")", Color.Lime);
                Console.Beep(400, 300);
            }
            catch (Exception ex) { UpdateStatus(tag + " error: " + ex.Message, Color.Red); }
        }

        


        private async System.Threading.Tasks.Task<bool> TestDllInject(string tag, string dllName, string url)
        {
            try
            {
                Process target = FindEmulator();
                if (target == null) { UpdateStatus("Emulator Not Found!", Color.Red); return false; }
                string fileName = System.IO.Path.Combine(Application.StartupPath, dllName);
                if (!System.IO.File.Exists(fileName))
                {
                    // 1) exe embedded copy, 2) GitHub download
                    if (!ExtractNative(dllName, fileName))
                    {
                        if (string.IsNullOrWhiteSpace(url) || url.StartsWith("PUT_")) { UpdateStatus(tag + ": embedded illa, URL set pannala!", Color.Red); return false; }
                        UpdateStatus(tag + ": Downloading...", Color.Yellow);
                        ServicePointManager.SecurityProtocol = (SecurityProtocolType)3072;
                        // ⚠ part-la download aana file left aayathu, alla download: next time
                        // File.Exists true aayum broken DLL inject aagum — always delete first
                        try { if (System.IO.File.Exists(fileName)) System.IO.File.Delete(fileName); } catch { }
                        using (WebClient wc = new WebClient())
                            await wc.DownloadFileTaskAsync(new Uri(url), fileName);
                    }
                }
                // Sanity: file irundhaalum 0 byte / partial na backup aagum
                try
                {
                    var fi = new System.IO.FileInfo(fileName);
                    if (!fi.Exists || fi.Length < 1024)
                    { UpdateStatus(tag + ": DLL corrupt/empty (" + (fi.Exists ? fi.Length + "B" : "missing") + ") - delete panni retry", Color.Red); return false; }
                }
                catch (Exception exChk) { UpdateStatus(tag + " verify error: " + exChk.Message, Color.Red); return false; }
                IntPtr procHandle = OpenProcess(PROCESS_CREATE_THREAD | PROCESS_QUERY_INFORMATION | PROCESS_VM_OPERATION | PROCESS_VM_WRITE | PROCESS_VM_READ, false, target.Id);
                if (procHandle == IntPtr.Zero) { UpdateStatus("OpenProcess failed! Run as Admin", Color.Red); return false; }
                IntPtr loadAddr = GetProcAddress(GetModuleHandle("kernel32.dll"), "LoadLibraryA");
                byte[] pathBytes = Encoding.Default.GetBytes(fileName + "\0");
                IntPtr allocAddr = VirtualAllocEx(procHandle, IntPtr.Zero, (uint)pathBytes.Length, MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE);
                UIntPtr written;
                WriteProcessMemory(procHandle, allocAddr, pathBytes, (uint)pathBytes.Length, out written);
                IntPtr thread = CreateRemoteThread(procHandle, IntPtr.Zero, 0, loadAddr, allocAddr, 0, IntPtr.Zero);
                if (thread == IntPtr.Zero) { UpdateStatus("Inject failed!", Color.Red); return false; }
                WaitForSingleObject(thread, 5000);
                uint exitCode;
                if (GetExitCodeThread(thread, out exitCode) && exitCode == 0) { UpdateStatus("DLL load failed! Install VC++", Color.Red); return false; }
                UpdateStatus(tag + " Injected", Color.Lime);
                Console.Beep(400, 300);
                return true;
            }
            catch (Exception ex) { UpdateStatus(tag + " error: " + ex.Message, Color.Red); return false; }
        }

        // ★★★ FEATURE: TEST5566 — VENOMHEX scan & replace (vendor "venom hex" method) ★★★
        // ENABLE = AoBScan(search) → original backup → replace write.
        // DISABLE = originals restore (dictionary la vachadhu).
        // 🔧 Pattern enga: keezha TestSnrSearch / TestSnrReplace ulla real pattern podu
        private const string TestSnrSearch = "00 00 00 00 00 00 5C 43 00 00 90 42 00 00 B4 42 96 00 00 00 00 00 00 00 00 00 00 3F 00 00 80 3E 00 00 00 00 04 00 00 00 00 00 80 3F 00 00 20 41 00 00 34 42 01 00 00 00 01 00 00 00 00 00 00 00 00 00 00 00 00 00 80 3F 8F C2 35 3F 9A 99 99 3F 00 00 80 3F 00 00 00 00 1F 85 6B 3F 1F 85 6B 3F 00 00 80 3F 00 00 00 00 00 00 00 00 00 00 00 3F 00 00 00 00 00 00 40 3F 00 00 00 00 00 00 80 3F";
        private const string TestSnrReplace = "00 00 00 00 00 00 5C 43 00 00 90 42 00 00 B4 42 96 00 00 00 00 00 00 00 00 00 00 01 00 00 80 00 00 00 00 00 04 00 00 00 00 00 80 3F 00 00 20 41 00 00 34 42 01 00 00 00 01 00 00 00 00 00 00 00 00 00 00 00 00 00 80 3F 8F C2 35 3F 9A 99 99 3F 00 00 80 3F 00 00 00 00 1F 85 6B 3F 1F 85 6B 3F 00 00 80 3F";
        private static readonly VNX.VENOMHEX VenomMem = new VNX.VENOMHEX();
        private static readonly Dictionary<long, byte[]> VenomOriginal = new Dictionary<long, byte[]>();
        private static readonly Dictionary<long, byte[]> VenomReplaced = new Dictionary<long, byte[]>();
        private bool venom5566On;

        private async void chkTest5566_CheckedChanged(object sender, EventArgs e)
        {
            if (!chkTest5566.Checked)
            {
                // ---- DISABLE — restore originals (vendor disable branch) ----
                if (!venom5566On) return;
                try
                {
                    UpdateStatus("TEST5566: Restoring originals...", Color.Orange);
                    int restoreCount = 0;
                    foreach (var kvp in VenomOriginal)
                        if (VenomMem.WriteBytes(kvp.Key, kvp.Value)) restoreCount++;
                    VenomOriginal.Clear();
                    VenomReplaced.Clear();
                    venom5566On = false;
                    UpdateStatus("TEST5566: Restored " + restoreCount + " addresses!", Color.Lime);
                    Console.Beep(1500, 300);
                }
                catch (Exception ex) { UpdateStatus("TEST5566 restore error: " + ex.Message, Color.Red); }
                return;
            }

            // ---- ENABLE — vendor scan & replace branch ----
            if (string.IsNullOrWhiteSpace(TestSnrSearch))
            {
                chkTest5566.Checked = false;
                UpdateStatus("TEST5566: pattern not set (Test.cs la TestSnrSearch/Replace podu)", Color.Orange);
                return;
            }

            try
            {
                VenomOriginal.Clear();
                VenomReplaced.Clear();
                var sw = System.Diagnostics.Stopwatch.StartNew();

                Process proc = FindEmulator();
                if (proc == null) { chkTest5566.Checked = false; UpdateStatus("TEST5566: Emulator Not Found!", Color.Red); Console.Beep(2000, 400); return; }

                if (!VenomMem.OpenProcess(proc.Id)) { chkTest5566.Checked = false; UpdateStatus("TEST5566: OpenProcess failed! Run as Admin", Color.Red); return; }

                UpdateStatus("TEST5566: Searching & Replacing...", Color.Yellow);
                var found = (await VenomMem.AoBScan(TestSnrSearch, writable: true, executable: false)).ToList();
                if (found.Count == 0)
                {
                    venom5566On = false;
                    chkTest5566.Checked = false;
                    UpdateStatus("TEST5566: Pattern Not Found!", Color.Red);
                    Console.Beep(1000, 400);
                    return;
                }

                byte[] replaceBytes = TestSnrHexBytes(TestSnrReplace);
                int patternLength = TestSnrSearch.Split(new[] { ' ' }, StringSplitOptions.RemoveEmptyEntries).Length;

                foreach (long addr in found)
                {
                    VenomOriginal[addr] = VenomMem.ReadBytes(addr, patternLength);   // original save
                    VenomMem.WriteBytes(addr, replaceBytes);                        // replace write
                    VenomReplaced[addr] = replaceBytes;                             // replaced back-up
                }

                sw.Stop();
                venom5566On = true;
                UpdateStatus("TEST5566: Activated (" + found.Count + ") - " + sw.Elapsed.TotalSeconds.ToString("F2") + " s", Color.Lime);
                Console.Beep(400, 300);
            }
            catch (Exception ex)
            {
                venom5566On = false;
                chkTest5566.Checked = false;
                UpdateStatus("TEST5566 error: " + ex.Message, Color.Red);
            }
        }

        // hex string → bytes (?? = 00, VENOMHEX ParseHexToBytes same logic)
        private static byte[] TestSnrHexBytes(string hexString)
        {
            var parts = hexString.Split(new[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
            byte[] bytes = new byte[parts.Length];
            for (int i = 0; i < parts.Length; i++)
            {
                if (parts[i] == "??" || parts[i] == "?") bytes[i] = 0x00;
                else bytes[i] = Convert.ToByte(parts[i], 16);
            }
            return bytes;
        }

    }
}
