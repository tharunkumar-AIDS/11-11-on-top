using System;
using System.Drawing;
using System.Windows.Forms;

namespace zafkialontop
{
    public enum ToastType { Error, Info, Success }

    // Screenshot mari slide-in toast (top-right, auto-close + progress + X)
    public class ToastForm : Form
    {
        private Timer anim;
        private Timer life;
        private Panel progress;
        private int targetX;
        private int lifeMs;
        private int elapsed;

        public ToastForm(string title, string message, ToastType type)
        {
            FormBorderStyle = FormBorderStyle.None;
            ShowInTaskbar = false;
            TopMost = true;
            StartPosition = FormStartPosition.Manual;
            Size = new Size(320, 85);
            BackColor = Color.FromArgb(25, 25, 25);

            Color accent = type == ToastType.Error ? Color.FromArgb(220, 50, 50)
                : (type == ToastType.Success ? Color.FromArgb(50, 200, 80) : Color.FromArgb(50, 130, 220));
            string icon = type == ToastType.Error ? "✕" : (type == ToastType.Success ? "✓" : "i");

            var bar = new Panel();
            bar.BackColor = accent;
            bar.Location = new Point(0, 0);
            bar.Size = new Size(5, 82);
            Controls.Add(bar);

            var pic = new Label();
            pic.Text = icon;
            pic.Font = new Font("Segoe UI", 16, FontStyle.Bold);
            pic.ForeColor = Color.White;
            pic.BackColor = accent;
            pic.TextAlign = ContentAlignment.MiddleCenter;
            pic.Location = new Point(14, 18);
            pic.Size = new Size(44, 44);
            Controls.Add(pic);

            var lblTitle = new Label();
            lblTitle.Text = title.ToUpperInvariant();
            lblTitle.Font = new Font("Segoe UI", 10, FontStyle.Bold);
            lblTitle.ForeColor = Color.White;
            lblTitle.Location = new Point(68, 10);
            lblTitle.AutoSize = true;
            Controls.Add(lblTitle);

            var lblMsg = new Label();
            lblMsg.Text = message;
            lblMsg.Font = new Font("Segoe UI", 8.5F);
            lblMsg.ForeColor = Color.FromArgb(180, 180, 180);
            lblMsg.Location = new Point(68, 34);
            lblMsg.Size = new Size(215, 34);
            Controls.Add(lblMsg);

            var btnX = new Button();
            btnX.Text = "✕";
            btnX.Font = new Font("Segoe UI", 8, FontStyle.Bold);
            btnX.ForeColor = Color.Gray;
            btnX.FlatStyle = FlatStyle.Flat;
            btnX.FlatAppearance.BorderSize = 0;
            btnX.BackColor = Color.Transparent;
            btnX.Location = new Point(292, 5);
            btnX.Size = new Size(23, 23);
            btnX.Click += (s, e) => { Close(); };
            Controls.Add(btnX);

            progress = new Panel();
            progress.BackColor = accent;
            progress.Location = new Point(0, 82);
            progress.Size = new Size(320, 3);
            Controls.Add(progress);

            var area = Screen.PrimaryScreen.WorkingArea;
            targetX = area.Right - Width - 15;
            Location = new Point(area.Right + 10, 0);

            lifeMs = 3500;
            elapsed = 0;

            anim = new Timer();
            anim.Interval = 12;
            anim.Tick += (s, e) =>
            {
                if (Left > targetX) Left = Math.Max(targetX, Left - 28);
                else
                {
                    anim.Stop();
                    life.Start();
                }
            };

            life = new Timer();
            life.Interval = 50;
            life.Tick += (s, e) =>
            {
                elapsed += 50;
                int w = (int)(320 * (1.0 - (double)elapsed / lifeMs));
                if (w < 0) w = 0;
                progress.Width = w;
                if (elapsed >= lifeMs) { life.Stop(); Close(); }
            };
        }

        protected override void OnShown(EventArgs e)
        {
            base.OnShown(e);
            anim.Start();
        }

        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            try { if (anim != null) anim.Dispose(); } catch { }
            try { if (life != null) life.Stop(); } catch { }
            base.OnFormClosing(e);
        }
    }

    public static class Toast
    {
        private static readonly System.Collections.Generic.List<ToastForm> open = new System.Collections.Generic.List<ToastForm>();

        public static void Show(string title, string message, ToastType type)
        {
            try
            {
                var area = Screen.PrimaryScreen.WorkingArea;
                var f = new ToastForm(title, message, type);
                lock (open)
                {
                    while (open.Count >= 4)
                    {
                        try { open[0].Close(); } catch { }
                        open.RemoveAt(0);
                    }
                    open.Add(f);
                    Layout();
                }
                f.FormClosed += (s, e) => { lock (open) { open.Remove(f); Layout(); } };
                f.Show();
            }
            catch { }
        }

        private static void Layout()
        {
            try
            {
                var area = Screen.PrimaryScreen.WorkingArea;
                int y = area.Top + 15;
                foreach (var f in open)
                {
                    try
                    {
                        if (f.Left < area.Right) f.Location = new Point(area.Right - f.Width - 15, y);
                        else f.Location = new Point(f.Left, y);
                        y += f.Height + 10;
                    }
                    catch { }
                }
            }
            catch { }
        }

        public static void Error(string title, string message) { Show(title, message, ToastType.Error); }
        public static void Info(string title, string message) { Show(title, message, ToastType.Info); }
        public static void Success(string title, string message) { Show(title, message, ToastType.Success); }
    }
}
